// Test «Später nachtragen» (Handy-Format, erfundene Daten): eine Person zurückstellen, die anderen abrechnen,
// später nur für sie Dokumente erstellen, ablegen, senden. Google ist nachgebaut (google-mock.js), kein Netz.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const assert = require('assert');
const openSec = async (page) => { if (!(await page.locator('details.card[open]').count())) await page.getByText('Sicherheit', { exact: true }).click(); };
const { makeGoogle } = require('./google-mock');
const OUT = path.join(__dirname, 'ui-out'); fs.mkdirSync(OUT, { recursive: true });
const KEY = 'testkey-abruf-0123456789'; const PIN = '123456';
const ok = (s) => console.log('ok -', s);
const MON = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

const g = makeGoogle();
const testFolder = g.folder('_TEST Beispieldaten', g.main);

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' && !(offline && /Failed to load resource/.test(m.text()))) errors.push('console: ' + m.text()); });
  let dialogAnswer = true; const dialogs = []; page.on('dialog', (d) => { dialogs.push(d.message()); return dialogAnswer ? d.accept() : d.dismiss(); });
  let offline = false; const posts = [];
  await page.route('https://script.google.com/**', async (route) => {
    if (offline) return route.abort();
    const req = route.request(); let body;
    if (req.method() === 'POST') {
      const p = JSON.parse(req.postData()); posts.push(p);
      assert.ok(!/application\/json/.test(req.headers()['content-type'] || ''), 'kein JSON-Content-Type (sonst Vorabfrage)');
      body = g.post(p);
    } else body = g.get(Object.fromEntries(new URL(req.url()).searchParams));
    route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(body) });
  });
  const shot = (n) => page.screenshot({ path: path.join(OUT, n + '.png'), fullPage: true });
  const btn = (name, exact) => page.getByRole('button', { name, exact: !!exact });

  await page.goto('http://localhost:8765/');
  await page.getByPlaceholder('PIN (6–8 Ziffern)').fill(PIN); await page.getByPlaceholder('PIN wiederholen').fill(PIN);
  await btn('Mit erfundenen Beispieldaten starten').click(); await page.getByText('Abrechnungsmonat').waitFor();
  // Schlüssel eintragen
  await btn('Einstellungen').click(); await openSec(page); await page.getByLabel('Abruf-Schlüssel').fill(KEY); await page.getByLabel('Abruf-Schlüssel').blur();
  await btn('Abrechnung', true).click();
  const card = (n) => page.locator('.card', { has: page.getByRole('heading', { name: n, exact: true }) });
  const y26 = () => [...g.folders.values()].find((f) => f._name === '2026' && f._parent === testFolder); // Jahresordner im Testordner
  const sub = (n) => [...g.folders.values()].find((f) => f._name === n && f._parent === y26());
  await page.locator('select').nth(0).selectOption('9'); await page.locator('select').nth(1).selectOption('2026');
  await btn('Beispiel-CSV laden').click(); await page.getByText('eingelesen').waitFor();
  await card('Maria Demo').getByRole('button', { name: 'Stunden eintragen' }).click();
  await page.locator('select').filter({ hasText: 'Bitte wählen' }).selectOption('abziehen');
  await page.getByPlaceholder('z. B. 36').fill('36'); await page.getByPlaceholder('z. B. 36').blur();
  await btn('Verteilung vorschlagen').click(); await page.getByText('Summe stimmt mit dem Total').waitFor();
  // Peter hat noch keine Stunden: «Später nachtragen»
  await page.getByText('Peter Test: keine Stunden erfasst').waitFor();
  assert.ok(await btn('Dokumente erstellen').isDisabled(), 'vorher gesperrt');
  await card('Peter Test').getByRole('button', { name: 'Später nachtragen' }).click();
  await card('Peter Test').getByText('später nachtragen', { exact: true }).waitFor();
  assert.ok(await card('Peter Test').evaluate((el) => el.classList.contains('later')), 'Karte orange');
  assert.ok(!/\bnull\b|undefined/.test(await page.innerText('body')), 'kein «null» oder «undefined» sichtbar');
  const bg = await card('Peter Test').evaluate((el) => getComputedStyle(el).backgroundColor); assert.strictEqual(bg, 'rgb(251, 225, 200)', 'orange Hintergrund');
  await page.getByText('Später nachtragen: Peter Test – keine Dokumente, keine E-Mail, in der Jahresübersicht leer.').waitFor();
  assert.ok(!(await btn('Dokumente erstellen').isDisabled()), 'für die anderen freigegeben');
  await shot('n-01-spaeter'); ok('«Später nachtragen»: Karte orange, Dokumente für die anderen freigegeben');
  // Rückgängig und wieder setzen
  await card('Peter Test').getByRole('button', { name: 'Rückgängig' }).click(); await page.getByText('Peter Test: keine Stunden erfasst').waitFor();
  await card('Peter Test').getByRole('button', { name: 'Später nachtragen' }).click();

  // 1) Abrechnung ohne Peter
  await btn('Dokumente erstellen').click(); await page.getByText('Dokumente erstellt').waitFor({ timeout: 20000 });
  assert.strictEqual(await page.locator('details.mailprev').count(), 3, 'drei E-Mails, keine für Peter');
  assert.ok(!(await page.getByText(/Peter Test\.pdf/).count()), 'keine Datei für Peter');
  await btn('Senden, ablegen und sichern (3)').click();
  await page.getByText('Test abgeschlossen: abgelegt, Senden geprüft, gesichert.').waitFor({ timeout: 30000 });
  const sh = [...g.spreads.values()].find((x) => x.getName() === 'Jahresübersicht Löhne Assistenz 2026' && x._file._parent === y26());
  assert.ok(sh, 'Jahrestabelle im Testordner neu angelegt'); const s = sh._sheets[0];
  const col = (hd) => { const j = s.rows[0].indexOf(hd); assert.ok(j > 0, 'Spalte ' + hd); return j; };
  assert.strictEqual(s.rows[9][0], 'September'); assert.strictEqual(s.rows[9][col('Peter Netto')], '', 'Peter leer (nicht 0.00)');
  const annaN = s.rows[9][col('Anna Netto')]; const totStd1 = s.rows[9][col('Total Stunden')];
  assert.ok(annaN > 0);
  assert.ok(!sub('Peter Test') || !g.live(sub('Peter Test')).length, 'nichts im Ordner von Peter');
  assert.strictEqual(posts.filter((p) => p.action === 'senden').length, 3);
  assert.ok(!g.drafts.some((d) => /Peter/.test(d.subject)), 'kein Entwurf für Peter');
  await card('Peter Test').getByText('später nachtragen', { exact: true }).waitFor();
  await shot('n-02-ohne-peter'); ok('Ohne Peter abgerechnet: 3 E-Mails, Peter in der Jahrestabelle leer, keine Datei');

  // 2) Neustart, dann Peters Stunden nachtragen: nur Peter, normaler Text
  await page.reload(); await page.getByPlaceholder('PIN').fill(PIN); await btn('Entsperren').click(); await page.getByText('Abrechnungsmonat').waitFor();
  await card('Peter Test').getByText('später nachtragen', { exact: true }).waitFor();
  assert.strictEqual(await page.getByText('✓ gesendet', { exact: true }).count(), 3);
  await card('Peter Test').getByRole('button', { name: 'Stunden eintragen' }).click();
  const hrs = card('Peter Test').locator('input.hrs'); await hrs.first().fill('4.5'); await hrs.first().blur();
  await card('Peter Test').getByRole('button', { name: '+ Tag' }).click();
  await hrs.nth(1).fill('3'); await hrs.nth(1).blur();
  await card('Peter Test').getByText('2 Einsätze · 7.50 h').waitFor();
  await page.getByText('Die Dokumente können erstellt werden für: Peter Test.').waitFor();
  const nd = dialogs.length;
  await btn('Dokumente erstellen').click(); await page.getByText('Dokumente erstellt').waitFor({ timeout: 20000 });
  assert.strictEqual(dialogs.length, nd, 'keine Rückfrage «schon erstellt» beim Nachtrag');
  assert.strictEqual(await page.locator('details.mailprev').count(), 1, 'nur Peter');
  await page.locator('details.mailprev > summary').click();
  const b = await page.innerText('body');
  assert.ok(b.includes('[TEST] Lohnabrechnung September 2026 / Peter Test') && !b.includes('(korrigiert)') && b.includes('Hier ist deine Lohnabrechnung vom September mit der Stundenübersicht.'), 'normaler Betreff und Text');
  const nAbl = posts.filter((p) => p.action === 'ablegen').length;
  await btn('Senden, ablegen und sichern (1)').click();
  await page.getByText('Test abgeschlossen: abgelegt, Senden geprüft, gesichert.').waitFor({ timeout: 30000 });
  assert.deepStrictEqual(posts.filter((p) => p.action === 'ablegen').slice(nAbl).map((p) => p.ordner), ['', 'Peter Test'], 'nur Jahres-PDF und Peter abgelegt');
  assert.deepStrictEqual(g.live(sub('Peter Test')).map((f) => f._name).sort(), ['2026-09 Lohnabrechnung Peter Test.pdf', '2026-09 Stundenübersicht Peter Test.pdf']);
  assert.ok(s.rows[9][col('Peter Netto')] > 0, 'Peter jetzt eingetragen'); assert.strictEqual(s.rows[9][col('Anna Netto')], annaN, 'Anna unverändert');
  assert.strictEqual(Math.round((s.rows[9][col('Total Stunden')] - totStd1) * 100), 750, 'Total Stunden + 7.50');
  assert.strictEqual(posts.filter((p) => p.action === 'senden').length, 4, 'nur Peter dazu gesendet');
  assert.strictEqual(posts.filter((p) => p.action === 'sicherung').length, 2);
  assert.strictEqual(await page.getByText('✓ gesendet', { exact: true }).count(), 4, 'alle gesendet');
  await shot('n-03-nachtrag'); ok('Nachtrag: nur Peter erstellt, abgelegt, gesendet (normaler Text), Jahrestabelle ergänzt');

  assert.deepStrictEqual(errors, [], errors.join('\n'));
  await browser.close(); console.log('NACHTRAG-TEST OK');
})().catch((e) => { console.error('TESTFEHLER:', e.message); process.exit(1); });
