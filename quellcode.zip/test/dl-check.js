const { chromium } = require('/opt/npm-tools/node_modules/playwright');
(async () => {
  const b = await chromium.launch(); const p = await (await b.newContext({ acceptDownloads: true })).newPage();
  await p.goto('http://localhost:8765/');
  for (const name of ['2026-09 Stundenübersicht Test.pdf', '2026-09 Lohnabrechnung Test.pdf', 'Jahresübersicht.pdf', 'María.pdf']) {
    const d = p.waitForEvent('download');
    await p.evaluate((n) => { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['x'], { type: 'application/pdf' })); a.download = n; document.body.append(a); a.click(); a.remove(); }, name);
    console.log(JSON.stringify(name), '->', JSON.stringify((await d).suggestedFilename()));
    await p.waitForTimeout(300);
  }
  await b.close();
})();
