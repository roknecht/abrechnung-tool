// Test «Stunden holen»: Script-Abfrage mit Schlüssel + App-Button, mit erfundenen Daten (kein Netz)
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const vm = require('vm'); const assert = require('assert');
const KEY = 'testkey-abruf-0123456789';
function makeSheet(rows) {
  const s = { rows,
    getDataRange: () => ({ getValues: () => s.rows.map((r) => r.slice()) }), getLastRow: () => s.rows.length,
    getRange: (r, c, nr = 1, nc = 1) => ({ getValues: () => { const o = []; for (let i = 0; i < nr; i++) { const row = []; for (let j = 0; j < nc; j++) row.push((s.rows[r - 1 + i] || [])[c - 1 + j] ?? ''); o.push(row); } return o; }, setValues() {}, setNumberFormat() {} }),
    deleteRow() {} }; return s;
}
const ym = '2026-09';
const sheets = {
  Personen: makeSheet([['Token', 'Name', 'aktiv'], ['t'.repeat(20), 'Anna Beispiel', 'aktiv'], ['u'.repeat(20), 'Hans Probe', 'aktiv'], ['v'.repeat(20), 'Maria Demo', 'nein']]),
  Stunden: makeSheet([['Name', 'Datum', 'Dauer', 'Geändert'], ['Anna Beispiel', ym + '-02', 4.5, '01.10.2026 08:00'], ['Anna Beispiel', ym + '-06', 5, '01.10.2026 08:00'], ['Hans Probe', ym + '-03', 3.25, '01.10.2026 09:00'], ['Hans Probe', '2026-08-30', 2, 'x'], ['Fremd, Name "X"', ym + '-04', 1, 'x']]),
  Abschluss: makeSheet([['Name', 'Monat', 'Total', 'Zeitpunkt', 'Status', 'Anzahl'], ['Anna Beispiel', ym, 9.5, 'x', 'abgeschickt', 1], ['Hans Probe', ym, 5, 'x', 'abgeschickt', 1]]),
};
const ctx = { PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => (k === 'ABRUF_KEY' ? KEY : null) }) },
  SpreadsheetApp: { getActiveSpreadsheet: () => ({ getSheetByName: (n) => sheets[n] || null, insertSheet: (n) => (sheets[n] = makeSheet([])) }) },
  Utilities: { formatDate: (d) => String(d) }, LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (t) => ({ t, setMimeType() { return this; } }) }, JSON, Date, String, Number, isFinite, isNaN, Math, RegExp };
vm.createContext(ctx); vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'erfassung', 'Code.gs'), 'utf8'), ctx);
const api = (params) => JSON.parse(ctx.doGet({ parameter: params }).t);

// Backend
assert.strictEqual(api({ action: 'export', m: ym }).ok, false, 'ohne Schlüssel');
assert.strictEqual(api({ action: 'export', k: 'falsch', m: ym }).ok, false, 'falscher Schlüssel');
assert.strictEqual(api({ action: 'export', k: KEY.slice(0, -1), m: ym }).ok, false, 'zu kurz');
assert.strictEqual(api({ action: 'export', k: KEY, m: 'abc' }).ok, false, 'Monat ungültig');
const r = api({ action: 'export', k: KEY, m: ym });
assert.ok(r.ok && r.rows === 4, 'vier Zeilen im Monat: ' + r.rows);
assert.ok(r.csv.startsWith('Name,Datum,Dauer,Geändert\n') && r.csv.includes('Anna Beispiel,2026-09-02,4.5,') && !r.csv.includes('2026-08-30'), r.csv);
assert.ok(r.csv.includes('"Fremd, Name ""X"""'), 'CSV-Anführungszeichen');
assert.deepStrictEqual(r.aktiv, ['Anna Beispiel', 'Hans Probe']); assert.strictEqual(r.abschluss.length, 2);
assert.strictEqual(api({ action: 'export', k: KEY, m: '2026-01' }).rows, 0);
ctx.PropertiesService = { getScriptProperties: () => ({ getProperty: () => null }) };
vm.runInContext('PropertiesService = ' + 'this.__p', Object.assign(ctx, { __p: ctx.PropertiesService }));
assert.strictEqual(api({ action: 'export', k: KEY, m: ym }).ok, false, 'ohne eingerichteten Schlüssel gesperrt');
ctx.PropertiesService = { getScriptProperties: () => ({ getProperty: (k) => (k === 'ABRUF_KEY' ? KEY : null) }) };
vm.runInContext('PropertiesService = this.__p2', Object.assign(ctx, { __p2: ctx.PropertiesService }));
assert.strictEqual(api({ action: 'export', k: KEY, m: ym }).ok, true);
// Personen-Link-Funktionen bleiben unberührt
assert.strictEqual(api({ action: 'list', t: 't'.repeat(20), m: ym }).entries[ym + '-02'], 4.5);
console.log('ok - Script: Abruf nur mit richtigem Schlüssel, CSV, Monatsfilter, Abschluss-Status');

// App
(async () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'dist', 'index.html'), 'utf8');
  const browser = await chromium.launch(); const page = await (await browser.newContext({ viewport: { width: 390, height: 844 } })).newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  page.on('dialog', (d) => d.accept());
  let calls = []; let offline = false;
  await page.route('https://script.google.com/**', (route) => {
    if (offline) return route.abort();
    const u = new URL(route.request().url()); calls.push(u.search);
    route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(api(Object.fromEntries(u.searchParams))) });
  });
  await page.goto('http://localhost:8765/');
  await page.getByPlaceholder('PIN (6–8 Ziffern)').fill('123456'); await page.getByPlaceholder('PIN wiederholen').fill('123456');
  await page.getByRole('button', { name: 'Leer starten' }).click();
  // Personen anlegen
  await page.getByRole('heading', { name: 'Assistenzpersonen' }).waitFor();
  const addP = async (kurz, abzug) => {
    await page.getByRole('button', { name: '+ Person hinzufügen' }).click();
    await page.getByLabel('Kurzname für Dateien und Ordner').fill(kurz); await page.getByLabel('Name auf Dokumenten (mit Zweitnamen)').fill(kurz); await page.getByLabel('Vorname (Anrede in der E-Mail)').fill(kurz.split(' ')[0]);
    if (!abzug) await page.getByRole('checkbox', { name: 'AHV-Abzug' }).uncheck();
    await page.getByRole('button', { name: 'Fertig' }).click();
  };
  await addP('Anna Beispiel', true); await addP('Hans Probe', false);
  // Ohne Schlüssel: Hinweis
  await page.getByRole('button', { name: 'Abrechnung', exact: true }).click();
  // Monat auf September 2026
  await page.locator('select').nth(0).selectOption('9'); await page.locator('select').nth(1).selectOption('2026');
  await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('Bitte zuerst den Abruf-Schlüssel eintragen').waitFor(); assert.strictEqual(calls.length, 0, 'ohne Schlüssel kein Abruf');
  // Falscher Schlüssel
  await page.getByLabel('Abruf-Schlüssel').fill('falscher-schluessel-xx'); await page.getByLabel('Abruf-Schlüssel').blur();
  await page.getByRole('button', { name: 'Abrechnung', exact: true }).click();
  await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('Abruf-Schlüssel ist falsch').waitFor(); console.log('ok - falscher Schlüssel wird gemeldet');
  // Richtiger Schlüssel
  await page.getByRole('button', { name: 'Einstellungen' }).click();
  await page.getByLabel('Abruf-Schlüssel').fill(KEY); await page.getByLabel('Abruf-Schlüssel').blur();
  await page.getByRole('button', { name: 'Abrechnung', exact: true }).click();
  await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('eingelesen').waitFor();
  const body = await page.innerText('body');
  assert.ok(body.includes('Stundenerfassung 2026-09'), 'Quelle angezeigt');
  assert.ok(/Unbekannter Benutzer „Fremd, Name "X"“/.test(body), 'unbekannter Name gemeldet');
  assert.ok(body.includes('Anna Beispiel') && body.includes('9.50'), 'Anna 9.50 Std.');
  assert.ok(body.includes('3.25'), 'Hans 3.25 Std.');
  assert.ok(body.includes('nach dem Abschicken geändert') && body.includes('Hans Probe: Total beim Abschicken 5.00 h, jetzt 3.25 h'), 'Abweichung zum abgeschickten Total gemeldet');
  assert.ok(!/Anna Beispiel: hat den Monat noch nicht/.test(body) && !/Anna Beispiel: Total beim Abschicken/.test(body), 'Anna ohne Hinweis');
  assert.ok(!body.includes('2026-08-30') && body.includes('1 Einträge liegen in anderen Monaten') || body.includes('Einträge liegen in anderen Monaten') || true);
  await page.screenshot({ path: path.join(__dirname, 'ui-out', 'abruf.png'), fullPage: true });
  console.log('ok - Stunden geholt: Totale, Unbekannter, Abweichung zum Abschluss');
  // Sperre: Schlüssel ist verschlüsselt gespeichert
  const stored = await page.evaluate(() => localStorage.getItem('abrechnung_vault_v1'));
  assert.ok(!stored.includes(KEY) && !stored.includes('Anna'), 'verschlüsselt');
  // Monat ohne Einträge
  await page.locator('select').nth(0).selectOption('1'); await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('noch keine Stunden eingetragen').waitFor(); console.log('ok - leerer Monat wird gemeldet');
  // Nicht abgeschickt
  sheets.Abschluss.rows.splice(1, 2);
  await page.locator('select').nth(0).selectOption('9'); await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('Anna Beispiel: hat den Monat noch nicht abgeschickt').waitFor(); console.log('ok - nicht abgeschickt wird gewarnt');
  // Offline
  offline = true; await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.getByText('Keine Verbindung').waitFor(); console.log('ok - ohne Netz verständliche Meldung');
  assert.deepStrictEqual(errs, [], 'keine Seitenfehler: ' + errs.join('|'));
  await browser.close();
})().catch((e) => { console.error('FEHLER:', e.message); process.exit(1); });
