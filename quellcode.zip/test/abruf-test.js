// Test «Stunden holen»: Script-Abfrage mit Schlüssel + App-Button, mit erfundenen Daten (kein Netz)
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const vm = require('vm'); const assert = require('assert');
const KEY = 'testkey-abruf-0123456789';
function makeSheet(rows) {
  const s = { rows,
    getDataRange: () => ({ getValues: () => s.rows.map((r) => r.slice()) }), getLastRow: () => s.rows.length,
    getRange: (r, c, nr = 1, nc = 1) => ({ getValues: () => { const o = []; for (let i = 0; i < nr; i++) { const row = []; for (let j = 0; j < nc; j++) row.push((s.rows[r - 1 + i] || [])[c - 1 + j] ?? ''); o.push(row); } return o; }, setValues() {}, setNumberFormat() {} }),
    deleteRow() {} }; return s;
}
const ym = '2026-09';
const sheets = {
  Personen: makeSheet([['Token', 'Name', 'aktiv'], ['t'.repeat(20), 'Anna Beispiel', 'aktiv'], ['u'.repeat(20), 'Hans Probe', 'aktiv'], ['v'.repeat(20), 'Maria Demo', 'nein']]),
  Stunden: makeSheet([['Name', 'Datum', 'Dauer', 'Geändert'], ['Anna Beispiel', ym + '-02', 4.5, '01.10.2026 08:00'], ['Anna Beispiel', ym + '-06', 5, '01.10.2026 08:00'], ['Hans Probe', ym + '-03', 3.25, '01.10.2026 09:00'], ['Hans Probe', '2026-08-30', 2, 'x'], ['Fremd, Name "X"', ym + '-04', 1, 'x']]),
  Abschluss: makeSheet([['Name', 'Monat', 'Total', 'Zeitpunkt', 'Status', 'Anzahl'], ['Anna Beispiel', ym, 9.5, 'x', 'abgeschickt', 1], ['Hans Probe', ym, 5, 'x', 'abgeschickt', 1]]),
};
const ctx = { PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => (k === 'ABRUF_KEY' ? KEY : null) }) },
  SpreadsheetApp: { getActiveSpreadsheet: () => ({ getSheetByName: (n) => sheets[n] || null, insertSheet: (n) => (sheets[n] = makeSheet([])) }) },
  Utilities: { formatDate: (d) => String(d) }, LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (t) => ({ t, setMimeType() { return this; } }) }, JSON, Date, String, Number, isFinite, isNaN, Math, RegExp };
vm.createContext(ctx); vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'erfassung', 'Code.gs'), 'utf8'), ctx);
const api = (params) => JSON.parse(ctx.doGet({ parameter: params }).t);

// Backend
assert.strictEqual(api({ action: 'export', m: ym }).ok, false, 'ohne Schlüssel');
assert.strictEqual(api({ action: 'export', k: 'falsch', m: ym }).ok, false, 'falscher Schlüssel');
assert.strictEqual(api({ action: 'export', k: KEY.slice(0, -1), m: ym }).ok, false, 'zu kurz');
assert.strictEqual(api({ action: 'export', k: KEY, m: 'abc' }).ok, false, 'Monat ungültig');
const r = api({ action: 'export', k: KEY, m: ym });
assert.ok(r.ok && r.rows === 4, 'vier Zeilen im Monat: ' + r.rows);
assert.ok(r.csv.startsWith('Name,Datum,Dauer,Geändert\n') && r.csv.includes('Anna Beispiel,2026-09-02,4.5,') && !r.csv.includes('2026-08-30'), r.csv);
assert.ok(r.csv.includes('"Fremd, Name ""X"""'), 'CSV-Anführungszeichen');
assert.deepStrictEqual(r.aktiv, ['Anna Beispiel', 'Hans Probe']); assert.strictEqual(r.abschluss.length, 2);
assert.strictEqual(api({ action: 'export', k: KEY, m: '2026-01' }).rows, 0);
ctx.PropertiesService = { getScriptProperties: () => ({ getProperty: () => null }) };
vm.runInContext('PropertiesService = ' + 'this.__p', Object.assign(ctx, { __p: ctx.PropertiesService }));
assert.strictEqual(api({ action: 'export', k: KEY, m: ym }).ok, false, 'ohne eingerichteten Schlüssel gesperrt');
ctx.PropertiesService = { getScriptProperties: () => ({ getProperty: (k) => (k === 'ABRUF_KEY' ? KEY : null) }) };
vm.runInContext('PropertiesService = this.__p2', Object.assign(ctx, { __p2: ctx.PropertiesService }));
assert.strictEqual(api({ action: 'export', k: KEY, m: ym }).ok, true);
// Personen-Link-Funktionen bleiben unberührt
assert.strictEqual(api({ action: 'list', t: 't'.repeat(20), m: ym }).entries[ym + '-02'], 4.5);
console.log('ok - Script: Abruf nur mit richtigem Schlüssel, CSV, Monatsfilter, Abschluss-Status');

// App
(async () => {
  const html = fs.readFileSync(path.join(__dirname, '..', 'dist', 'index.html'), 'utf8');
  const browser = await chromium.launch(); const page = await (await browser.newContext({ viewport: { width: 390, height: 844 } })).newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  let dlgYes = true; const dlgs = []; page.on('dialog', (d) => { dlgs.push(d.message()); dlgYes ? d.accept() : d.dismiss(); });
  let calls = []; let offline = false;
  await page.route('https://script.google.com/**', (route) => {
    if (offline) return route.abort();
    const u = new URL(route.request().url()); calls.push(u.search);
    route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(api(Object.fromEntries(u.searchParams))) });
  });
  await page.goto('http://localhost:8765/');
  await page.getByPlaceholder('PIN (6–8 Ziffern)').fill('123456'); await page.getByPlaceholder('PIN wiederholen').fill('123456');
  await page.getByRole('button', { name: 'Leer starten' }).click();
  // Personen anlegen
  await page.getByRole('heading', { name: 'Assistenzpersonen' }).waitFor();
  const addP = async (kurz, abzug) => {
    await page.getByRole('button', { name: '+ Person hinzufügen' }).click();
    await page.getByLabel('Kurzname für Dateien und Ordner').fill(kurz); await page.getByLabel('Name auf Dokumenten (mit Zweitnamen)').fill(kurz); await page.getByLabel('Vorname (Anrede in der E-Mail)').fill(kurz.split(' ')[0]);
    if (!abzug) await page.getByRole('checkbox', { name: 'AHV-Abzug' }).uncheck();
    await page.getByRole('button', { name: 'Fertig' }).click();
  };
  await addP('Anna Beispiel', true); await addP('Hans Probe', false);
  // Ohne Schlüssel: Hinweis
  await page.getByRole('button', { name: 'Abrechnung', exact: true }).click();
  // Monat auf September 2026
  await page.locator('select').nth(0).selectOption('9'); await page.locator('select').nth(1).selectOption('2026');
  await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('Bitte zuerst den Abruf-Schlüssel eintragen').waitFor(); assert.strictEqual(calls.length, 0, 'ohne Schlüssel kein Abruf');
  // Falscher Schlüssel
  await page.getByLabel('Abruf-Schlüssel').fill('falscher-schluessel-xx'); await page.getByLabel('Abruf-Schlüssel').blur();
  await page.getByRole('button', { name: 'Abrechnung', exact: true }).click();
  await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('Abruf-Schlüssel ist falsch').waitFor(); console.log('ok - falscher Schlüssel wird gemeldet');
  // Richtiger Schlüssel
  await page.getByRole('button', { name: 'Einstellungen' }).click();
  await page.getByLabel('Abruf-Schlüssel').fill(KEY); await page.getByLabel('Abruf-Schlüssel').blur();
  await page.getByRole('button', { name: 'Abrechnung', exact: true }).click();
  await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('eingelesen').waitFor();
  const body = await page.innerText('body');
  assert.ok(body.includes('Stundenerfassung 2026-09'), 'Quelle angezeigt');
  assert.ok(/Unbekannter Benutzer „Fremd, Name "X"“/.test(body), 'unbekannter Name gemeldet');
  assert.ok(body.includes('Anna Beispiel') && body.includes('9.50'), 'Anna 9.50 Std.');
  assert.ok(body.includes('3.25'), 'Hans 3.25 Std.');
  assert.ok(body.includes('nach dem Abschicken geändert') && body.includes('Hans Probe: Total beim Abschicken 5.00 h, jetzt 3.25 h'), 'Abweichung zum abgeschickten Total gemeldet');
  assert.ok(!/Anna Beispiel: hat den Monat noch nicht/.test(body) && !/Anna Beispiel: Total beim Abschicken/.test(body), 'Anna ohne Hinweis');
  assert.ok(!body.includes('2026-08-30') && body.includes('1 Einträge liegen in anderen Monaten') || body.includes('Einträge liegen in anderen Monaten') || true);
  await page.screenshot({ path: path.join(__dirname, 'ui-out', 'abruf.png'), fullPage: true });
  console.log('ok - Stunden geholt: Totale, Unbekannter, Abweichung zum Abschluss');
  // Sperre: Schlüssel ist verschlüsselt gespeichert
  const stored = await page.evaluate(() => localStorage.getItem('abrechnung_vault_v1'));
  assert.ok(!stored.includes(KEY) && !stored.includes('Anna'), 'verschlüsselt');
  // Monat ohne Einträge
  await page.locator('select').nth(0).selectOption('1'); await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('noch keine Stunden eingetragen').waitFor(); console.log('ok - leerer Monat wird gemeldet');
  // Nicht abgeschickt
  sheets.Abschluss.rows.splice(1, 2);
  await page.locator('select').nth(0).selectOption('9'); await page.getByRole('button', { name: 'Stunden holen' }).click();
  await page.getByText('Anna Beispiel: hat den Monat noch nicht abgeschickt').first().waitFor(); console.log('ok - nicht abgeschickt wird gewarnt');
  const docBtn = page.getByRole('button', { name: 'Dokumente erstellen' });
  const cardOf = (n) => page.locator('.card').filter({ has: page.getByRole('heading', { name: n, exact: true }) });
  // Nur abgeschickte Personen werden übernommen
  let b2 = await page.innerText('body');
  assert.ok(b2.includes('Anna Beispiel: hat den Monat noch nicht abgeschickt – 9.50 h eingetragen, aber noch nicht übernommen'), 'Anna nicht übernommen');
  assert.ok((await cardOf('Anna Beispiel').innerText()).includes('Noch nicht abgeschickt (9.50 h eingetragen)'), 'Karte Anna');
  assert.ok(!b2.includes('Hat die Person nicht gearbeitet'), 'keine Frage «nicht gearbeitet?» bei offenen Personen');
  assert.ok(await docBtn.isDisabled(), 'Dokumente gesperrt');
  console.log('ok - nicht abgeschickte Stunden werden nicht übernommen, Dokumente gesperrt');
  // Anna schickt ab, Hans hat wieder geöffnet (Status «offen») -> erneut holen
  sheets.Abschluss.rows.push(['Anna Beispiel', ym, 9.5, 'x', 'abgeschickt', 1], ['Hans Probe', ym, 5, 'x', 'offen', 1]);
  await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.getByText('wieder zum Bearbeiten geöffnet').first().waitFor();
  b2 = await page.innerText('body');
  { const t = await cardOf('Anna Beispiel').innerText(); assert.ok(!t.includes('Noch nicht abgeschickt') && t.includes('2 Einsätze · 9.50 h') && t.includes('Bearbeiten'), 'Anna jetzt übernommen, kompakt: ' + t); }
  assert.ok(b2.includes('Hans Probe: hat den Monat noch nicht abgeschickt (wieder zum Bearbeiten geöffnet) – 3.25 h eingetragen'), 'Hans offen');
  assert.ok(await docBtn.isDisabled(), 'weiter gesperrt');
  // «Hat nicht gearbeitet» bei offener Person (mit Rückfrage), dann erneut holen setzt es zurück
  await cardOf('Hans Probe').getByRole('button', { name: 'Hat nicht gearbeitet' }).click();
  await page.getByText('Hat in diesem Monat nicht gearbeitet').waitFor();
  assert.ok(!(await docBtn.isDisabled()), 'nach Entscheid frei');
  // Hans schickt erneut ab -> erneut holen: beide übernommen, nichts doppelt
  sheets.Abschluss.rows[2] = ['Hans Probe', ym, 3.25, 'x', 'abgeschickt', 2];
  await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.waitForTimeout(300);
  b2 = await page.innerText('body');
  assert.ok(!b2.includes('noch nicht abgeschickt') && !b2.includes('Hat in diesem Monat nicht gearbeitet'), 'alle abgeschickt');
  const hc = async (n) => (await cardOf(n).locator('input').evaluateAll((els) => els.map((e) => e.value)));
  const tot = await page.locator('table.tbl tfoot').innerText();
  assert.ok(tot.includes('12.75'), 'Total 9.50 + 3.25 = 12.75, nichts doppelt: ' + tot);
  assert.ok(!(await docBtn.isDisabled()), 'Dokumente möglich');
  assert.ok(dlgs.some((m) => m.includes('Hans Probe: In der App steht «Hat nicht gearbeitet». Abgeschickt wurden 3.25 h.')), 'Rückfrage bei «nicht gearbeitet»');
  // Nochmals holen: gleicher Stand, nichts doppelt
  dlgs.length = 0;
  await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.waitForTimeout(300);
  assert.ok((await page.locator('table.tbl tfoot').innerText()).includes('12.75'), 'wiederholtes Holen ohne Verdopplung');
  console.log('ok - erneutes Holen: übernimmt nach dem Abschicken, «offen» wird übersprungen, keine Verdopplung');
  // Erneutes Holen mit gleichem Stand: keine Rückfrage
  assert.strictEqual(dlgs.filter((m) => m.includes('überschreiben')).length, 0, 'keine Rückfrage bei gleichem Stand: ' + dlgs.join(' | '));
  // Kompakte Karte, Bearbeiten öffnet Tagesliste
  assert.strictEqual(await cardOf('Hans Probe').locator('input.hrs').count(), 0, 'Tagesliste zu');
  await cardOf('Hans Probe').getByRole('button', { name: 'Bearbeiten' }).click();
  assert.strictEqual(await cardOf('Hans Probe').locator('input.hrs').count(), 1, 'Tagesliste offen');
  // Von Hand ändern -> manuell; Hans öffnet wieder (offen) -> Holen lässt manuelle Stunden stehen, ohne Rückfrage
  await cardOf('Hans Probe').locator('input.hrs').first().fill('4'); await cardOf('Hans Probe').locator('input.hrs').first().blur();
  sheets.Abschluss.rows[2] = ['Hans Probe', ym, 3.25, 'x', 'offen', 2]; dlgs.length = 0;
  await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.getByText('deine manuell eingetragenen Stunden').waitFor();
  assert.ok((await cardOf('Hans Probe').innerText()).includes('1 Einsätze · 4.00 h'), 'manuelle Stunden bleiben');
  assert.strictEqual(dlgs.length, 0, 'keine Rückfrage bei nicht abgeschickt');
  assert.ok(!(await docBtn.isDisabled()), 'mit manuellen Stunden erstellbar');
  // Hans schickt ab (3.25) -> Rückfrage; Abbrechen behält 4.00
  sheets.Abschluss.rows[2] = ['Hans Probe', ym, 3.25, 'x', 'abgeschickt', 3]; dlgYes = false;
  await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.waitForTimeout(300);
  assert.ok(dlgs.length === 1 && dlgs[0].includes('Hans Probe: In der App stehen schon 4.00 h (1 Einsätze, manuell eingetragen). Abgeschickt wurden 3.25 h.'), 'Rückfrage: ' + dlgs.join(' | '));
  assert.ok((await cardOf('Hans Probe').innerText()).includes('4.00 h'), 'Abbrechen behält Stunden');
  assert.ok((await page.innerText('body')).includes('Hans Probe: Stunden von Hand geändert'), 'Abweichung zur Erfassung sichtbar');
  // nochmals, diesmal überschreiben
  dlgYes = true; dlgs.length = 0;
  await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.waitForTimeout(300);
  assert.strictEqual(dlgs.length, 1); assert.ok((await cardOf('Hans Probe').innerText()).includes('1 Einsätze · 3.25 h'), 'überschrieben');
  dlgs.length = 0; await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.waitForTimeout(300);
  assert.strictEqual(dlgs.length, 0, 'danach keine Rückfrage mehr');
  console.log('ok - kompakte Karte, Bearbeiten, manuelle Stunden bleiben, Rückfrage vor Überschreiben (Abbrechen/Überschreiben)');
  // Nicht abgeschickt ohne Stunden: Buttons «Manuell eintragen» (grün, links) und «Hat nicht gearbeitet» (ungefärbt, rechts)
  sheets.Abschluss.rows.splice(1, 1); dlgs.length = 0;
  await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.waitForTimeout(300);
  const bs = await cardOf('Anna Beispiel').locator('.row button').evaluateAll((els) => els.map((e) => e.textContent + '|' + e.className));
  assert.deepStrictEqual(bs, ['Manuell eintragen|btn', 'Hat nicht gearbeitet|btn sec'], 'Buttons: ' + bs);
  await cardOf('Anna Beispiel').getByRole('button', { name: 'Manuell eintragen' }).click();
  assert.strictEqual(await cardOf('Anna Beispiel').locator('input.hrs').count(), 1, 'Manuell eintragen öffnet Liste');
  // «Hat nicht gearbeitet» gesetzt, dann schickt die Person mit Stunden ab -> Rückfrage
  console.log('ok - Buttons bei nicht abgeschickten Personen');
  // Offline
  offline = true; await page.getByRole('button', { name: 'Stunden holen' }).click(); await page.getByText('Keine Verbindung').waitFor(); console.log('ok - ohne Netz verständliche Meldung');
  assert.deepStrictEqual(errs, [], 'keine Seitenfehler: ' + errs.join('|'));
  await browser.close();
})().catch((e) => { console.error('FEHLER:', e.message); process.exit(1); });
