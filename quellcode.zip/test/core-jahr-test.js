// Lesen der Jahrestabelle: Fehlerfälle (erfundene Personen)
const assert = require('assert'); const C = require('../src/core.js');
const P = [{ id: 'a', vorname: 'Anna', kurzname: 'Anna Beispiel', ahvAbzug: true }, { id: 'h', vorname: 'Hans', kurzname: 'Hans Probe', ahvAbzug: false }];
const H = ['Monat', 'Anna Brutto', 'Anna Netto', 'Hans Netto', 'Total Stunden'];
let r = C.parseYearSheet([H, ['Januar', 1000, 947, 500, 30], ['Total', 1000, 947, 500, 30]], P);
assert.deepStrictEqual(r.errors, []); assert.deepStrictEqual(r.months[1], { persons: { a: { hc: 0, bruttoC: 100000, nettoC: 94700 }, h: { hc: 0, bruttoC: 50000, nettoC: 50000 } }, hcTotal: 3000 });
assert.ok(!r.months[0], 'Totalzeile ignoriert');
assert.ok(/keine Kopfzeile/.test(C.parseYearSheet([['a', 'b']], P).errors[0]));
assert.ok(/Brutto» für Anna/.test(C.parseYearSheet([['Monat', 'Anna Netto', 'Hans Netto', 'Total Stunden']], P).errors.join()));
assert.ok(/Total Stunden/.test(C.parseYearSheet([['Monat', 'Anna Brutto', 'Anna Netto', 'Hans Netto']], P).errors.join()));
assert.ok(/zweimal/.test(C.parseYearSheet([H, ['Januar', 1, 1, 1, 1], ['Jan', 1, 1, 1, 1]], P).errors.join()));
assert.ok(/keine Zahl/.test(C.parseYearSheet([H, ['Januar', 'abc', 1, 1, 1]], P).errors.join()));
assert.ok(/keine Monate/.test(C.parseYearSheet([H, ['Januar', '', '', '', '']], P).errors.join()));
r = C.parseYearSheet([['Monat', 'Anna Brutto', 'Anna Netto', 'Hans Netto', 'Bemerkung', 'Total Stunden'], [{ m: 2 }, "1'000.50", 'CHF 947', '', 'x', '12.5']], P);
assert.deepStrictEqual(r.errors, []); assert.strictEqual(r.months[2].persons.a.bruttoC, 100050); assert.strictEqual(r.months[2].persons.a.nettoC, 94700); assert.ok(!r.months[2].persons.h, 'leere Zelle = nicht gearbeitet');
assert.ok(r.warnings.some((w) => /Bemerkung/.test(w))); assert.strictEqual(r.months[2].hcTotal, 1250);
// Tabelle der App: Kopf und Werte
const ys = C.yearSheet({ '2026-03': { persons: { a: { hc: 400, bruttoC: 15165, nettoC: 14360 } } }, '2026-01': { imported: true, hcTotal: 3000, persons: { h: { hc: 0, bruttoC: 50000, nettoC: 50000 } } } }, P, 2026);
assert.deepStrictEqual(ys.header, H); assert.deepStrictEqual(ys.rows[0], ['Januar', '', '', 500, 30]); assert.deepStrictEqual(ys.rows[2], ['März', 151.65, 143.6, '', 4]); assert.deepStrictEqual(ys.rows[1], ['Februar', '', '', '', '']);
console.log('ok - Jahrestabelle lesen/schreiben: Fehlerfälle, Formate, übernommene Monate');
