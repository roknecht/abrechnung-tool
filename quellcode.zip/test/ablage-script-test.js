// Test der Script-Ablage (Drive, Jahrestabelle, Gmail-Entwürfe) mit nachgebauten Google-Diensten und erfundenen Daten.
const assert = require('assert');
const { makeGoogle } = require('./google-mock');
const KEY = 'testkey-abruf-0123456789';
const pdf = (txt) => Buffer.from('%PDF-1.7\n' + (txt || 'x')).toString('base64');
const ok = (s) => console.log('ok -', s);

/* ---------- Schlüssel ---------- */
{
  const g = makeGoogle();
  for (const action of ['ablegen', 'jahr_lesen', 'jahr_schreiben', 'entwurf', 'sicherung']) {
    assert.strictEqual(g.post({ action, k: 'falsch-falsch-falsch', ordner: 'X', files: [] }).error, 'Abruf-Schlüssel ist falsch.', action);
    assert.strictEqual(g.post({ action }).ok, false);
  }
  assert.strictEqual(g.files.size, 1, 'nichts angelegt'); assert.strictEqual(g.drafts.length, 0);
  ok('alle Ablage-Aktionen nur mit richtigem Schlüssel');
}

/* ---------- Ablegen ---------- */
{
  const g = makeGoogle();
  const anna = g.folder('Anna Beispiel', g.main); g.folder('Hans Probe', g.main);
  // alte Datei mit gleichem Namen, aber in zerlegter Umlaut-Schreibweise (wie manche Geräte speichern)
  const nfd = '2026-10 Stundenübersicht Anna Beispiel.pdf'.normalize('NFD');
  const old = g.file(nfd, 'application/pdf', anna, []);
  const other = g.file('2026-09 Stundenübersicht Anna Beispiel.pdf', 'application/pdf', anna, []);
  const r = g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [
    { name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf('l') }, { name: '2026-10 Stundenübersicht Anna Beispiel.pdf', b64: pdf('s') }] });
  assert.ok(r.ok, JSON.stringify(r));
  assert.strictEqual(r.files[1].ersetzt, 1, 'alte Datei (NFD) ersetzt'); assert.strictEqual(r.files[0].ersetzt, 0);
  assert.ok(old._trashed, 'alte Version im Papierkorb'); assert.ok(!other._trashed, 'Vormonat bleibt');
  assert.deepStrictEqual(g.live(anna).map((f) => f._name).sort(), ['2026-09 Stundenübersicht Anna Beispiel.pdf', '2026-10 Lohnabrechnung Anna Beispiel.pdf', '2026-10 Stundenübersicht Anna Beispiel.pdf']);
  // nochmals ablegen: wieder genau eine Version
  g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf('l2') }] });
  assert.strictEqual(g.live(anna).filter((f) => f._name.startsWith('2026-10 Lohn')).length, 1, 'keine Doppel');
  ok('PDFs abgelegt, alte Version (auch mit anderer Umlaut-Schreibweise) im Papierkorb, Vormonat unberührt');

  const miss = g.post({ action: 'ablegen', k: KEY, ordner: 'Peter Test', files: [{ name: '2026-10 Lohnabrechnung Peter Test.pdf', b64: pdf() }] });
  assert.ok(!miss.ok && /keinen Ordner «Peter Test»/.test(miss.error)); assert.ok(![...g.folders.values()].some((f) => f._name === 'Peter Test'), 'kein Ordner still angelegt');
  ok('fehlender Personenordner: Abbruch mit Meldung, nichts angelegt');

  assert.ok(/Unerwarteter Dateiname/.test(g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: 'Sicherung.json', b64: pdf() }] }).error));
  assert.ok(/Unerwarteter Dateiname/.test(g.post({ action: 'ablegen', k: KEY, ordner: '', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }] }).error), 'Personen-PDF nicht in den Hauptordner');
  const n0 = g.live(anna).length;
  assert.ok(/Keine PDF-Datei/.test(g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: Buffer.from('hallo').toString('base64') }] }).error));
  assert.strictEqual(g.live(anna).length, n0, 'bei Fehler nichts ersetzt');
  const ids0 = g.live(anna).map((f) => f._id).join();
  assert.ok(!g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }, { name: '2026-10 Stundenübersicht Anna Beispiel.pdf', b64: Buffer.from('kaputt').toString('base64') }] }).ok);
  assert.strictEqual(g.live(anna).map((f) => f._id).join(), ids0, 'erste Datei nicht ersetzt, wenn zweite fehlerhaft');
  ok('falsche Dateinamen und Nicht-PDF abgewiesen, bestehende Datei bleibt');

  const jp = g.file('Jahresübersicht Löhne Assistenz 2026.pdf', 'application/pdf', g.main, []);
  const j = g.post({ action: 'ablegen', k: KEY, ordner: '', files: [{ name: 'Jahresübersicht Löhne Assistenz 2026.pdf', b64: pdf('j') }] });
  assert.ok(j.ok && j.files[0].ersetzt === 1 && jp._trashed);
  ok('Jahresübersicht-PDF im Hauptordner ersetzt');
}

/* ---------- Testmodus ---------- */
{
  const g = makeGoogle(); const real = g.folder('Anna Beispiel', g.main); const realFile = g.file('2026-10 Lohnabrechnung Anna Beispiel.pdf', 'application/pdf', real, []);
  const r = g.post({ action: 'ablegen', k: KEY, test: true, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }] });
  assert.ok(r.ok); assert.ok(!realFile._trashed, 'echter Ordner unberührt');
  const t = [...g.folders.values()].find((f) => f._name === '_TEST Beispieldaten');
  assert.ok(t && t._parent === g.main); const ta = [...g.folders.values()].find((f) => f._name === 'Anna Beispiel' && f._parent === t);
  assert.strictEqual(g.live(ta).length, 1);
  ok('Testmodus arbeitet nur im Ordner «_TEST Beispieldaten»');
}

/* ---------- falscher Hauptordner ---------- */
{
  const g = makeGoogle({ mainName: 'Anderer Ordner' });
  const r = g.post({ action: 'ablegen', k: KEY, ordner: '', files: [{ name: 'Jahresübersicht Löhne Assistenz 2026.pdf', b64: pdf() }] });
  assert.ok(!r.ok && /heisst nicht/.test(r.error)); assert.strictEqual(g.live(g.main).length, 1);
  ok('liegt die Stundentabelle nicht im richtigen Ordner: Abbruch');
}

/* ---------- Jahrestabelle ---------- */
const MON = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
{
  const g = makeGoogle();
  const header = ['Monat', 'Anna Brutto', 'Anna Netto', 'Hans Netto', 'Total Stunden'];
  const old = [header].concat(MON.map((m, i) => (i < 9 ? [m, 1000 + i, 947 + i, 500, 30 + i] : [m, '', '', '', '']))).concat([['Total', 9036, 8559, 4500, 306]]);
  const ss = g.spreadsheet('Jahresübersicht Löhne Assistenz 2026', g.main, old);
  g.spreadsheet('Jahresübersicht Löhne Assistenz 2025', g.main, [header]);
  const rd = g.post({ action: 'jahr_lesen', k: KEY, year: 2026 });
  assert.ok(rd.ok && rd.found && rd.values.length === 14 && rd.values[1][0] === 'Januar' && rd.values[9][1] === 1008);
  assert.strictEqual(g.post({ action: 'jahr_lesen', k: KEY, year: 2027 }).found, false);
  ok('Jahrestabelle lesen (gefunden / nicht vorhanden)');

  const rows = (filled) => MON.map((m, i) => (filled.includes(i) ? [m, 1000 + i, 947 + i, 500, 30 + i] : [m, '', '', '', '']));
  const before = JSON.stringify(ss._sheets[0].rows);
  const no = g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([9]) });
  assert.ok(!no.ok && /enthält 9 Monate, die App erst 1/.test(no.error), no.error);
  assert.strictEqual(JSON.stringify(ss._sheets[0].rows), before, 'nichts geändert');
  ok('Sicherung: weniger Monate als in der Tabelle -> nichts überschrieben');

  const yes = g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) });
  assert.ok(yes.ok && !yes.neu, JSON.stringify(yes));
  const s = ss._sheets[0];
  assert.strictEqual(s.rows[10][0], 'Oktober'); assert.strictEqual(s.rows[10][1], 1009);
  assert.strictEqual(s.formulas['14,2'], '=SUM(B2:B13)'); assert.strictEqual(s.formulas['14,5'], '=SUM(E2:E13)'); assert.strictEqual(s.rows[13][0], 'Total');
  assert.ok(!ss._file._trashed && g.live(g.main).filter((f) => f._name === 'Jahresübersicht Löhne Assistenz 2026').length === 1, 'gleiche Datei, kein Papierkorb');
  ok('Jahrestabelle in derselben Datei aktualisiert, Totals als Formel');

  assert.ok(!g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([1]).slice(0, 11) }).ok, '11 Zeilen abgewiesen');
  const bad = rows([0]); bad[0][1] = 'abc';
  assert.ok(!g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: bad }).ok, 'Text statt Zahl abgewiesen');
  const sw = rows([0]); [sw[0], sw[1]] = [sw[1], sw[0]];
  assert.ok(!g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: sw }).ok, 'falsche Monatsreihenfolge abgewiesen');

  const nw = g.post({ action: 'jahr_schreiben', k: KEY, year: 2027, header, rows: rows([0]) });
  assert.ok(nw.ok && nw.neu); const f27 = [...g.files.values()].find((f) => f._name === 'Jahresübersicht Löhne Assistenz 2027');
  assert.strictEqual(f27._parent, g.main, 'neue Tabelle im Hauptordner');
  ok('neue Jahrestabelle wird im Hauptordner angelegt; ungültige Daten abgewiesen');

  // Monate als Datum / Abkürzung in der bestehenden Tabelle werden erkannt
  const g2 = makeGoogle();
  const t2 = g2.spreadsheet('Jahresübersicht Löhne Assistenz 2026', g2.main, [header, [new Date(2026, 0, 1), 10, 9, 1, 1], ['Feb', 10, 9, 1, 1], ['Mär 2026', 10, 9, 1, 1], ['2026-04', 10, 9, 1, 1]]);
  const r2 = g2.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([0, 1, 2]) });
  assert.ok(!r2.ok && /enthält 4 Monate/.test(r2.error), r2.error); void t2;
  const l2 = g2.post({ action: 'jahr_lesen', k: KEY, year: 2026 }); assert.deepStrictEqual(l2.values[1][0], { m: 1 });
  ok('Monatsangaben als Datum, «Feb», «Mär 2026», «2026-04» werden gezählt');
}

/* ---------- Gmail-Entwürfe ---------- */
{
  const g = makeGoogle();
  const base = { action: 'entwurf', k: KEY, to: 'anna@beispiel.ch', cc: 'chef@beispiel.ch', subject: 'Lohnabrechnung Oktober 2026 / Anna Beispiel', body: 'Liebe Anna\n\nHier ist deine Lohnabrechnung vom Oktober mit der Stundenübersicht.\n\nVielen Dank für deine Unterstützung! ❤️\n\nLiebe Grüsse\nRoger',
    files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }, { name: '2026-10 Stundenübersicht Anna Beispiel.pdf', b64: pdf() }] };
  const r = g.post(base); assert.ok(r.ok, JSON.stringify(r));
  const d = g.drafts[0];
  assert.strictEqual(d.to, 'anna@beispiel.ch'); assert.strictEqual(d.cc, 'chef@beispiel.ch'); assert.strictEqual(d.attachments.length, 2); assert.ok(d.body.includes('❤️'));
  g.drafts.push({ _id: 'alt', subject: 'Anderes', getMessageId: () => 'malt', getMessage: () => ({ getSubject: () => 'Anderes' }), deleteDraft() { this._deleted = true; } });
  // ein Entwurf mit ähnlichem, aber nicht gleichem Betreff bleibt
  g.ctx.GmailApp.createDraft('x@beispiel.ch', base.subject + ' (Kopie)', 'x', {});
  const r2 = g.post(base); assert.ok(r2.ok && r2.ersetzt === 1, JSON.stringify(r2));
  assert.strictEqual(g.ctx.GmailApp._calls(), 0, 'Entwürfe werden nicht einzeln geöffnet (schnell)');
  assert.ok(g.ctx.GmailApp.getDrafts().some((d) => d.subject === base.subject + ' (Kopie)'), 'ähnlicher Betreff bleibt');
  assert.strictEqual(g.ctx.GmailApp.getDrafts().filter((x) => x.subject === base.subject).length, 1, 'kein doppelter Entwurf'); assert.ok(!g.drafts.find((x) => x._id === 'alt')._deleted, 'andere Entwürfe bleiben');
  ok('Gmail-Entwurf mit 2 PDFs und CC, erneutes Erstellen ersetzt nur den gleichen Entwurf');

  assert.ok(/E-Mail-Adresse/.test(g.post(Object.assign({}, base, { to: '' })).error));
  assert.ok(/CC-Adresse/.test(g.post(Object.assign({}, base, { cc: 'kaputt' })).error));
  assert.ok(/Betreff/.test(g.post(Object.assign({}, base, { subject: 'Hallo' })).error));
  assert.ok(/Anhang|Anhänge/.test(g.post(Object.assign({}, base, { files: [] })).error));
  assert.ok(/Unerwarteter Anhang/.test(g.post(Object.assign({}, base, { files: [{ name: 'x.pdf', b64: pdf() }] })).error));
  assert.ok(/nur Adressen @example.com/.test(g.post(Object.assign({}, base, { test: true })).error), 'Testmodus nur example.com');
  const t = g.post(Object.assign({}, base, { test: true, to: 'anna@example.com', cc: 'max@example.com' }));
  assert.ok(t.ok && t.subject.startsWith('[TEST] '));
  ok('Entwurf: ungültige Adresse/Betreff/Anhang abgewiesen; Testmodus nur @example.com mit [TEST]');
  assert.ok(!('sendEmail' in g.ctx.GmailApp), 'kein Versand möglich');
}

/* ---------- Senden ---------- */
{
  const files = [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }, { name: '2026-10 Stundenübersicht Anna Beispiel.pdf', b64: pdf() }];
  const mk = (g, o) => g.post(Object.assign({ action: 'entwurf', k: KEY, to: 'anna@beispiel.ch', cc: 'chef@beispiel.ch', subject: 'Lohnabrechnung Oktober 2026 / Anna Beispiel', body: 'Liebe Anna', files }, o || {}));
  // ohne Liste erlaubter Empfänger: nichts senden
  let g = makeGoogle();
  let e = mk(g); assert.ok(e.ok);
  let s = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(!s.ok && /nicht in der Liste der erlaubten Empfänger/.test(s.error), s.error); assert.strictEqual(g.sent.length, 0);
  assert.strictEqual(g.post({ action: 'senden', k: 'falsch-falsch-falsch', draftId: e.id }).error, 'Abruf-Schlüssel ist falsch.');
  // nur Empfänger erlaubt, CC nicht -> nichts senden
  g = makeGoogle({ props: { ERLAUBTE_EMPFAENGER: 'Anna@Beispiel.ch' } });
  e = mk(g); s = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(!s.ok && /chef@beispiel\.ch/.test(s.error)); assert.strictEqual(g.sent.length, 0);
  ok('Senden: ohne bzw. mit unvollständiger Empfängerliste wird nichts gesendet');
  // alles erlaubt -> gesendet, danach nicht nochmals
  g = makeGoogle({ props: { ERLAUBTE_EMPFAENGER: 'anna@beispiel.ch, chef@beispiel.ch' } });
  e = mk(g); s = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(s.ok && s.gesendet, JSON.stringify(s)); assert.strictEqual(g.sent.length, 1);
  const again = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(!again.ok && /nicht gefunden/.test(again.error)); assert.strictEqual(g.sent.length, 1);
  ok('Senden an erlaubte Empfänger; zweites Senden desselben Entwurfs unmöglich');
  // fremder Entwurf (anderer Betreff / ohne PDF) wird nicht gesendet
  const fremd = g.ctx.GmailApp.createDraft('anna@beispiel.ch', 'Hallo', 'x', {});
  assert.ok(/Betreff/.test(g.post({ action: 'senden', k: KEY, draftId: fremd.getId() }).error));
  const ohne = g.ctx.GmailApp.createDraft('anna@beispiel.ch', 'Lohnabrechnung Oktober 2026 / Anna Beispiel', 'x', {});
  assert.ok(/Anhänge fehlen/.test(g.post({ action: 'senden', k: KEY, draftId: ohne.getId() }).error));
  const falsch = g.ctx.GmailApp.createDraft('anna@beispiel.ch', 'Lohnabrechnung Oktober 2026 / Anna Beispiel', 'x', { attachments: [{ name: 'virus.exe', mime: 'application/octet-stream' }] });
  assert.ok(/Unerwarteter Anhang/.test(g.post({ action: 'senden', k: KEY, draftId: falsch.getId() }).error));
  const bcc = mk(g); g.drafts.find((d) => d._id === bcc.id).bcc = 'fremd@boese.ch';
  assert.ok(/fremd@boese\.ch/.test(g.post({ action: 'senden', k: KEY, draftId: bcc.id }).error), 'BCC wird geprüft');
  assert.strictEqual(g.sent.length, 1);
  ok('Senden: fremde Entwürfe, falsche Anhänge und BCC an Unbekannte werden abgewiesen');
  // eigene Adresse ist immer erlaubt; Testmodus
  g = makeGoogle({ owner: 'roger@beispiel.ch' });
  e = mk(g, { to: 'roger@beispiel.ch', cc: '' }); s = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(s.ok && s.gesendet);
  e = mk(g, { test: true, to: 'anna@example.com', cc: 'max@example.com' }); assert.ok(e.ok);
  s = g.post({ action: 'senden', k: KEY, draftId: e.id, test: true });
  assert.ok(s.ok && s.simuliert && !s.gesendet); assert.strictEqual(g.sent.length, 1, '@example.com wird im Test nur simuliert');
  e = mk(g, { test: true, to: 'roger@beispiel.ch', cc: 'roger@beispiel.ch' }); assert.ok(e.ok, JSON.stringify(e));
  s = g.post({ action: 'senden', k: KEY, draftId: e.id, test: true }); assert.ok(s.ok && s.gesendet); assert.strictEqual(g.sent.length, 2);
  assert.ok(!g.post({ action: 'senden', k: KEY, draftId: mk(g).id, test: true }).ok, 'Testmodus sendet keine echten Lohnabrechnungen');
  ok('Senden: eigene Adresse erlaubt; Testmodus simuliert @example.com und sendet echt nur an die eigene Adresse');
}

/* ---------- Sicherung ---------- */
{
  const g = makeGoogle();
  const name = 'Sicherung Abrechnung 2026-11-01.json';
  const vault = JSON.stringify({ v: 1, salt: 'c2FsdA==', iter: 250000, iv: 'aXY=', ct: 'Y3Q=' });
  const alt1 = g.file('Sicherung Abrechnung 2026-10-01.json', 'application/json', g.main, []);
  const alt2 = g.file('Sicherung Abrechnung 2026-10-22 (1).json', 'application/json', g.main, []);
  const fremd = g.file('Notizen.json', 'application/json', g.main, []);
  const anna = g.folder('Anna Beispiel', g.main); const inPerson = g.file('Sicherung Abrechnung 2026-09-01.json', 'application/json', anna, []);
  const n0 = g.files.size;
  assert.strictEqual(g.post({ action: 'sicherung', k: 'falsch-falsch-falsch', name, inhalt: vault }).error, 'Abruf-Schlüssel ist falsch.');
  assert.ok(/Unerwarteter Dateiname/.test(g.post({ action: 'sicherung', k: KEY, name: 'Notizen.json', inhalt: vault }).error));
  assert.ok(/Unerwarteter Dateiname/.test(g.post({ action: 'sicherung', k: KEY, name: 'Sicherung Abrechnung 2026-11-01.pdf', inhalt: vault }).error));
  for (const bad of ['', 'kein json', '[]', JSON.stringify({ persons: [{ name: 'Anna Beispiel' }] }), JSON.stringify({ v: 1, salt: 'a', iter: 1, iv: 'b', ct: 'c', klartext: 'x' }), JSON.stringify({ v: 1, salt: 'a', iter: 1, iv: 'b', ct: { name: 'x' } })]) {
    assert.strictEqual(g.post({ action: 'sicherung', k: KEY, name, inhalt: bad }).ok, false, 'abgelehnt: ' + bad);
  }
  assert.strictEqual(g.files.size, n0, 'bei Fehlern nichts angelegt'); assert.ok(!alt1._trashed && !alt2._trashed);
  const r = g.post({ action: 'sicherung', k: KEY, name, inhalt: vault });
  assert.ok(r.ok, JSON.stringify(r)); assert.strictEqual(r.ersetzt, 2); assert.strictEqual(r.ordner, g.main.getName());
  assert.ok(alt1._trashed && alt2._trashed, 'ältere Sicherungen im Papierkorb'); assert.ok(!fremd._trashed, 'andere Dateien bleiben'); assert.ok(!inPerson._trashed, 'nur im Hauptordner');
  let live = g.live(g.main).filter((f) => /^Sicherung/.test(f._name));
  assert.strictEqual(live.length, 1); assert.strictEqual(live[0]._name, name); assert.strictEqual(live[0]._mime, 'application/json'); assert.strictEqual(live[0]._bytes, vault);
  const r2 = g.post({ action: 'sicherung', k: KEY, name, inhalt: vault });
  assert.strictEqual(r2.ersetzt, 1, 'gleicher Tag: ersetzt'); assert.strictEqual(g.live(g.main).filter((f) => /^Sicherung/.test(f._name)).length, 1);
  const r3 = g.post({ action: 'sicherung', k: KEY, name, inhalt: vault, test: true });
  assert.ok(r3.ok); assert.strictEqual(r3.ordner, '_TEST Beispieldaten'); assert.strictEqual(r3.ersetzt, 0);
  assert.strictEqual(g.live(g.main).filter((f) => /^Sicherung/.test(f._name)).length, 1, 'Test berührt echte Sicherung nicht');
  ok('Sicherung: nur verschlüsselt, richtiger Name, im Hauptordner; ältere in den Papierkorb; Testmodus nur im Testordner');
}

/* ---------- Erfassungsseite unverändert ---------- */
{
  const { makeGoogle: mg } = require('./google-mock');
  const tok = 't'.repeat(20);
  const mkS = (rows) => ({ rows, getDataRange: () => ({ getValues: () => rows.map((r) => r.slice()) }), getLastRow: () => rows.length,
    getRange: (r, c, nr = 1, nc = 1) => ({ getValues: () => { const o = []; for (let i = 0; i < nr; i++) { const row = []; for (let j = 0; j < nc; j++) row.push((rows[r - 1 + i] || [])[c - 1 + j] ?? ''); o.push(row); } return o; }, setValues() {}, setNumberFormat() {} }) });
  const g = mg({ erfassungSheets: { Personen: mkS([['Token', 'Name', 'aktiv'], [tok, 'Anna Beispiel', '']]), Stunden: mkS([['Name', 'Datum', 'Dauer', 'Geändert'], ['Anna Beispiel', '2026-09-02', 4.5, 'x']]), Abschluss: mkS([['Name', 'Monat', 'Total', 'Zeitpunkt', 'Status', 'Anzahl']]) } });
  assert.strictEqual(g.get({ t: tok, m: '2026-09' }).entries['2026-09-02'], 4.5);
  assert.ok(g.get({ action: 'export', k: KEY, m: '2026-09' }).csv.includes('Anna Beispiel,2026-09-02,4.5'));
  ok('Erfassungsseite und «Stunden holen» funktionieren unverändert');
}
console.log('ALLE SCRIPT-TESTS OK');
