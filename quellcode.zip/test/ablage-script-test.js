// Test der Script-Ablage (Drive, Jahrestabelle, Gmail-Entwürfe) mit nachgebauten Google-Diensten und erfundenen Daten.
const assert = require('assert');
const { makeGoogle } = require('./google-mock');
const KEY = 'testkey-abruf-0123456789';
const pdf = (txt) => Buffer.from('%PDF-1.7\n' + (txt || 'x')).toString('base64');
const ok = (s) => console.log('ok -', s);
const MON = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

/* ---------- Schlüssel ---------- */
{
  const g = makeGoogle();
  for (const action of ['ablegen', 'jahr_lesen', 'jahr_schreiben', 'entwurf', 'sicherung']) {
    assert.strictEqual(g.post({ action, k: 'falsch-falsch-falsch', ordner: 'X', files: [] }).error, 'Abruf-Schlüssel ist falsch.', action);
    assert.strictEqual(g.post({ action }).ok, false);
  }
  assert.strictEqual(g.files.size, 1, 'nichts angelegt'); assert.strictEqual(g.drafts.length, 0);
  ok('alle Ablage-Aktionen nur mit richtigem Schlüssel');
}

/* ---------- Ablegen (nach Jahren: Hauptordner/JJJJ/[Kurzname]) ---------- */
const personen = (names) => ({ Personen: { getDataRange: () => ({ getValues: () => [['Token', 'Name', 'aktiv']].concat(names.map((n, i) => ['tok' + i, n, ''])) }) } });
const sub = (g, parent, name) => [...g.folders.values()].find((f) => f._parent === parent && f._name === name && !f._trashed);
{
  const g = makeGoogle({ erfassungSheets: personen(['Anna Beispiel', 'Hans Probe', 'Zoë Müller']) });
  const y26 = g.folder('2026', g.main); const anna = g.folder('Anna Beispiel', y26);
  // alte Datei mit gleichem Namen, aber in zerlegter Umlaut-Schreibweise (wie manche Geräte speichern)
  const nfd = '2026-10 Stundenübersicht Anna Beispiel.pdf'.normalize('NFD');
  const old = g.file(nfd, 'application/pdf', anna, []);
  const other = g.file('2026-09 Stundenübersicht Anna Beispiel.pdf', 'application/pdf', anna, []);
  const r = g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [
    { name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf('l') }, { name: '2026-10 Stundenübersicht Anna Beispiel.pdf', b64: pdf('s') }] });
  assert.ok(r.ok, JSON.stringify(r)); assert.strictEqual(r.ordner, '2026 / Anna Beispiel');
  assert.strictEqual(r.files[1].ersetzt, 1, 'alte Datei (NFD) ersetzt'); assert.strictEqual(r.files[0].ersetzt, 0);
  assert.ok(old._trashed, 'alte Version im Papierkorb'); assert.ok(!other._trashed, 'Vormonat bleibt');
  assert.deepStrictEqual(g.live(anna).map((f) => f._name).sort(), ['2026-09 Stundenübersicht Anna Beispiel.pdf', '2026-10 Lohnabrechnung Anna Beispiel.pdf', '2026-10 Stundenübersicht Anna Beispiel.pdf']);
  g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf('l2') }] });
  assert.strictEqual(g.live(anna).filter((f) => f._name.startsWith('2026-10 Lohn')).length, 1, 'keine Doppel');
  ok('PDFs in «2026 / Person» abgelegt, alte Version (auch andere Umlaut-Schreibweise) im Papierkorb, Vormonat unberührt');

  // Personenordner im Jahresordner fehlt: wird angelegt, wenn der Name im Blatt «Personen» steht (auch mit Umlaut in anderer Schreibweise)
  const h = g.post({ action: 'ablegen', k: KEY, ordner: 'Hans Probe', files: [{ name: '2026-10 Lohnabrechnung Hans Probe.pdf', b64: pdf() }] });
  assert.ok(h.ok && h.ordner === '2026 / Hans Probe', JSON.stringify(h)); assert.strictEqual(g.live(sub(g, y26, 'Hans Probe')).length, 1);
  const z = g.post({ action: 'ablegen', k: KEY, ordner: 'Zoë Müller'.normalize('NFD'), files: [{ name: '2026-10 Lohnabrechnung Zoë Müller.pdf', b64: pdf() }] });
  assert.ok(z.ok, JSON.stringify(z)); assert.ok(sub(g, y26, 'Zoë Müller'), 'Ordner in NFC angelegt');
  ok('fehlender Personenordner im Jahr wird angelegt, wenn der Name im Blatt «Personen» steht');

  const nF = g.folders.size;
  const miss = g.post({ action: 'ablegen', k: KEY, ordner: 'Peter Test', files: [{ name: '2027-01 Lohnabrechnung Peter Test.pdf', b64: pdf() }] });
  assert.ok(!miss.ok && /«Peter Test» gibt es im Blatt «Personen»/.test(miss.error) && /nichts abgelegt/.test(miss.error), miss.error);
  assert.strictEqual(g.folders.size, nF, 'weder Jahres- noch Personenordner angelegt');
  ok('unbekannter Kurzname: Abbruch mit Meldung, kein Ordner angelegt (auch kein neuer Jahresordner)');

  assert.ok(/Unerwarteter Dateiname/.test(g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: 'Sicherung.json', b64: pdf() }] }).error));
  assert.ok(/Unerwarteter Dateiname/.test(g.post({ action: 'ablegen', k: KEY, ordner: '', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }] }).error), 'Personen-PDF nicht als Jahresübersicht');
  assert.ok(/verschiedenen Jahren/.test(g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-12 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }, { name: '2027-01 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }] }).error));
  assert.ok(/Jahr im Dateinamen ungültig/.test(g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '1999-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }] }).error));
  assert.ok(/Ungültiger Ordnername/.test(g.post({ action: 'ablegen', k: KEY, ordner: '2026', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }] }).error));
  const n0 = g.live(anna).length;
  assert.ok(/Keine PDF-Datei/.test(g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: Buffer.from('hallo').toString('base64') }] }).error));
  assert.strictEqual(g.live(anna).length, n0, 'bei Fehler nichts ersetzt');
  const ids0 = g.live(anna).map((f) => f._id).join();
  assert.ok(!g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }, { name: '2026-10 Stundenübersicht Anna Beispiel.pdf', b64: Buffer.from('kaputt').toString('base64') }] }).ok);
  assert.strictEqual(g.live(anna).map((f) => f._id).join(), ids0, 'erste Datei nicht ersetzt, wenn zweite fehlerhaft');
  const nF2 = g.folders.size;
  assert.ok(!g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2028-01 Lohnabrechnung Anna Beispiel.pdf', b64: Buffer.from('kaputt').toString('base64') }] }).ok);
  assert.strictEqual(g.folders.size, nF2, 'kaputte Datei: kein Jahresordner angelegt');
  ok('falsche Dateinamen, gemischte Jahre und Nicht-PDF abgewiesen, bestehende Datei bleibt, kein Ordner angelegt');

  const jp = g.file('Jahresübersicht Löhne Assistenz 2026.pdf', 'application/pdf', y26, []);
  const j = g.post({ action: 'ablegen', k: KEY, ordner: '', files: [{ name: 'Jahresübersicht Löhne Assistenz 2026.pdf', b64: pdf('j') }] });
  assert.ok(j.ok && j.files[0].ersetzt === 1 && jp._trashed && j.ordner === '2026', JSON.stringify(j));
  assert.strictEqual(g.live(y26).filter((f) => f._name === 'Jahresübersicht Löhne Assistenz 2026.pdf').length, 1);
  ok('Jahresübersicht-PDF im Ordner «2026» ersetzt');
}

/* ---------- Jahreswechsel und frühere Ablage ---------- */
{
  const g = makeGoogle({ erfassungSheets: personen(['Anna Beispiel', 'Hans Probe']) });
  // frühere Ablage: Personenordner und Jahres-PDF direkt im Hauptordner
  const altAnna = g.folder('Anna Beispiel', g.main);
  const altOkt = g.file('2026-10 Lohnabrechnung Anna Beispiel.pdf', 'application/pdf', altAnna, []);
  const altSep = g.file('2026-09 Lohnabrechnung Anna Beispiel.pdf', 'application/pdf', altAnna, []);
  const altJp = g.file('Jahresübersicht Löhne Assistenz 2026.pdf', 'application/pdf', g.main, []);
  // Korrektur Oktober 2026 nach der Umstellung: neue Datei im Jahresordner, alte gleichnamige aus der früheren Ablage im Papierkorb
  const k = g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf('k') }] });
  assert.ok(k.ok && k.files[0].ersetzt === 1 && altOkt._trashed && !altSep._trashed, JSON.stringify(k));
  const y26 = sub(g, g.main, '2026'); assert.strictEqual(g.live(sub(g, y26, 'Anna Beispiel')).length, 1);
  const jj = g.post({ action: 'ablegen', k: KEY, ordner: '', files: [{ name: 'Jahresübersicht Löhne Assistenz 2026.pdf', b64: pdf() }] });
  assert.ok(jj.ok && jj.files[0].ersetzt === 1 && altJp._trashed);
  ok('Korrektur nach der Umstellung: gleichnamige Datei aus der früheren Ablage kommt in den Papierkorb, nichts doppelt');

  // Dezember 2026 (abgerechnet im Januar 2027) -> 2026; Januar 2027 -> neuer Ordner 2027
  assert.strictEqual(g.post({ action: 'ablegen', k: KEY, ordner: 'Hans Probe', files: [{ name: '2026-12 Lohnabrechnung Hans Probe.pdf', b64: pdf() }, { name: '2026-12 Stundenübersicht Hans Probe.pdf', b64: pdf() }] }).ordner, '2026 / Hans Probe');
  const j27 = g.post({ action: 'ablegen', k: KEY, ordner: 'Hans Probe', files: [{ name: '2027-01 Lohnabrechnung Hans Probe.pdf', b64: pdf() }] });
  assert.strictEqual(j27.ordner, '2027 / Hans Probe'); const y27 = sub(g, g.main, '2027');
  assert.ok(y27 && g.live(sub(g, y27, 'Hans Probe')).length === 1 && g.live(sub(g, y26, 'Hans Probe')).length === 2);
  assert.strictEqual(g.post({ action: 'ablegen', k: KEY, ordner: '', files: [{ name: 'Jahresübersicht Löhne Assistenz 2027.pdf', b64: pdf() }] }).ordner, '2027');
  assert.strictEqual(g.live(y27).length, 1, 'Jahres-PDF 2027 im Ordner 2027');
  assert.strictEqual([...g.folders.values()].filter((f) => f._name === '2027').length, 1, 'genau ein Ordner 2027');
  ok('Jahreswechsel: Dezember in «2026», Januar in neuen Ordner «2027» (automatisch angelegt)');
}

/* ---------- Einmalige Einrichtung: bestehende Dateien in die Jahresordner ---------- */
{
  const g = makeGoogle({ erfassungSheets: personen(['Anna Beispiel', 'Hans Probe', 'Zoë Müller']) });
  const sich = g.file('Sicherung Abrechnung 2026-11-01.json', 'application/json', g.main, []);
  const tab = g.spreadsheet('Jahresübersicht Löhne Assistenz 2026', g.main, [['Monat']]);
  const jpdf = g.file('Jahresübersicht Löhne Assistenz 2026.pdf', 'application/pdf', g.main, []);
  const notiz = g.file('Notizen.txt', 'text/plain', g.main, []);
  const anna = g.folder('Anna Beispiel', g.main), hans = g.folder('Hans Probe', g.main), zoe = g.folder('Zoë Müller'.normalize('NFD'), g.main);
  const muster = g.folder('Muster alt', g.main); const musterFile = g.file('2025-12 Lohnabrechnung Muster.pdf', 'application/pdf', muster, []);
  const testF = g.folder('_TEST Beispieldaten', g.main); const testFile = g.file('2026-10 Lohnabrechnung Anna Beispiel.pdf', 'application/pdf', testF, []);
  const a9 = g.file('2026-09 Lohnabrechnung Anna Beispiel.pdf', 'application/pdf', anna, []);
  const a9alt = g.file('2026-09 Lohnabrechnung Anna Alt.pdf', 'application/pdf', anna, []); // alter Kurzname, gleiches Muster
  const a10 = g.file('2026-10 Stundenübersicht Anna Beispiel.pdf'.normalize('NFD'), 'application/pdf', anna, []);
  const a25 = g.file('2025-12 Lohnabrechnung Anna Beispiel.pdf', 'application/pdf', anna, []);
  const aOdd = g.file('Lohnabrechnung_Anna_08-2025.pdf', 'application/pdf', anna, []);
  const h10 = g.file('2026-10 Lohnabrechnung Hans Probe.pdf', 'application/pdf', hans, []);
  const z10 = g.file('2026-10 Lohnabrechnung Zoë Müller.pdf', 'application/pdf', zoe, []);
  const snap = () => [...g.files.values()].map((f) => f._id + ':' + (f._parent && f._parent._id) + ':' + f._trashed).join() + [...g.folders.values()].map((f) => f._id + ':' + f._trashed).join();

  const before = snap(); const nFo = g.folders.size;
  const pr = g.ctx.jahresordnerPruefen();
  assert.strictEqual(snap(), before, 'Prüfen verändert nichts'); assert.strictEqual(g.folders.size, nFo, 'Prüfen legt keinen Ordner an');
  assert.strictEqual(pr.verschoben, 8, pr.log.join('\n')); assert.ok(pr.log.some((l) => /Lohnabrechnung_Anna_08-2025\.pdf/.test(l) && /BLEIBT/.test(l)));
  assert.ok(pr.log.some((l) => /Muster alt.*bleibt unverändert/.test(l)));
  ok('«jahresordnerPruefen» zeigt nur an, verändert nichts');

  const ids = [tab._file, jpdf, a9, a10, h10].map((f) => f._id);
  const r = g.ctx.jahresordnerEinrichten();
  assert.strictEqual(r.verschoben, 8, r.log.join('\n'));
  const y26 = sub(g, g.main, '2026'), y25 = sub(g, g.main, '2025');
  assert.strictEqual(tab._file._parent, y26); assert.strictEqual(jpdf._parent, y26);
  const a26 = sub(g, y26, 'Anna Beispiel');
  assert.deepStrictEqual(g.live(a26).map((f) => f._name.normalize('NFC')).sort(), ['2026-09 Lohnabrechnung Anna Alt.pdf', '2026-09 Lohnabrechnung Anna Beispiel.pdf', '2026-10 Stundenübersicht Anna Beispiel.pdf']);
  assert.strictEqual(a25._parent, sub(g, y25, 'Anna Beispiel'), '2025 in Ordner 2025');
  assert.strictEqual(h10._parent, sub(g, y26, 'Hans Probe')); assert.strictEqual(z10._parent, sub(g, y26, 'Zoë Müller'), 'NFD-Ordnername erkannt');
  assert.deepStrictEqual([tab._file, jpdf, a9, a10, h10].map((f) => f._id), ids, 'gleiche Dateien (Links bleiben)');
  assert.ok(![tab._file, jpdf, a9, a9alt, a10, a25, h10, z10].some((f) => f._trashed), 'nichts im Papierkorb');
  assert.strictEqual(aOdd._parent, anna, 'fremder Dateiname bleibt'); assert.ok(!anna._trashed, 'Ordner mit verbleibender Datei bleibt');
  assert.ok(hans._trashed && zoe._trashed, 'leere alte Personenordner im Papierkorb');
  assert.ok(sich._parent === g.main && !sich._trashed && notiz._parent === g.main, 'Sicherung und andere Dateien bleiben im Hauptordner');
  assert.ok(musterFile._parent === muster && !muster._trashed && testFile._parent === testF && !testF._trashed, 'fremde Ordner und Testordner unberührt');
  ok('«jahresordnerEinrichten»: Dateien in «Jahr / Person», Links bleiben, Unbekanntes bleibt, leere alte Ordner in den Papierkorb');

  const before2 = snap(); const r2 = g.ctx.jahresordnerEinrichten();
  assert.strictEqual(r2.verschoben, 0); assert.strictEqual(snap(), before2, 'zweiter Lauf ändert nichts');
  // gleicher Name schon im Ziel: wird übersprungen, nicht überschrieben
  const dup = g.file('2026-09 Lohnabrechnung Anna Beispiel.pdf', 'application/pdf', anna, []);
  const r3 = g.ctx.jahresordnerEinrichten();
  assert.strictEqual(r3.verschoben, 0); assert.strictEqual(dup._parent, anna); assert.ok(!dup._trashed && !a9._trashed);
  assert.ok(r3.log.some((l) => /ÜBERSPRUNGEN/.test(l)));
  ok('zweiter Lauf ändert nichts; gleicher Name im Ziel wird übersprungen, nichts überschrieben');

  // danach normal weiterarbeiten
  const w = g.post({ action: 'ablegen', k: KEY, ordner: 'Anna Beispiel', files: [{ name: '2026-11 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }] });
  assert.ok(w.ok && w.ordner === '2026 / Anna Beispiel');
  const js = g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header: ['Monat', 'Anna Netto', 'Total Stunden'], rows: MON.map((m, i) => (i === 10 ? [m, 100, 4] : [m, '', ''])) });
  assert.ok(js.ok && !js.neu, JSON.stringify(js)); assert.strictEqual(tab._file._parent, y26);
  ok('nach der Einrichtung: Ablage und Jahrestabelle funktionieren normal');
}

/* ---------- Testmodus ---------- */
{
  const g = makeGoogle(); const real = g.folder('Anna Beispiel', g.main); const realFile = g.file('2026-10 Lohnabrechnung Anna Beispiel.pdf', 'application/pdf', real, []);
  const r = g.post({ action: 'ablegen', k: KEY, test: true, ordner: 'Anna Beispiel', files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }] });
  assert.ok(r.ok, JSON.stringify(r)); assert.ok(!realFile._trashed, 'echter Ordner unberührt');
  const t = [...g.folders.values()].find((f) => f._name === '_TEST Beispieldaten');
  assert.ok(t && t._parent === g.main); const ta = sub(g, sub(g, t, '2026'), 'Anna Beispiel');
  assert.strictEqual(g.live(ta).length, 1); assert.ok(!sub(g, g.main, '2026'), 'kein echter Jahresordner');
  ok('Testmodus arbeitet nur im Ordner «_TEST Beispieldaten» (mit eigenen Jahresordnern)');
}

/* ---------- falscher Hauptordner ---------- */
{
  const g = makeGoogle({ mainName: 'Anderer Ordner' });
  const r = g.post({ action: 'ablegen', k: KEY, ordner: '', files: [{ name: 'Jahresübersicht Löhne Assistenz 2026.pdf', b64: pdf() }] });
  assert.ok(!r.ok && /heisst nicht/.test(r.error)); assert.strictEqual(g.live(g.main).length, 1);
  ok('liegt die Stundentabelle nicht im richtigen Ordner: Abbruch');
}

/* ---------- Jahrestabelle ---------- */
{
  const g = makeGoogle();
  const header = ['Monat', 'Anna Brutto', 'Anna Netto', 'Hans Netto', 'Total Stunden'];
  const old = [header].concat(MON.map((m, i) => (i < 9 ? [m, 1000 + i, 947 + i, 500, 30 + i] : [m, '', '', '', '']))).concat([['Total', 9036, 8559, 4500, 306]]);
  // 2026 liegt noch an der früheren Stelle (Hauptordner), 2025 schon im Jahresordner
  const ss = g.spreadsheet('Jahresübersicht Löhne Assistenz 2026', g.main, old);
  g.spreadsheet('Jahresübersicht Löhne Assistenz 2025', g.folder('2025', g.main), [header]);
  assert.ok(g.post({ action: 'jahr_lesen', k: KEY, year: 2025 }).found, '2025 im Jahresordner gefunden');
  const rd = g.post({ action: 'jahr_lesen', k: KEY, year: 2026 });
  assert.ok(rd.ok && rd.found && rd.values.length === 14 && rd.values[1][0] === 'Januar' && rd.values[9][1] === 1008);
  assert.strictEqual(g.post({ action: 'jahr_lesen', k: KEY, year: 2027 }).found, false);
  ok('Jahrestabelle lesen (gefunden / nicht vorhanden)');

  const rows = (filled) => MON.map((m, i) => (filled.includes(i) ? [m, 1000 + i, 947 + i, 500, 30 + i] : [m, '', '', '', '']));
  const before = JSON.stringify(ss._sheets[0].rows);
  const no = g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([9]) });
  assert.ok(!no.ok && /enthält 9 Monate, die App erst 1/.test(no.error), no.error);
  assert.strictEqual(JSON.stringify(ss._sheets[0].rows), before, 'nichts geändert');
  assert.strictEqual(ss._file._parent, g.main, 'abgewiesen: Tabelle nicht verschoben');
  ok('Sicherung: weniger Monate als in der Tabelle -> nichts überschrieben');

  const yes = g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]) });
  assert.ok(yes.ok && !yes.neu, JSON.stringify(yes));
  const s = ss._sheets[0];
  assert.strictEqual(s.rows[10][0], 'Oktober'); assert.strictEqual(s.rows[10][1], 1009);
  assert.strictEqual(s.formulas['14,2'], '=SUM(B2:B13)'); assert.strictEqual(s.formulas['14,5'], '=SUM(E2:E13)'); assert.strictEqual(s.rows[13][0], 'Total');
  const f26 = sub(g, g.main, '2026');
  assert.ok(!ss._file._trashed && ss._file._parent === f26, 'gleiche Datei (gleicher Link), jetzt im Ordner 2026');
  assert.strictEqual([...g.files.values()].filter((f) => f._name === 'Jahresübersicht Löhne Assistenz 2026' && !f._trashed).length, 1, 'keine zweite Tabelle');
  const again = g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]) });
  assert.ok(again.ok && !again.neu && ss._sheets[0].rows[11][1] === 1010, 'zweites Schreiben findet sie im Ordner 2026');
  ok('Jahrestabelle in derselben Datei aktualisiert (aus dem Hauptordner in «2026» verschoben, Link bleibt), Totals als Formel');

  assert.ok(!g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([1]).slice(0, 11) }).ok, '11 Zeilen abgewiesen');
  const bad = rows([0]); bad[0][1] = 'abc';
  assert.ok(!g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: bad }).ok, 'Text statt Zahl abgewiesen');
  const sw = rows([0]); [sw[0], sw[1]] = [sw[1], sw[0]];
  assert.ok(!g.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: sw }).ok, 'falsche Monatsreihenfolge abgewiesen');

  const nw = g.post({ action: 'jahr_schreiben', k: KEY, year: 2027, header, rows: rows([0]) });
  assert.ok(nw.ok && nw.neu); const f27 = [...g.files.values()].find((f) => f._name === 'Jahresübersicht Löhne Assistenz 2027');
  assert.strictEqual(f27._parent, sub(g, g.main, '2027'), 'neue Tabelle im Ordner 2027');
  assert.ok(g.post({ action: 'jahr_lesen', k: KEY, year: 2027 }).found);
  ok('neue Jahrestabelle wird im neuen Ordner «2027» angelegt; ungültige Daten abgewiesen');

  // Monate als Datum / Abkürzung in der bestehenden Tabelle werden erkannt
  const g2 = makeGoogle();
  const t2 = g2.spreadsheet('Jahresübersicht Löhne Assistenz 2026', g2.main, [header, [new Date(2026, 0, 1), 10, 9, 1, 1], ['Feb', 10, 9, 1, 1], ['Mär 2026', 10, 9, 1, 1], ['2026-04', 10, 9, 1, 1]]);
  const r2 = g2.post({ action: 'jahr_schreiben', k: KEY, year: 2026, header, rows: rows([0, 1, 2]) });
  assert.ok(!r2.ok && /enthält 4 Monate/.test(r2.error), r2.error); void t2;
  const l2 = g2.post({ action: 'jahr_lesen', k: KEY, year: 2026 }); assert.deepStrictEqual(l2.values[1][0], { m: 1 });
  ok('Monatsangaben als Datum, «Feb», «Mär 2026», «2026-04» werden gezählt');
}

/* ---------- Gmail-Entwürfe ---------- */
{
  // Entwurf prüft schon die erlaubten Empfänger (damit die App vor dem Senden abbricht)
  { const g0 = makeGoogle(); const f0 = [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }];
    const e0 = g0.post({ action: 'entwurf', k: KEY, to: 'anna@beispiel.ch', cc: 'chef@beispiel.ch', subject: 'Lohnabrechnung Oktober 2026 / Anna Beispiel', body: 'x', files: f0 });
    assert.ok(!e0.ok && /anna@beispiel\.ch ist nicht in der Liste/.test(e0.error) && /kein Entwurf erstellt/.test(e0.error), e0.error);
    g0.props.ERLAUBTE_EMPFAENGER = 'Anna@Beispiel.ch';
    const e1 = g0.post({ action: 'entwurf', k: KEY, to: 'anna@beispiel.ch', cc: 'chef@beispiel.ch', subject: 'Lohnabrechnung Oktober 2026 / Anna Beispiel', body: 'x', files: f0 });
    assert.ok(!e1.ok && /chef@beispiel\.ch/.test(e1.error), e1.error); assert.strictEqual(g0.drafts.length, 0, 'kein Entwurf bei unerlaubter Adresse');
    const e2 = g0.post({ action: 'entwurf', k: KEY, to: 'anna@beispiel.ch', cc: '', subject: 'Lohnabrechnung Oktober 2026 / Anna Beispiel (korrigiert)', body: 'x', files: f0 });
    assert.ok(e2.ok, JSON.stringify(e2));
    ok('Entwurf: nicht erlaubte Empfänger (auch CC) abgewiesen, Betreff mit «(korrigiert)» erlaubt'); }
  const g = makeGoogle({ props: { ERLAUBTE_EMPFAENGER: 'anna@beispiel.ch, chef@beispiel.ch' } });
  const base = { action: 'entwurf', k: KEY, to: 'anna@beispiel.ch', cc: 'chef@beispiel.ch', subject: 'Lohnabrechnung Oktober 2026 / Anna Beispiel', body: 'Liebe Anna\n\nHier ist deine Lohnabrechnung vom Oktober mit der Stundenübersicht.\n\nVielen Dank für deine Unterstützung! ❤️\n\nLiebe Grüsse\nRoger',
    files: [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }, { name: '2026-10 Stundenübersicht Anna Beispiel.pdf', b64: pdf() }] };
  const r = g.post(base); assert.ok(r.ok, JSON.stringify(r));
  const d = g.drafts[0];
  assert.strictEqual(d.to, 'anna@beispiel.ch'); assert.strictEqual(d.cc, 'chef@beispiel.ch'); assert.strictEqual(d.attachments.length, 2); assert.ok(d.body.includes('❤️'));
  g.drafts.push({ _id: 'alt', subject: 'Anderes', getMessageId: () => 'malt', getMessage: () => ({ getSubject: () => 'Anderes' }), deleteDraft() { this._deleted = true; } });
  // ein Entwurf mit ähnlichem, aber nicht gleichem Betreff bleibt
  g.ctx.GmailApp.createDraft('x@beispiel.ch', base.subject + ' (Kopie)', 'x', {});
  const r2 = g.post(base); assert.ok(r2.ok && r2.ersetzt === 1, JSON.stringify(r2));
  assert.strictEqual(g.ctx.GmailApp._calls(), 0, 'Entwürfe werden nicht einzeln geöffnet (schnell)');
  assert.ok(g.ctx.GmailApp.getDrafts().some((d) => d.subject === base.subject + ' (Kopie)'), 'ähnlicher Betreff bleibt');
  assert.strictEqual(g.ctx.GmailApp.getDrafts().filter((x) => x.subject === base.subject).length, 1, 'kein doppelter Entwurf'); assert.ok(!g.drafts.find((x) => x._id === 'alt')._deleted, 'andere Entwürfe bleiben');
  ok('Gmail-Entwurf mit 2 PDFs und CC, erneutes Erstellen ersetzt nur den gleichen Entwurf');

  assert.ok(/E-Mail-Adresse/.test(g.post(Object.assign({}, base, { to: '' })).error));
  assert.ok(/CC-Adresse/.test(g.post(Object.assign({}, base, { cc: 'kaputt' })).error));
  assert.ok(/Betreff/.test(g.post(Object.assign({}, base, { subject: 'Hallo' })).error));
  assert.ok(/Anhang|Anhänge/.test(g.post(Object.assign({}, base, { files: [] })).error));
  assert.ok(/Unerwarteter Anhang/.test(g.post(Object.assign({}, base, { files: [{ name: 'x.pdf', b64: pdf() }] })).error));
  assert.ok(/nur Adressen @example.com/.test(g.post(Object.assign({}, base, { test: true })).error), 'Testmodus nur example.com');
  const t = g.post(Object.assign({}, base, { test: true, to: 'anna@example.com', cc: 'max@example.com' }));
  assert.ok(t.ok && t.subject.startsWith('[TEST] '));
  ok('Entwurf: ungültige Adresse/Betreff/Anhang abgewiesen; Testmodus nur @example.com mit [TEST]');
  assert.ok(!('sendEmail' in g.ctx.GmailApp), 'kein Versand möglich');
}

/* ---------- Senden ---------- */
{
  const files = [{ name: '2026-10 Lohnabrechnung Anna Beispiel.pdf', b64: pdf() }, { name: '2026-10 Stundenübersicht Anna Beispiel.pdf', b64: pdf() }];
  const mk = (g, o) => g.post(Object.assign({ action: 'entwurf', k: KEY, to: 'anna@beispiel.ch', cc: 'chef@beispiel.ch', subject: 'Lohnabrechnung Oktober 2026 / Anna Beispiel', body: 'Liebe Anna', files }, o || {}));
  // ohne Liste erlaubter Empfänger: nichts senden (Liste nach dem Entwurf entfernt – das Senden prüft nochmals)
  let g = makeGoogle({ props: { ERLAUBTE_EMPFAENGER: 'anna@beispiel.ch, chef@beispiel.ch' } });
  let e = mk(g); assert.ok(e.ok); delete g.props.ERLAUBTE_EMPFAENGER;
  let s = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(!s.ok && /nicht in der Liste der erlaubten Empfänger/.test(s.error), s.error); assert.strictEqual(g.sent.length, 0);
  assert.strictEqual(g.post({ action: 'senden', k: 'falsch-falsch-falsch', draftId: e.id }).error, 'Abruf-Schlüssel ist falsch.');
  // nur Empfänger erlaubt, CC nicht -> nichts senden
  g = makeGoogle({ props: { ERLAUBTE_EMPFAENGER: 'anna@beispiel.ch, chef@beispiel.ch' } });
  e = mk(g); g.props.ERLAUBTE_EMPFAENGER = 'Anna@Beispiel.ch'; s = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(!s.ok && /chef@beispiel\.ch/.test(s.error)); assert.strictEqual(g.sent.length, 0);
  ok('Senden: ohne bzw. mit unvollständiger Empfängerliste wird nichts gesendet');
  // alles erlaubt -> gesendet, danach nicht nochmals
  g = makeGoogle({ props: { ERLAUBTE_EMPFAENGER: 'anna@beispiel.ch, chef@beispiel.ch' } });
  e = mk(g); s = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(s.ok && s.gesendet, JSON.stringify(s)); assert.strictEqual(g.sent.length, 1);
  const again = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(!again.ok && /nicht gefunden/.test(again.error)); assert.strictEqual(g.sent.length, 1);
  ok('Senden an erlaubte Empfänger; zweites Senden desselben Entwurfs unmöglich');
  // fremder Entwurf (anderer Betreff / ohne PDF) wird nicht gesendet
  const fremd = g.ctx.GmailApp.createDraft('anna@beispiel.ch', 'Hallo', 'x', {});
  assert.ok(/Betreff/.test(g.post({ action: 'senden', k: KEY, draftId: fremd.getId() }).error));
  const ohne = g.ctx.GmailApp.createDraft('anna@beispiel.ch', 'Lohnabrechnung Oktober 2026 / Anna Beispiel', 'x', {});
  assert.ok(/Anhänge fehlen/.test(g.post({ action: 'senden', k: KEY, draftId: ohne.getId() }).error));
  const falsch = g.ctx.GmailApp.createDraft('anna@beispiel.ch', 'Lohnabrechnung Oktober 2026 / Anna Beispiel', 'x', { attachments: [{ name: 'virus.exe', mime: 'application/octet-stream' }] });
  assert.ok(/Unerwarteter Anhang/.test(g.post({ action: 'senden', k: KEY, draftId: falsch.getId() }).error));
  const bcc = mk(g); g.drafts.find((d) => d._id === bcc.id).bcc = 'fremd@boese.ch';
  assert.ok(/fremd@boese\.ch/.test(g.post({ action: 'senden', k: KEY, draftId: bcc.id }).error), 'BCC wird geprüft');
  assert.strictEqual(g.sent.length, 1);
  ok('Senden: fremde Entwürfe, falsche Anhänge und BCC an Unbekannte werden abgewiesen');
  // eigene Adresse ist immer erlaubt; Testmodus
  g = makeGoogle({ owner: 'roger@beispiel.ch' });
  e = mk(g, { to: 'roger@beispiel.ch', cc: '' }); s = g.post({ action: 'senden', k: KEY, draftId: e.id });
  assert.ok(s.ok && s.gesendet);
  e = mk(g, { test: true, to: 'anna@example.com', cc: 'max@example.com' }); assert.ok(e.ok);
  s = g.post({ action: 'senden', k: KEY, draftId: e.id, test: true });
  assert.ok(s.ok && s.simuliert && !s.gesendet); assert.strictEqual(g.sent.length, 1, '@example.com wird im Test nur simuliert');
  e = mk(g, { test: true, to: 'roger@beispiel.ch', cc: 'roger@beispiel.ch' }); assert.ok(e.ok, JSON.stringify(e));
  s = g.post({ action: 'senden', k: KEY, draftId: e.id, test: true }); assert.ok(s.ok && s.gesendet); assert.strictEqual(g.sent.length, 2);
  assert.ok(!g.post({ action: 'senden', k: KEY, draftId: mk(g).id, test: true }).ok, 'Testmodus sendet keine echten Lohnabrechnungen');
  ok('Senden: eigene Adresse erlaubt; Testmodus simuliert @example.com und sendet echt nur an die eigene Adresse');
}

/* ---------- Sicherung ---------- */
{
  const g = makeGoogle();
  const name = 'Sicherung Abrechnung 2026-11-01.json';
  const vault = JSON.stringify({ v: 1, salt: 'c2FsdA==', iter: 250000, iv: 'aXY=', ct: 'Y3Q=' });
  const alt1 = g.file('Sicherung Abrechnung 2026-10-01.json', 'application/json', g.main, []);
  const alt2 = g.file('Sicherung Abrechnung 2026-10-22 (1).json', 'application/json', g.main, []);
  const fremd = g.file('Notizen.json', 'application/json', g.main, []);
  const anna = g.folder('Anna Beispiel', g.main); const inPerson = g.file('Sicherung Abrechnung 2026-09-01.json', 'application/json', anna, []);
  const n0 = g.files.size;
  assert.strictEqual(g.post({ action: 'sicherung', k: 'falsch-falsch-falsch', name, inhalt: vault }).error, 'Abruf-Schlüssel ist falsch.');
  assert.ok(/Unerwarteter Dateiname/.test(g.post({ action: 'sicherung', k: KEY, name: 'Notizen.json', inhalt: vault }).error));
  assert.ok(/Unerwarteter Dateiname/.test(g.post({ action: 'sicherung', k: KEY, name: 'Sicherung Abrechnung 2026-11-01.pdf', inhalt: vault }).error));
  for (const bad of ['', 'kein json', '[]', JSON.stringify({ persons: [{ name: 'Anna Beispiel' }] }), JSON.stringify({ v: 1, salt: 'a', iter: 1, iv: 'b', ct: 'c', klartext: 'x' }), JSON.stringify({ v: 1, salt: 'a', iter: 1, iv: 'b', ct: { name: 'x' } })]) {
    assert.strictEqual(g.post({ action: 'sicherung', k: KEY, name, inhalt: bad }).ok, false, 'abgelehnt: ' + bad);
  }
  assert.strictEqual(g.files.size, n0, 'bei Fehlern nichts angelegt'); assert.ok(!alt1._trashed && !alt2._trashed);
  const r = g.post({ action: 'sicherung', k: KEY, name, inhalt: vault });
  assert.ok(r.ok, JSON.stringify(r)); assert.strictEqual(r.ersetzt, 2); assert.strictEqual(r.ordner, g.main.getName());
  assert.ok(alt1._trashed && alt2._trashed, 'ältere Sicherungen im Papierkorb'); assert.ok(!fremd._trashed, 'andere Dateien bleiben'); assert.ok(!inPerson._trashed, 'nur im Hauptordner');
  let live = g.live(g.main).filter((f) => /^Sicherung/.test(f._name));
  assert.strictEqual(live.length, 1); assert.strictEqual(live[0]._name, name); assert.strictEqual(live[0]._mime, 'application/json'); assert.strictEqual(live[0]._bytes, vault);
  const r2 = g.post({ action: 'sicherung', k: KEY, name, inhalt: vault });
  assert.strictEqual(r2.ersetzt, 1, 'gleicher Tag: ersetzt'); assert.strictEqual(g.live(g.main).filter((f) => /^Sicherung/.test(f._name)).length, 1);
  const r3 = g.post({ action: 'sicherung', k: KEY, name, inhalt: vault, test: true });
  assert.ok(r3.ok); assert.strictEqual(r3.ordner, '_TEST Beispieldaten'); assert.strictEqual(r3.ersetzt, 0);
  assert.strictEqual(g.live(g.main).filter((f) => /^Sicherung/.test(f._name)).length, 1, 'Test berührt echte Sicherung nicht');
  ok('Sicherung: nur verschlüsselt, richtiger Name, im Hauptordner; ältere in den Papierkorb; Testmodus nur im Testordner');
}

/* ---------- Erfassungsseite unverändert ---------- */
{
  const { makeGoogle: mg } = require('./google-mock');
  const tok = 't'.repeat(20);
  const mkS = (rows) => ({ rows, getDataRange: () => ({ getValues: () => rows.map((r) => r.slice()) }), getLastRow: () => rows.length,
    getRange: (r, c, nr = 1, nc = 1) => ({ getValues: () => { const o = []; for (let i = 0; i < nr; i++) { const row = []; for (let j = 0; j < nc; j++) row.push((rows[r - 1 + i] || [])[c - 1 + j] ?? ''); o.push(row); } return o; }, setValues() {}, setNumberFormat() {} }) });
  const g = mg({ erfassungSheets: { Personen: mkS([['Token', 'Name', 'aktiv'], [tok, 'Anna Beispiel', '']]), Stunden: mkS([['Name', 'Datum', 'Dauer', 'Geändert'], ['Anna Beispiel', '2026-09-02', 4.5, 'x']]), Abschluss: mkS([['Name', 'Monat', 'Total', 'Zeitpunkt', 'Status', 'Anzahl']]) } });
  assert.strictEqual(g.get({ t: tok, m: '2026-09' }).entries['2026-09-02'], 4.5);
  assert.ok(g.get({ action: 'export', k: KEY, m: '2026-09' }).csv.includes('Anna Beispiel,2026-09-02,4.5'));
  ok('Erfassungsseite und «Stunden holen» funktionieren unverändert');
}
console.log('ALLE SCRIPT-TESTS OK');
