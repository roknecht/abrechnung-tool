"""Unabhängige Prüfung der erzeugten PDFs: liest den Text aus den PDFs und rechnet alles neu."""
import glob, os, re, sys, datetime
from decimal import Decimal, ROUND_HALF_UP
import pdfplumber

OUT = os.path.join(os.path.dirname(__file__), 'ui-out')
WD = ['Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag', 'Sonntag']

def r5(x):  # auf 5 Rappen, kaufmännisch
    return (Decimal(x) / Decimal('0.05')).quantize(Decimal('1'), rounding=ROUND_HALF_UP) * Decimal('0.05')

def num(s):
    return Decimal(s.replace("'", ''))

def text(path):
    with pdfplumber.open(path) as pdf:
        assert len(pdf.pages) == 1, f'{path}: mehr als eine Seite'
        return pdf.pages[0].extract_text()

errors = []
def check(cond, msg):
    if not cond: errors.append(msg)
    print(('ok   ' if cond else 'FEHLER ') + msg)

hours_by_person = {}
for p in sorted(glob.glob(os.path.join(OUT, '*Stundenübersicht*.pdf'))):
    person = re.sub(r'^\d{4}-\d{2} Stundenübersicht (.*)\.pdf$', r'\1', os.path.basename(p))
    t = text(p)
    rows = re.findall(r'^(\d{2})\.(\d{2})\.(\d{4}) (\w+) (\d+\.\d{2})$', t, re.M)
    total = re.search(r'Total Stunden (\d+\.\d{2})', t)
    s = sum(Decimal(r[4]) for r in rows)
    check(len(rows) > 0, f'{person}: {len(rows)} Tageszeilen gelesen')
    check(total and Decimal(total.group(1)) == s, f'{person}: Total Stunden {total.group(1)} = Summe der Zeilen {s}')
    ok_wd = all(WD[datetime.date(int(r[2]), int(r[1]), int(r[0])).weekday()] == r[3] for r in rows)
    check(ok_wd, f'{person}: alle Wochentage stimmen zum Datum')
    n = re.search(r'Einsätze (\d+)', t)
    check(n and int(n.group(1)) == len(rows), f'{person}: Anzahl Einsätze {n.group(1)} = Zeilen {len(rows)}')
    check('Grundlage für die Lohnabrechnung September 2026.' in t, f'{person}: Fusszeile')
    check('Stunden × Ansatz' not in t, f'{person}: keine Zeile Stunden × Ansatz')
    hours_by_person[person] = s
    if person == 'Maria Demo':
        check(all(r[3] in ('Sonntag', 'Donnerstag') and r[4] in ('4.00', '5.00') for r in rows) and s == Decimal('36.00'),
              'Maria Demo: nur Sonntage/Donnerstage, je 4.00 oder 5.00, Summe genau 36.00')

AHV = {'Anna Beispiel': True, 'Hans Probe': False, 'Maria Demo': True}
for p in sorted(glob.glob(os.path.join(OUT, '*Lohnabrechnung*.pdf'))):
    person = re.sub(r'^\d{4}-\d{2} Lohnabrechnung (.*)\.pdf$', r'\1', os.path.basename(p))
    t = text(p)
    m = re.search(r'^Stundenlohn (\d+\.\d{2}) x (\d+\.\d{2}) ([\d\']+\.\d{2})$', t, re.M)
    h = Decimal(m.group(1)); lohn = num(m.group(3))
    check(h == hours_by_person[person], f'{person}: Stunden auf Lohnabrechnung {h} = Stundenübersicht {hours_by_person[person]}')
    check(lohn == r5(h * 35), f'{person}: Stundenlohn {lohn} = {h} x 35.00')
    fe = num(re.search(r'^Ferienentschädigung 8\.33% ([\d\']+\.\d{2})$', t, re.M).group(1))
    check(fe == r5(lohn * Decimal('0.0833')), f'{person}: Ferienentschädigung {fe}')
    br = num(re.search(r'^Bruttolohn ([\d\']+\.\d{2})$', t, re.M).group(1)); ahvl = num(re.search(r'^AHV-Lohn ([\d\']+\.\d{2})$', t, re.M).group(1))
    check(br == lohn + fe == ahvl, f'{person}: Brutto {br} = AHV-Lohn {ahvl} = Lohn + Ferien')
    ahv = num(re.search(r'^AHV/IV/EO [\d.]+% [\d\']+\.\d{2} ([\d\']+\.\d{2})$', t, re.M).group(1))
    if AHV[person]: exp = r5(br * Decimal('0.053'))
    else: exp = r5(max(br - 1400, 0) * Decimal('0.053'))  # Test wählte „abziehen“
    check(ahv == exp, f'{person}: AHV/IV/EO {ahv} (erwartet {exp})')
    tot = num(re.search(r'^Total Abzüge ([\d\']+\.\d{2})$', t, re.M).group(1)); net = num(re.search(r'^Nettolohn CHF ([\d\']+\.\d{2})$', t, re.M).group(1))
    check(tot == ahv and net == br - tot, f'{person}: Total Abzüge {tot}, Nettolohn {net} = Brutto - Abzüge')
    check('Abrechnungsdatum 01.10.2026' in t and '756.0000.0000.0' in t, f'{person}: Abrechnungsdatum 01.10.2026 und AHV-Nr.')
    check('Bitte Lohnabrechnung überprüfen und Unstimmigkeiten melden. Danke.' in t, f'{person}: Schlusssatz')
    check('###' not in t and 'Zusatztext' not in t, f'{person}: keine ### und kein Zusatztext')

j = glob.glob(os.path.join(OUT, 'Jahres*.pdf'))[0]; t = text(j)
tot_h = sum(hours_by_person.values())
check(f'{tot_h:.2f}' in t, f'Jahresübersicht enthält Total Stunden aller Personen {tot_h:.2f}')
check('Stand: September 2026' in t and '1 von 12' in t, 'Jahresübersicht: Stand und abgerechnete Monate')
print('\n' + ('ALLES OK' if not errors else f'{len(errors)} FEHLER'))
sys.exit(1 if errors else 0)
