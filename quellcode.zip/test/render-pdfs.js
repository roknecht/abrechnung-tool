// Erzeugt Test-PDFs mit erfundenen Daten und schreibt sie nach test/out/
const fs = require('fs');
const path = require('path');
const PDFLib = require('/opt/npm-tools/node_modules/pdf-lib');
require('../src/core.js'); require('../src/pdf.js');
const C = globalThis.Core; const P = globalThis.Pdf;

const settings = { stundenlohn: 35, ferien: 8.33, ahv: 5.3, freibetrag: 1400 };
const employer = { name: 'Max Muster', strasse: 'Musterstrasse 1', ort: '8000 Zürich', email: 'max@example.com' };
const persons = [
  { id: 'a', anrede: 'Frau', name: 'Anna Beispiel', kurzname: 'Anna Beispiel', vorname: 'Anna', strasse: 'Beispielweg 2', plzOrt: '3000 Bern', ahvNr: '756.0000.0000.02', ahvAbzug: true },
  { id: 'b', anrede: 'Herr', name: 'Hans Probe', kurzname: 'Hans Probe', vorname: 'Hans', strasse: 'Probestrasse 3', plzOrt: '4000 Basel', ahvNr: '756.0000.0000.03', ahvAbzug: false },
  { id: 'c', anrede: 'Herr', name: 'Peter Test', kurzname: 'Peter Test', vorname: 'Peter', strasse: 'Testgasse 4', plzOrt: '5000 Aarau', ahvNr: '756.0000.0000.04', ahvAbzug: false },
  { id: 'd', anrede: 'Frau', name: 'María Demo Łukasz', kurzname: 'María Demo', vorname: 'María', strasse: 'Demoplatz 5', plzOrt: '6000 Luzern', ahvNr: '756.0000.0000.05', ahvAbzug: true, zahlung: 'IBAN CH00 0000 0000 0000 0000 0' },
];
const out = path.join(__dirname, 'out'); fs.mkdirSync(out, { recursive: true });

(async () => {
  const y = 2026; const m = 8; const months = {};
  const rec = { persons: {} };
  const dayMap = {
    a: [['2026-08-01', 433], ['2026-08-06', 500], ['2026-08-16', 500], ['2026-08-20', 400], ['2026-08-22', 400], ['2026-08-23', 500], ['2026-08-26', 500], ['2026-08-30', 400]],
    b: Array.from({ length: 31 }, (_, i) => [C.ymd(y, m, i + 1), 150 + (i % 4) * 25]), // 31 Einträge (Platztest)
    c: [['2026-08-05', 675], ['2026-08-12', 800]],
    d: C.distribute(36, C.sundaysThursdays(y, m)).days.map((q) => [q.date, q.hc]),
  };
  for (const p of persons) {
    const days = dayMap[p.id].map(([date, hc]) => ({ date, hc })).sort((u, v) => u.date.localeCompare(v.date));
    const hc = days.reduce((s, q) => s + q.hc, 0);
    const calc = C.calcPerson(p, hc, settings, p.id === 'b' ? { excessMode: 'abziehen' } : {});
    rec.persons[p.id] = { hc, bruttoC: calc.bruttoC, nettoC: calc.nettoC };
    const l = await P.lohnabrechnung(PDFLib, { employer, person: p, y, m, calc, settings });
    const s = await P.stundenuebersicht(PDFLib, { employer, person: p, y, m, days, settings });
    fs.writeFileSync(path.join(out, `${C.monthKey(y, m)} Lohnabrechnung ${p.kurzname}.pdf`), l);
    fs.writeFileSync(path.join(out, `${C.monthKey(y, m)} Stundenübersicht ${p.kurzname}.pdf`), s);
    console.log(p.kurzname, 'h', C.fmtHc(hc), 'brutto', C.fmtMoney(calc.bruttoC), 'ahv', C.fmtMoney(calc.ahvC), 'netto', C.fmtMoney(calc.nettoC));
  }
  months[C.monthKey(y, m)] = rec;
  months[C.monthKey(y, 7)] = { persons: { a: { hc: 3600, bruttoC: 136495, nettoC: 129260 }, b: { hc: 2000, bruttoC: 75830, nettoC: 75830 }, d: { hc: 3200, bruttoC: 121330, nettoC: 114900 } } };
  const j = await P.jahresuebersicht(PDFLib, { employer, persons, year: y, months });
  fs.writeFileSync(path.join(out, `Jahresübersicht Löhne Assistenz ${y}.pdf`), j);
  console.log('PDFs geschrieben');
})().catch((e) => { console.error(e); process.exit(1); });
