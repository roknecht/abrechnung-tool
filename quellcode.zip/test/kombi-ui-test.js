// Test «Ablegen und Entwürfe erstellen» (ein Zug)
// Basis: Gesamttest Phase 2 (Handy-Format, erfundene Daten): Dokumente erstellen -> Drive-Ablage (Sicherung greift) ->
// Jahresdaten übernehmen -> Ablage -> Gmail-Entwürfe. Google ist nachgebaut (google-mock.js), kein Netz.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const assert = require('assert');
const openSec = async (page) => { if (!(await page.locator('details.card[open]').count())) await page.getByText('Sicherheit', { exact: true }).click(); };
const { makeGoogle } = require('./google-mock');
const OUT = path.join(__dirname, 'ui-out'); fs.mkdirSync(OUT, { recursive: true });
const KEY = 'testkey-abruf-0123456789'; const PIN = '123456';
const ok = (s) => console.log('ok -', s);
const MON = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

const g = makeGoogle();
const realFiles0 = g.files.size;
// Bestehende Jahrestabelle im Test-Ordner mit Januar bis August (erfunden)
const testFolder = g.folder('_TEST Beispieldaten', g.main);
const header = ['Monat', 'Anna Brutto', 'Anna Netto', 'Maria Brutto', 'Maria Netto', 'Hans Netto', 'Peter Netto', 'Total Stunden'];
const oldRows = [header].concat(MON.map((m, i) => (i < 8 ? [m, 1000 + i, 947 + i, 800, 757.6, i === 2 ? "1'234.50" : 600, '', 70 + i] : [m, '', '', '', '', '', '', '']))).concat([['Total', '', '', '', '', '', '', '']]);
const sheet = g.spreadsheet('Jahresübersicht Löhne Assistenz 2026', testFolder, oldRows);

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' && !(offline && /Failed to load resource/.test(m.text()))) errors.push('console: ' + m.text()); });
  let dialogAnswer = true; const dialogs = []; page.on('dialog', (d) => { dialogs.push(d.message()); return dialogAnswer ? d.accept() : d.dismiss(); });
  let offline = false; const posts = [];
  await page.route('https://script.google.com/**', async (route) => {
    if (offline) return route.abort();
    const req = route.request(); let body;
    if (req.method() === 'POST') {
      const p = JSON.parse(req.postData()); posts.push(p);
      assert.ok(!/application\/json/.test(req.headers()['content-type'] || ''), 'kein JSON-Content-Type (sonst Vorabfrage)');
      body = g.post(p);
    } else body = g.get(Object.fromEntries(new URL(req.url()).searchParams));
    route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(body) });
  });
  const shot = (n) => page.screenshot({ path: path.join(OUT, n + '.png'), fullPage: true });
  const btn = (name, exact) => page.getByRole('button', { name, exact: !!exact });

  await page.goto('http://localhost:8765/');
  await page.getByPlaceholder('PIN (6–8 Ziffern)').fill(PIN); await page.getByPlaceholder('PIN wiederholen').fill(PIN);
  await btn('Mit erfundenen Beispieldaten starten').click(); await page.getByText('Abrechnungsmonat').waitFor();
  // Schlüssel eintragen
  await btn('Einstellungen').click(); await openSec(page); await page.getByLabel('Abruf-Schlüssel').fill(KEY); await page.getByLabel('Abruf-Schlüssel').blur();
  await btn('Abrechnung', true).click();
  // Monat September 2026 wie im bestehenden UI-Test vorbereiten
  await page.locator('select').nth(0).selectOption('9'); await page.locator('select').nth(1).selectOption('2026');
  await btn('Beispiel-CSV laden').click(); await page.getByText('eingelesen').waitFor();
  await page.locator('.card', { hasText: 'Peter Test' }).getByRole('button', { name: 'Hat nicht gearbeitet' }).click();
  await page.locator('.card', { hasText: 'Maria Demo' }).getByRole('button', { name: 'Stunden eintragen' }).click();
  await page.locator('select').filter({ hasText: 'Bitte wählen' }).selectOption('abziehen');
  await page.getByPlaceholder('z. B. 36').fill('36'); await page.getByPlaceholder('z. B. 36').blur();
  await btn('Verteilung vorschlagen').click(); await page.getByText('Summe stimmt mit dem Total').waitFor();
  await btn('Dokumente erstellen').click(); await page.getByText('Dokumente erstellt').waitFor({ timeout: 20000 });
  await page.getByText('Testmodus (erfundene Daten)').waitFor();
  ok('Dokumente erstellt, Testmodus erkannt');


  // Breite: keine waagrechte Verschiebung
  const sw = await page.evaluate(() => document.documentElement.scrollWidth);
  assert.ok(sw <= 390, 'Seite nicht breiter als der Bildschirm (' + sw + ')');
  ok('Dateiliste passt in die Breite');

  // A) Fehlende E-Mail: nichts wird ausgeführt
  await btn('Einstellungen').click();
  const empMail = page.getByLabel('E-Mail (für CC)'); const oldMail = await empMail.inputValue();
  await empMail.fill(''); await empMail.blur(); await btn('Abrechnung', true).click();
  await btn('Ablegen und Entwürfe erstellen').click();
  await page.getByText('Nichts ausgeführt').waitFor();
  assert.strictEqual(posts.length, 0, 'bei fehlender Angabe keine Anfrage an Google');
  await btn('Einstellungen').click(); await page.getByLabel('E-Mail (für CC)').fill(oldMail); await page.getByLabel('E-Mail (für CC)').blur(); await btn('Abrechnung', true).click();
  ok('fehlende E-Mail: nichts abgelegt, keine Entwürfe');

  // B) Ablage scheitert (Tabelle hat mehr Monate): keine Entwürfe
  await btn('Ablegen und Entwürfe erstellen').click();
  await page.getByText('Es wurden keine Entwürfe erstellt').waitFor({ timeout: 20000 });
  assert.strictEqual(g.ctx.GmailApp.getDrafts().length, 0, 'keine Entwürfe bei unvollständiger Ablage');
  assert.ok(!posts.some((p) => p.action === 'entwurf' || p.action === 'senden'));
  await shot('k-01-abbruch'); ok('Ablage scheitert: keine Entwürfe, klare Meldung');

  await btn('Zu „Jahr“: Jahresdaten übernehmen').click();
  await btn('Tabelle lesen und prüfen').click(); await page.getByText('Neu in die App:').waitFor();
  await btn('Übernehmen').click(); await page.getByText('8 Monate übernommen').waitFor();
  await btn('Abrechnung', true).click();

  // C) Erfolgreich: abgelegt, 4 Entwürfe, nichts gesendet
  await btn('Ablegen und Entwürfe erstellen').click();
  await page.getByText('Abgelegt und Entwürfe erstellt').waitFor({ timeout: 30000 });
  assert.strictEqual(g.ctx.GmailApp.getDrafts().length, 4, '4 Entwürfe');
  assert.ok(g.ctx.GmailApp.getDrafts().every((d) => d.cc === 'max@example.com'), 'CC aus den aktuellen Einstellungen');
  assert.ok(!posts.some((p) => p.action === 'senden') && g.sent.length === 0, 'nichts gesendet');
  assert.ok(await page.getByText('Alles im Drive abgelegt.').count(), 'Ablage vollständig');
  assert.ok(!(await btn('Ablegen und Entwürfe erstellen').count()), 'Kombi-Button danach weg');
  assert.ok(await btn('Jetzt senden und sichern (4)').count(), 'Senden bleibt eigener Schritt');
  await page.getByText('Abgelegt und Entwürfe erstellt').scrollIntoViewIfNeeded(); await page.screenshot({ path: path.join(OUT, 'k-02-fertig.png') });
  await shot('k-03-fertig-voll'); ok('Erfolg: abgelegt und 4 Entwürfe, Senden nur separat');

  dialogAnswer = true; await btn('Jetzt senden und sichern (4)').click();
  await page.getByText('Test abgeschlossen: Senden geprüft.').waitFor({ timeout: 20000 });
  assert.strictEqual(g.sent.length, 0); ok('Senden mit Rückfrage wie bisher (Test: nur simuliert)');
  await page.getByText(/Sicherung Abrechnung \d{4}-\d{2}-\d{2}\.json im Ordner «_TEST Beispieldaten»/).waitFor({ timeout: 20000 });
  { const sp = posts.filter((p) => p.action === 'sicherung'); assert.strictEqual(sp.length, 1, 'genau eine Sicherung');
    const inh = JSON.parse(sp[0].inhalt); assert.deepStrictEqual(Object.keys(inh).sort(), ['ct', 'iter', 'iv', 'salt', 'v'], 'nur verschlüsselt');
    assert.ok(!/Anna|Beispiel|example/.test(sp[0].inhalt.replace(/"ct":"[^"]*"/, '')), 'kein Klartext ausserhalb der verschlüsselten Daten');
    const files = [...g.files.values()].filter((f) => !f._trashed && /^Sicherung Abrechnung .*\.json$/.test(f._name));
    assert.strictEqual(files.length, 1, 'eine Sicherung im Drive'); assert.strictEqual(files[0]._parent._name, '_TEST Beispieldaten', 'Testmodus: nur Testordner'); }
  ok('Nach dem Senden: Sicherung im Drive abgelegt');
  assert.deepStrictEqual(errors, [], errors.join('\n'));
  await browser.close(); console.log('KOMBI-TEST OK');
})().catch((e) => { console.error('TESTFEHLER:', e.message); process.exit(1); });
