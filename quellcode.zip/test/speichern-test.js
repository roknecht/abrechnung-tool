// Test Speichern (erfundene Daten): Änderungen gehen nicht verloren, wenn direkt danach gesperrt wird
// oder die App in den Hintergrund geht; «Alle Daten löschen» bleibt gelöscht, auch mit offenem Speichervorgang.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const assert = require('assert');
const URL = process.env.APP_URL || 'http://localhost:8765/';
const PIN = '123456';
const ok = (s) => console.log('ok -', s);

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 } });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push('pageerror: ' + e.message));
  page.on('dialog', (d) => d.accept());
  // Name des Arbeitgebers ändern (löst das verzögerte Speichern aus) und im selben Moment etwas anderes tun
  const changeName = (name, then) => page.evaluate(([name, then]) => {
    const inp = [...document.querySelectorAll('label.f')].find((l) => l.querySelector('span').textContent === 'Name').querySelector('input');
    inp.value = name; inp.dispatchEvent(new Event('change'));
    if (then === 'sperren') [...document.querySelectorAll('button')].find((b) => b.textContent === 'Jetzt sperren').click();
    if (then === 'hintergrund') { Object.defineProperty(document, 'hidden', { configurable: true, get: () => true }); document.dispatchEvent(new Event('visibilitychange')); }
    if (then === 'loeschen') [...document.querySelectorAll('button')].find((b) => b.textContent === 'Alle Daten löschen').click();
  }, [name, then]);
  const nameValue = () => page.evaluate(() => [...document.querySelectorAll('label.f')].find((l) => l.querySelector('span').textContent === 'Name').querySelector('input').value);
  const unlock = async () => { await page.getByPlaceholder('PIN').fill(PIN); await page.getByRole('button', { name: 'Entsperren' }).click(); };

  try {
    await page.goto(URL); await page.evaluate(() => localStorage.clear()); await page.reload();
    const ins = page.locator('input'); await ins.nth(0).fill(PIN); await ins.nth(1).fill(PIN);
    await page.getByText('Mit erfundenen Beispieldaten starten').click(); await page.getByText('Abrechnungsmonat').waitFor();
    await page.getByRole('button', { name: 'Einstellungen' }).click(); await page.getByText('Arbeitgeber (Briefkopf)').waitFor();

    // 1) «Jetzt sperren» direkt nach einer Änderung
    await changeName('Sofort Gesperrt AG', 'sperren');
    await page.getByPlaceholder('PIN').waitFor(); await page.waitForTimeout(600); await unlock();
    await page.getByText('Arbeitgeber (Briefkopf)').waitFor();
    assert.strictEqual(await nameValue(), 'Sofort Gesperrt AG', 'Änderung vor dem Sperren gespeichert');
    ok('Sperren direkt nach einer Änderung: Änderung bleibt');

    // 2) App geht direkt nach einer Änderung in den Hintergrund, Neustart nach 150 ms (vor Ablauf der 0.4 s)
    await changeName('Hintergrund AG', 'hintergrund'); await page.waitForTimeout(150);
    await page.reload(); await unlock();
    await page.getByRole('button', { name: 'Einstellungen' }).click(); await page.getByText('Arbeitgeber (Briefkopf)').waitFor();
    assert.strictEqual(await nameValue(), 'Hintergrund AG', 'Änderung beim Wechsel in den Hintergrund gespeichert');
    ok('Wechsel in den Hintergrund: Änderung sofort gespeichert');

    // 3) «Alle Daten löschen» direkt nach einer Änderung: es wird nichts wiederhergestellt
    await changeName('Wird Geloescht AG', 'loeschen'); await page.waitForTimeout(1000);
    assert.strictEqual(await page.evaluate(() => localStorage.getItem('abrechnung_vault_v1')), null, 'Daten bleiben gelöscht');
    await page.reload(); await page.getByText('Erster Start').waitFor();
    ok('Alle Daten löschen mit offenem Speichervorgang: bleibt gelöscht');

    assert.deepStrictEqual(errors, []);
    console.log('SPEICHERN-TEST OK');
  } catch (e) { console.log('TESTFEHLER:', e.message.split('\n')[0]); process.exitCode = 1; }
  await browser.close();
})();
