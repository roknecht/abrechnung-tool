// Gesamttest (Handy-Format, erfundene Daten): Dokumente erstellen -> Vorschau -> «Senden, ablegen und sichern»
// (Sicherung der Jahrestabelle greift) -> Jahresdaten übernehmen -> Erfolg -> Neustart -> Korrektur. Google ist nachgebaut (google-mock.js), kein Netz.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const assert = require('assert');
const openSec = async (page) => { if (!(await page.locator('details.card[open]').count())) await page.getByText('Sicherheit', { exact: true }).click(); };
const { makeGoogle } = require('./google-mock');
const OUT = path.join(__dirname, 'ui-out'); fs.mkdirSync(OUT, { recursive: true });
const KEY = 'testkey-abruf-0123456789'; const PIN = '123456';
const ok = (s) => console.log('ok -', s);
const MON = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

const g = makeGoogle();
const realFiles0 = g.files.size;
// Bestehende Jahrestabelle im Test-Ordner mit Januar bis August (erfunden)
const testFolder = g.folder('_TEST Beispieldaten', g.main);
const header = ['Monat', 'Anna Brutto', 'Anna Netto', 'Maria Brutto', 'Maria Netto', 'Hans Netto', 'Peter Netto', 'Total Stunden'];
const oldRows = [header].concat(MON.map((m, i) => (i < 8 ? [m, 1000 + i, 947 + i, 800, 757.6, i === 2 ? "1'234.50" : 600, '', 70 + i] : [m, '', '', '', '', '', '', '']))).concat([['Total', '', '', '', '', '', '', '']]);
const sheet = g.spreadsheet('Jahresübersicht Löhne Assistenz 2026', testFolder, oldRows);

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' && !(offline && /Failed to load resource/.test(m.text()))) errors.push('console: ' + m.text()); });
  let dialogAnswer = true; const dialogs = []; page.on('dialog', (d) => { dialogs.push(d.message()); return dialogAnswer ? d.accept() : d.dismiss(); });
  let offline = false; const posts = [];
  await page.route('https://script.google.com/**', async (route) => {
    if (offline) return route.abort();
    const req = route.request(); let body;
    if (req.method() === 'POST') {
      const p = JSON.parse(req.postData()); posts.push(p);
      assert.ok(!/application\/json/.test(req.headers()['content-type'] || ''), 'kein JSON-Content-Type (sonst Vorabfrage)');
      body = g.post(p);
    } else body = g.get(Object.fromEntries(new URL(req.url()).searchParams));
    route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(body) });
  });
  const shot = (n) => page.screenshot({ path: path.join(OUT, n + '.png'), fullPage: true });
  const btn = (name, exact) => page.getByRole('button', { name, exact: !!exact });

  await page.goto('http://localhost:8765/');
  await page.getByPlaceholder('PIN (6–8 Ziffern)').fill(PIN); await page.getByPlaceholder('PIN wiederholen').fill(PIN);
  await btn('Mit erfundenen Beispieldaten starten').click(); await page.getByText('Abrechnungsmonat').waitFor();
  // Schlüssel eintragen
  await btn('Einstellungen').click(); await openSec(page); await page.getByLabel('Abruf-Schlüssel').fill(KEY); await page.getByLabel('Abruf-Schlüssel').blur();
  await btn('Abrechnung', true).click();
  // Monat September 2026 wie im bestehenden UI-Test vorbereiten
  await page.locator('select').nth(0).selectOption('9'); await page.locator('select').nth(1).selectOption('2026');
  await btn('Beispiel-CSV laden').click(); await page.getByText('eingelesen').waitFor();
  await page.locator('.card', { hasText: 'Peter Test' }).getByRole('button', { name: 'Hat nicht gearbeitet' }).click();
  await page.locator('.card', { hasText: 'Maria Demo' }).getByRole('button', { name: 'Stunden eintragen' }).click();
  await page.locator('select').filter({ hasText: 'Bitte wählen' }).selectOption('abziehen');
  await page.getByPlaceholder('z. B. 36').fill('36'); await page.getByPlaceholder('z. B. 36').blur();
  await btn('Verteilung vorschlagen').click(); await page.getByText('Summe stimmt mit dem Total').waitFor();
  await btn('Dokumente erstellen').click(); await page.getByText('Dokumente erstellt').waitFor({ timeout: 20000 });
  await page.getByText('Testmodus (erfundene Daten)').waitFor();
  ok('Dokumente erstellt, Testmodus erkannt');

  const run = () => btn(/^(Senden, ablegen und sichern|Nochmals versuchen) \(\d+\)$/);
  const card = (n) => page.locator('.card', { has: page.getByRole('heading', { name: n, exact: true }) });

  // 0) Prüfen: pro Person PDFs zum Ansehen und eine zugeklappte E-Mail-Vorschau
  assert.strictEqual(await btn('Ansehen', true).count(), 8, '7 PDFs der Personen + Jahresübersicht zum Ansehen');
  assert.strictEqual(await page.locator('details.mailprev').count(), 4, 'vier E-Mail-Vorschauen');
  assert.ok(!(await page.locator('details.mailprev[open]').count()), 'Vorschau zugeklappt');
  for (const d of await page.locator('details.mailprev > summary').all()) await d.click();
  const mb = await page.innerText('body');
  assert.ok(mb.includes('[TEST] Lohnabrechnung September 2026 / Anna Beispiel') && mb.includes('Liebe Anna') && mb.includes('Lieber Hans') && mb.includes('Liebe Maria'), 'Betreff und Anrede');
  assert.ok(mb.includes('Hier ist deine Lohnabrechnung vom September mit der Stundenübersicht.') && mb.includes('Vielen Dank für deine Unterstützung! ❤️') && mb.includes('Liebe Grüsse\nRoger'));
  assert.ok(mb.includes('Lieber Peter\n\nHier ist deine Lohnabrechnung vom September.\n'), 'eigener Satz ohne Stundenübersicht');
  assert.ok(mb.includes('Anhänge: 2026-09 Lohnabrechnung Peter Test.pdf') && mb.includes('max@example.com'));
  assert.ok(!/korrigiert/.test(mb), 'kein Korrektur-Text bei der ersten Abrechnung');
  await shot('p2-00-vorschau'); ok('Nach «Dokumente erstellen»: PDFs zum Ansehen, E-Mail-Vorschau zum Aufklappen');

  // A) Fehlende CC-Adresse: Button gesperrt, nichts ausgeführt
  await btn('Einstellungen').click();
  const empMail = page.getByLabel('E-Mail (für CC)'); const oldMail = await empMail.inputValue();
  await empMail.fill(''); await empMail.blur(); await btn('Abrechnung', true).click();
  await page.getByText('Arbeitgeber: keine E-Mail-Adresse für CC').waitFor();
  assert.ok(await run().isDisabled(), 'Button gesperrt'); assert.strictEqual(posts.length, 0);
  await btn('Einstellungen').click(); await page.getByLabel('E-Mail (für CC)').fill(oldMail); await page.getByLabel('E-Mail (für CC)').blur(); await btn('Abrechnung', true).click();
  ok('fehlende E-Mail: gesperrt, nichts an Google');

  // B) Rückfrage abbrechen: nichts
  dialogAnswer = false; await run().click(); await page.waitForTimeout(300);
  const q = dialogs[dialogs.length - 1];
  assert.ok(/4 E-Mails jetzt wirklich senden\?/.test(q) && q.includes('anna@example.com (CC max@example.com)'), 'Rückfrage zeigt Empfänger: ' + q);
  assert.strictEqual(posts.length, 0, 'abgebrochen: nichts'); dialogAnswer = true;
  ok('Rückfrage mit allen Empfängern; Abbrechen macht nichts');

  // C) Ablage scheitert (Tabelle hat mehr Monate): nichts gesendet
  await run().click();
  await page.getByText('Es wurde nichts gesendet').waitFor({ timeout: 20000 });
  await page.getByText('enthält 8 Monate, die App erst 1').waitFor();
  assert.ok(sheet._sheets[0].rows[1][1] === 1000 && sheet._sheets[0].rows.length === oldRows.length, 'Tabelle unverändert');
  assert.ok(!posts.some((p) => ['ablegen', 'entwurf', 'senden', 'sicherung'].includes(p.action)), 'keine PDFs, Entwürfe, Sendungen');
  assert.ok(await btn('Nochmals versuchen (4)').count(), 'nochmals versuchen');
  await shot('p2-01-sicherung'); ok('Ablage stoppt vor dem Überschreiben der Jahrestabelle – nichts gesendet');

  // D) Jahresdaten übernehmen
  await btn('Zu „Jahr“: Jahresdaten übernehmen').click();
  await btn('Tabelle lesen und prüfen').click(); await page.getByText('Neu in die App:').waitFor();
  const body = await page.innerText('body');
  assert.ok(body.includes('Januar, Februar, März, April, Mai, Juni, Juli, August') && body.includes("1'234.50"));
  assert.ok(/«Anna Brutto» → Anna Beispiel Brutto/.test(body) && /«Peter Netto» → Peter Test Netto/.test(body), 'Spaltenzuordnung angezeigt');
  await btn('Übernehmen').click(); await page.getByText('8 Monate übernommen').waitFor();
  await page.getByText('Abgerechnete Monate: 9 von 12').waitFor();
  ok('Jahresdaten übernommen: 9 von 12 Monaten in der App');

  // E) Ein Schritt: ablegen, Entwürfe, senden (Test: simuliert), sichern
  await btn('Abrechnung', true).click();
  await btn('Nochmals versuchen (4)').click();
  await page.getByText('Test abgeschlossen: abgelegt, Senden geprüft, gesichert.').waitFor({ timeout: 30000 });
  const s = sheet._sheets[0];
  const col = (hd) => { const j = s.rows[0].indexOf(hd); assert.ok(j > 0, 'Spalte ' + hd); return j; };
  assert.deepStrictEqual(s.rows[0], ['Monat', 'Anna Brutto', 'Anna Netto', 'Hans Netto', 'Peter Netto', 'Maria Brutto', 'Maria Netto', 'Total Stunden']);
  assert.strictEqual(s.rows[1][col('Anna Netto')], 947); assert.strictEqual(s.rows[3][col('Hans Netto')], 1234.5, 'März Hans übernommen');
  assert.strictEqual(s.rows[8][col('Total Stunden')], 77, 'August Stunden aus Tabelle');
  assert.ok(s.rows[9][0] === 'September' && s.rows[9][col('Anna Netto')] > 0, 'September eingetragen');
  assert.strictEqual(s.rows[10][1], '', 'Oktober leer'); assert.ok(Object.values(s.formulas).includes('=SUM(B2:B13)'));
  assert.ok(!sheet._file._trashed, 'gleiche Tabelle');
  const y26 = () => [...g.folders.values()].find((f) => f._name === '2026' && f._parent === testFolder); // Jahresordner im Testordner
  const sub = (n) => [...g.folders.values()].find((f) => f._name === n && f._parent === y26());
  for (const n of ['Anna Beispiel', 'Hans Probe', 'Maria Demo']) {
    assert.deepStrictEqual(g.live(sub(n)).map((f) => f._name).sort(), [`2026-09 Lohnabrechnung ${n}.pdf`, `2026-09 Stundenübersicht ${n}.pdf`], n);
    g.live(sub(n)).forEach((f) => assert.strictEqual(Buffer.from(f._bytes.map((b) => (b + 256) % 256)).slice(0, 4).toString(), '%PDF'));
  }
  assert.deepStrictEqual(g.live(sub('Peter Test')).map((f) => f._name), ['2026-09 Lohnabrechnung Peter Test.pdf'], 'nicht gearbeitet: nur Lohnabrechnung');
  assert.strictEqual(s.rows[9][col('Peter Netto')], 0, 'September Peter 0.00');
  assert.strictEqual(g.live(y26()).filter((f) => f._name === 'Jahresübersicht Löhne Assistenz 2026.pdf').length, 1);
  assert.strictEqual([...g.files.values()].filter((f) => f._parent === g.main).length, realFiles0, 'im echten Hauptordner nichts Neues');
  const act = g.drafts.filter((d) => /^\[TEST\] Lohnabrechnung September 2026/.test(d.subject));
  assert.strictEqual(act.length, 4, '4 Entwürfe'); assert.ok(act.every((d) => d.cc === 'max@example.com'));
  const pe = act.find((d) => d.to === 'peter@example.com'); assert.ok(pe.attachments.length === 1 && pe.attachments[0].name === '2026-09 Lohnabrechnung Peter Test.pdf');
  const ax = act.find((d) => d.to === 'anna@example.com'); assert.strictEqual(ax.attachments.map((x) => x.name).join(), '2026-09 Lohnabrechnung Anna Beispiel.pdf,2026-09 Stundenübersicht Anna Beispiel.pdf');
  assert.strictEqual(posts.filter((p) => p.action === 'senden').length, 4); assert.strictEqual(g.sent.length, 0, 'im Test nichts wirklich gesendet');
  { const sp = posts.filter((p) => p.action === 'sicherung'); assert.strictEqual(sp.length, 1, 'genau eine Sicherung');
    const inh = JSON.parse(sp[0].inhalt); assert.deepStrictEqual(Object.keys(inh).sort(), ['ct', 'iter', 'iv', 'salt', 'v'], 'nur verschlüsselt');
    assert.ok(!/Anna|Beispiel|example/.test(sp[0].inhalt.replace(/"ct":"[^"]*"/, '')));
    const files = [...g.files.values()].filter((f) => !f._trashed && /^Sicherung Abrechnung .*\.json$/.test(f._name));
    assert.strictEqual(files.length, 1); assert.strictEqual(files[0]._parent._name, '_TEST Beispieldaten'); }
  assert.ok(!(await run().count()), 'kein zweites Senden');
  const order = posts.map((p) => p.action).filter((a, i, arr) => a !== arr[i - 1]);
  assert.deepStrictEqual(order.slice(-5), ['jahr_schreiben', 'ablegen', 'entwurf', 'senden', 'sicherung'], 'Reihenfolge: Tabelle, PDFs, Entwürfe, Senden, Sicherung');
  await shot('p2-04-fertig'); ok('Ein Knopf: Tabelle, PDFs, 4 Entwürfe mit CC, Senden (simuliert), verschlüsselte Sicherung – nur im Testordner');

  // F) Daten verschlüsselt, Schlüssel nur im Inhalt
  const stored = await page.evaluate(() => localStorage.getItem('abrechnung_vault_v1'));
  assert.ok(!/Anna|947|Januar/.test(stored)); assert.ok(posts.every((p) => p.k === KEY) && posts.length > 0);
  ok('Schlüssel nur im Inhalt der Anfrage, Daten verschlüsselt gespeichert');

  // G) Neustart: Sendesperre bleibt, alles «gesendet», nichts mehr zu erstellen
  await page.reload(); await page.getByPlaceholder('PIN').fill(PIN); await btn('Entsperren').click();
  await page.getByText('Abrechnungsmonat').waitFor();
  await page.getByText('Lohnabrechnungen für diesen Monat bereits gesendet:').waitFor();
  assert.strictEqual(await page.getByText('✓ gesendet', { exact: true }).count(), 4, 'vier Karten «gesendet»');
  await page.getByText('Für diesen Monat ist alles gesendet.').waitFor();
  assert.ok(await btn('Dokumente erstellen').isDisabled(), 'nichts zu erstellen');
  assert.ok(!(await card('Anna Beispiel').getByRole('button', { name: 'Bearbeiten' }).count()), 'gesendete Karte: kein Bearbeiten, nur Korrektur');
  assert.ok(!/\bnull\b|undefined|NaN/.test(await page.innerText('body')), 'keine leeren Werte sichtbar');
  await shot('p2-05-neustart'); ok('Nach Neustart: alle gesendet, Sendesperre bleibt');

  // H) Korrektur abbrechen stellt den Stand wieder her
  await card('Anna Beispiel').getByRole('button', { name: 'Korrektur', exact: true }).click();
  await card('Anna Beispiel').getByRole('button', { name: 'Bearbeiten' }).click();
  await card('Anna Beispiel').locator('input.hrs').first().fill('7'); await card('Anna Beispiel').locator('input.hrs').first().blur();
  await btn('Korrektur abbrechen').click();
  await page.getByText('Für diesen Monat ist alles gesendet.').waitFor();
  assert.strictEqual(await page.getByText('✓ gesendet', { exact: true }).count(), 4);
  ok('Korrektur abbrechen: alter Stand, wieder gesperrt');

  // I) Korrektur Hans: nur Hans, Betreff «(korrigiert)», ersetzt im Drive, Jahrestabelle nachgeführt
  const annaNetto = s.rows[9][col('Anna Netto')]; const hansAlt = s.rows[9][col('Hans Netto')];
  await card('Hans Probe').getByRole('button', { name: 'Korrektur', exact: true }).click();
  await card('Hans Probe').getByText('Korrektur (gesendet am').waitFor();
  await card('Hans Probe').getByRole('button', { name: 'Bearbeiten' }).click();
  await card('Hans Probe').locator('input.hrs').first().fill('5'); await card('Hans Probe').locator('input.hrs').first().blur();
  await page.getByText('Die Dokumente können erstellt werden für: Hans Probe (Korrektur)').waitFor();
  await btn('Dokumente erstellen').click(); await page.getByText('Dokumente erstellt').waitFor({ timeout: 20000 });
  assert.ok(dialogs[dialogs.length - 1].includes('Korrektur für Hans Probe'), 'Rückfrage Korrektur');
  assert.strictEqual(await page.locator('details.mailprev').count(), 1, 'nur Hans');
  assert.strictEqual(await btn('Ansehen', true).count(), 3, 'Hans 2 PDFs + Jahresübersicht');
  await page.locator('details.mailprev > summary').click();
  const kb = await page.innerText('body');
  assert.ok(kb.includes('[TEST] Lohnabrechnung September 2026 / Hans Probe (korrigiert)') && kb.includes('Hier ist deine korrigierte Lohnabrechnung vom September mit der Stundenübersicht.'), 'Korrektur-Betreff und -Text');
  // ohne Netz: Fehler, nichts gesendet; danach nochmals
  const nSend = posts.filter((p) => p.action === 'senden').length;
  offline = true; await btn('Senden, ablegen und sichern (1)').click();
  await page.getByText('Keine Verbindung zu Google').first().waitFor(); await page.getByText('Es wurde nichts gesendet').waitFor();
  offline = false;
  assert.ok(dialogs[dialogs.length - 1].includes('hans@example.com (CC max@example.com) – Korrektur'));
  await btn('Nochmals versuchen (1)').click();
  await page.getByText('Test abgeschlossen: abgelegt, Senden geprüft, gesichert.').waitFor({ timeout: 30000 });
  assert.strictEqual(posts.filter((p) => p.action === 'senden').length, nSend + 1, 'nur Hans gesendet');
  const kd = g.drafts.filter((d) => d.subject === '[TEST] Lohnabrechnung September 2026 / Hans Probe (korrigiert)');
  assert.strictEqual(kd.length, 1); assert.ok(kd[0].body.includes('korrigierte Lohnabrechnung'));
  assert.ok(posts.filter((p) => p.action === 'ablegen').slice(-2).every((p) => p.ordner === '' || p.ordner === 'Hans Probe'), 'nur Jahres-PDF und Hans abgelegt');
  assert.strictEqual(g.live(sub('Hans Probe')).length, 2, 'Hans: weiterhin genau 2 Dateien');
  assert.strictEqual(s.rows[9][col('Anna Netto')], annaNetto, 'Anna unverändert');
  assert.ok(s.rows[9][col('Hans Netto')] !== hansAlt && s.rows[9][col('Hans Netto')] > hansAlt, 'Hans nachgeführt');
  assert.strictEqual(posts.filter((p) => p.action === 'sicherung').length, 2, 'Sicherung nach der Korrektur');
  assert.strictEqual([...g.files.values()].filter((f) => !f._trashed && /^Sicherung Abrechnung/.test(f._name)).length, 1, 'nur die neueste Sicherung');
  await page.reload(); await page.getByPlaceholder('PIN').fill(PIN); await btn('Entsperren').click(); await page.getByText('Abrechnungsmonat').waitFor();
  await card('Hans Probe').getByText(/Korrektur gesendet am/).waitFor();
  assert.strictEqual(await page.getByText('✓ gesendet', { exact: true }).count(), 4, 'Hans nach der Korrektur wieder gesperrt');
  assert.ok(!/\bnull\b|undefined|NaN/.test(await page.innerText('body')), 'keine leeren Werte sichtbar');
  await shot('p2-06-korrektur'); ok('Korrektur: nur Hans, «(korrigiert)», ohne Netz nichts gesendet, danach ersetzt und gesichert');

  assert.deepStrictEqual(errors, [], errors.join('\n'));
  const jp = g.live(y26()).find((f) => f._name === 'Jahresübersicht Löhne Assistenz 2026.pdf');
  const jbuf = Buffer.from(jp._bytes.map((b) => (b + 256) % 256)); fs.writeFileSync(path.join(OUT, 'p2-jahresuebersicht.pdf'), jbuf);
  const { execSync } = require('child_process');
  const jtxt = execSync('pdftotext -layout ' + JSON.stringify(path.join(OUT, 'p2-jahresuebersicht.pdf')) + ' -').toString();
  assert.ok(/9 von 12/.test(jtxt) && /947\.00/.test(jtxt), 'abgelegtes Jahres-PDF enthält die übernommenen Monate');
  console.log('ok - abgelegtes Jahres-PDF enthält 9 von 12 Monaten');
  await browser.close(); console.log('ALLE APP-TESTS OK');
})().catch((e) => { console.error('TESTFEHLER:', e.message); process.exit(1); });
