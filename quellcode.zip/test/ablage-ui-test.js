// Gesamttest Phase 2 (Handy-Format, erfundene Daten): Dokumente erstellen -> Drive-Ablage (Sicherung greift) ->
// Jahresdaten übernehmen -> Ablage -> Gmail-Entwürfe. Google ist nachgebaut (google-mock.js), kein Netz.
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const assert = require('assert');
const { makeGoogle } = require('./google-mock');
const OUT = path.join(__dirname, 'ui-out'); fs.mkdirSync(OUT, { recursive: true });
const KEY = 'testkey-abruf-0123456789'; const PIN = '123456';
const ok = (s) => console.log('ok -', s);
const MON = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

const g = makeGoogle();
const realFiles0 = g.files.size;
// Bestehende Jahrestabelle im Test-Ordner mit Januar bis August (erfunden)
const testFolder = g.folder('_TEST Beispieldaten', g.main);
const header = ['Monat', 'Anna Brutto', 'Anna Netto', 'Maria Brutto', 'Maria Netto', 'Hans Netto', 'Peter Netto', 'Total Stunden'];
const oldRows = [header].concat(MON.map((m, i) => (i < 8 ? [m, 1000 + i, 947 + i, 800, 757.6, i === 2 ? "1'234.50" : 600, '', 70 + i] : [m, '', '', '', '', '', '', '']))).concat([['Total', '', '', '', '', '', '', '']]);
const sheet = g.spreadsheet('Jahresübersicht Löhne Assistenz 2026', testFolder, oldRows);

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push(e.message)); page.on('console', (m) => { if (m.type() === 'error' && !(offline && /Failed to load resource/.test(m.text()))) errors.push('console: ' + m.text()); });
  let dialogAnswer = true; const dialogs = []; page.on('dialog', (d) => { dialogs.push(d.message()); return dialogAnswer ? d.accept() : d.dismiss(); });
  let offline = false; const posts = [];
  await page.route('https://script.google.com/**', async (route) => {
    if (offline) return route.abort();
    const req = route.request(); let body;
    if (req.method() === 'POST') {
      const p = JSON.parse(req.postData()); posts.push(p);
      assert.ok(!/application\/json/.test(req.headers()['content-type'] || ''), 'kein JSON-Content-Type (sonst Vorabfrage)');
      body = g.post(p);
    } else body = g.get(Object.fromEntries(new URL(req.url()).searchParams));
    route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(body) });
  });
  const shot = (n) => page.screenshot({ path: path.join(OUT, n + '.png'), fullPage: true });
  const btn = (name, exact) => page.getByRole('button', { name, exact: !!exact });

  await page.goto('http://localhost:8765/');
  await page.getByPlaceholder('PIN (6–8 Ziffern)').fill(PIN); await page.getByPlaceholder('PIN wiederholen').fill(PIN);
  await btn('Mit erfundenen Beispieldaten starten').click(); await page.getByText('Abrechnungsmonat').waitFor();
  // Schlüssel eintragen
  await btn('Einstellungen').click(); await page.getByLabel('Abruf-Schlüssel').fill(KEY); await page.getByLabel('Abruf-Schlüssel').blur();
  await btn('Abrechnung', true).click();
  // Monat September 2026 wie im bestehenden UI-Test vorbereiten
  await page.locator('select').nth(0).selectOption('9'); await page.locator('select').nth(1).selectOption('2026');
  await btn('Beispiel-CSV laden').click(); await page.getByText('eingelesen').waitFor();
  await page.locator('.card', { hasText: 'Peter Test' }).getByRole('button', { name: 'Hat nicht gearbeitet' }).click();
  await page.locator('.card', { hasText: 'Maria Demo' }).getByRole('button', { name: 'Stunden eintragen' }).click();
  await page.locator('select').filter({ hasText: 'Bitte wählen' }).selectOption('abziehen');
  await page.getByPlaceholder('z. B. 36').fill('36'); await page.getByPlaceholder('z. B. 36').blur();
  await btn('Verteilung vorschlagen').click(); await page.getByText('Summe stimmt mit dem Total').waitFor();
  await btn('Dokumente erstellen').click(); await page.getByText('Dokumente erstellt').waitFor({ timeout: 20000 });
  await page.getByText('Testmodus (erfundene Daten)').waitFor();
  ok('Dokumente erstellt, Testmodus erkannt');

  // 1) Ablage: Sicherung greift (Tabelle hat 8 Monate, App 1)
  await btn('Im Drive ablegen').click();
  await page.getByText('enthält 8 Monate, die App erst 1').waitFor();
  assert.ok(sheet._sheets[0].rows[1][1] === 1000 && sheet._sheets[0].rows.length === oldRows.length, 'Tabelle unverändert');
  assert.strictEqual(posts.filter((p) => p.action === 'ablegen').length, 0, 'keine PDFs abgelegt, wenn Tabelle verweigert');
  await shot('p2-01-sicherung'); ok('Sicherung: Ablage stoppt vor dem Überschreiben der Jahrestabelle');

  // 2) Jahresdaten übernehmen
  await btn('Zu „Jahr“: Jahresdaten übernehmen').click();
  await btn('Tabelle lesen und prüfen').click();
  await page.getByText('Neu in die App:').waitFor();
  const body = await page.innerText('body');
  assert.ok(body.includes('Januar, Februar, März, April, Mai, Juni, Juli, August'), 'acht Monate zur Übernahme');
  assert.ok(body.includes("1'234.50"), 'Wert mit Apostroph gelesen');
  assert.ok(/«Anna Brutto» → Anna Beispiel Brutto/.test(body) && /«Peter Netto» → Peter Test Netto/.test(body), 'Spaltenzuordnung angezeigt');
  await shot('p2-02-uebernahme');
  await btn('Übernehmen').click(); await page.getByText('8 Monate übernommen').waitFor();
  await page.getByText('Abgerechnete Monate: 9 von 12').waitFor();
  const yb = await page.innerText('body'); assert.ok(yb.includes('Total') && yb.includes('947.00'), 'Januar Anna Netto in der Jahresansicht');
  await shot('p2-03-jahr'); ok('Jahresdaten übernommen: 9 von 12 Monaten in der App');

  // 3) Ablage komplett
  await btn('Abrechnung', true).click();
  await btn('Nochmals im Drive ablegen').click();
  await page.getByText('Alles im Drive abgelegt.').waitFor({ timeout: 20000 });
  const s = sheet._sheets[0];
  const col = (hd) => { const j = s.rows[0].indexOf(hd); assert.ok(j > 0, 'Spalte ' + hd); return j; };
  assert.deepStrictEqual(s.rows[0], ['Monat', 'Anna Brutto', 'Anna Netto', 'Hans Netto', 'Peter Netto', 'Maria Brutto', 'Maria Netto', 'Total Stunden']);
  assert.strictEqual(s.rows[1][0], 'Januar'); assert.strictEqual(s.rows[1][col('Anna Netto')], 947); assert.strictEqual(s.rows[3][col('Hans Netto')], 1234.5, 'März Hans übernommen');
  assert.strictEqual(s.rows[1][col('Maria Netto')], 757.6); assert.strictEqual(s.rows[1][col('Peter Netto')], '', 'Peter leer');
  assert.strictEqual(s.rows[8][col('Total Stunden')], 77, 'August Stunden aus Tabelle');
  assert.ok(s.rows[9][0] === 'September' && typeof s.rows[9][col('Anna Netto')] === 'number' && s.rows[9][col('Anna Netto')] > 0, 'September eingetragen');
  assert.strictEqual(s.rows[10][1], '', 'Oktober leer');
  assert.ok(Object.values(s.formulas).includes('=SUM(B2:B13)'), 'Totals als Formel');
  assert.ok(!sheet._file._trashed, 'gleiche Tabelle, nicht im Papierkorb');
  const sub = (n) => [...g.folders.values()].find((f) => f._name === n && f._parent === testFolder);
  for (const n of ['Anna Beispiel', 'Hans Probe', 'Maria Demo']) {
    const names = g.live(sub(n)).map((f) => f._name).sort();
    assert.deepStrictEqual(names, [`2026-09 Lohnabrechnung ${n}.pdf`, `2026-09 Stundenübersicht ${n}.pdf`], n);
    g.live(sub(n)).forEach((f) => assert.strictEqual(Buffer.from(f._bytes.map((b) => (b + 256) % 256)).slice(0, 4).toString(), '%PDF'));
  }
  assert.deepStrictEqual(g.live(sub('Peter Test')).map((f) => f._name), ['2026-09 Lohnabrechnung Peter Test.pdf'], 'nicht gearbeitet: nur Lohnabrechnung');
  assert.strictEqual(s.rows[9][col('Peter Netto')], 0, 'September Peter 0.00 in der Tabelle');
  assert.strictEqual(g.live(testFolder).filter((f) => f._name === 'Jahresübersicht Löhne Assistenz 2026.pdf').length, 1);
  assert.strictEqual([...g.files.values()].filter((f) => f._parent === g.main).length, realFiles0, 'im echten Hauptordner nichts Neues');
  await shot('p2-04-abgelegt'); ok('Ablage: 3 Personen je 2 PDFs, Jahres-PDF, Tabelle mit 9 Monaten – nur im Test-Ordner');

  // nochmals ablegen -> keine Doppel
  await btn('Nochmals im Drive ablegen').click(); await page.waitForTimeout(500); await page.getByText('Alles im Drive abgelegt.').waitFor();
  assert.strictEqual(g.live(sub('Anna Beispiel')).length, 2); assert.strictEqual([...g.files.values()].filter((f) => f._parent === sub('Anna Beispiel') && f._trashed).length, 2);
  ok('erneutes Ablegen: alte Versionen im Papierkorb, keine Doppel');

  // 4) Gmail-Entwürfe
  await btn('Entwürfe ansehen').click();
  await page.getByText('[TEST] Lohnabrechnung September 2026 / Anna Beispiel').waitFor();
  const mb = await page.innerText('body');
  assert.ok(mb.includes('Liebe Anna') && mb.includes('Lieber Hans') && mb.includes('Liebe Maria'), 'Anrede');
  assert.ok(mb.includes('Hier ist deine Lohnabrechnung vom September mit der Stundenübersicht.') && mb.includes('Vielen Dank für deine Unterstützung! ❤️') && mb.includes('Liebe Grüsse\nRoger'));
  assert.ok(mb.includes('max@example.com') && mb.includes('[TEST] Lohnabrechnung September 2026 / Peter Test'));
  assert.ok(mb.includes('Lieber Peter\n\nHier ist deine Lohnabrechnung vom September.\n'), 'eigener Satz ohne Stundenübersicht');
  assert.strictEqual(g.drafts.length, 0, 'Ansehen erstellt noch nichts');
  await shot('p2-05-entwuerfe');
  await btn('Entwürfe in Gmail erstellen').click(); await page.getByText('Die Entwürfe liegen in Gmail.').waitFor({ timeout: 20000 });
  const act = g.ctx.GmailApp.getDrafts();
  assert.strictEqual(act.length, 4);
  const pe = act.find((d) => d.to === 'peter@example.com'); assert.ok(pe && pe.attachments.length === 1 && pe.attachments[0].name === '2026-09 Lohnabrechnung Peter Test.pdf', 'Peter: ein Anhang');
  const a = act.find((d) => d.to === 'anna@example.com');
  assert.ok(a && a.cc === 'max@example.com' && a.subject === '[TEST] Lohnabrechnung September 2026 / Anna Beispiel' && a.attachments.map((x) => x.name).join() === '2026-09 Lohnabrechnung Anna Beispiel.pdf,2026-09 Stundenübersicht Anna Beispiel.pdf');
  await btn('Entwürfe nochmals erstellen (ersetzt sie)').click(); await page.getByText('Entwurf ersetzt').first().waitFor();
  await page.getByText('Die Entwürfe liegen in Gmail.').waitFor();
  assert.strictEqual(g.ctx.GmailApp.getDrafts().length, 4, 'keine doppelten Entwürfe');
  await shot('p2-06-gmail'); ok('4 Gmail-Entwürfe (3 mit 2 PDFs, Peter mit Lohnabrechnung 0.00) mit CC; erneut erstellen ersetzt sie');

  // 4b) Senden: Rückfrage abbrechen -> nichts; bestätigen -> im Test nur simuliert
  dialogAnswer = false; await btn('Jetzt senden (4)').click(); await page.waitForTimeout(300);
  assert.ok(/4 E-Mails jetzt wirklich senden\?/.test(dialogs[dialogs.length - 1]) && dialogs[dialogs.length - 1].includes('anna@example.com (CC max@example.com)'), 'Rückfrage zeigt Empfänger');
  assert.ok(!posts.some((p) => p.action === 'senden'), 'abgebrochen: nichts gesendet');
  dialogAnswer = true; await btn('Jetzt senden (4)').click();
  await page.getByText('Test abgeschlossen: Senden geprüft.').waitFor({ timeout: 20000 });
  assert.strictEqual(posts.filter((p) => p.action === 'senden').length, 4); assert.strictEqual(g.sent.length, 0, 'im Test nichts wirklich gesendet');
  assert.ok(!(await page.getByRole('button', { name: /Jetzt senden/ }).count()), 'kein zweites Senden');
  assert.ok(!(await page.getByRole('button', { name: /Entwürfe nochmals erstellen/ }).count()), 'nach dem Senden keine neuen Entwürfe');
  await shot('p2-07-senden'); ok('Senden: Rückfrage mit Empfängern, Abbrechen sendet nichts, danach gesperrt (Test: nur simuliert)');

  // 5) Ohne Netz
  offline = true; await btn('Nochmals im Drive ablegen').click(); await page.getByText('Keine Verbindung zu Google').first().waitFor();
  offline = false; ok('ohne Netz: verständliche Meldung');

  // 6) Daten im Gerät bleiben verschlüsselt (auch übernommene Monate)
  const stored = await page.evaluate(() => localStorage.getItem('abrechnung_vault_v1'));
  assert.ok(!/Anna|947|Januar/.test(stored));
  // Schlüssel nie in einer URL
  assert.ok(posts.every((p) => p.k === KEY) && posts.length > 0);
  ok('Schlüssel nur im Inhalt der Anfrage, Daten verschlüsselt gespeichert');

  assert.deepStrictEqual(errors, [], errors.join('\n'));
  const jp = g.live(testFolder).find((f) => f._name === 'Jahresübersicht Löhne Assistenz 2026.pdf');
  const jbuf = Buffer.from(jp._bytes.map((b) => (b + 256) % 256)); fs.writeFileSync(path.join(OUT, 'p2-jahresuebersicht.pdf'), jbuf);
  const { execSync } = require('child_process');
  const jtxt = execSync('pdftotext -layout ' + JSON.stringify(path.join(OUT, 'p2-jahresuebersicht.pdf')) + ' -').toString();
  assert.ok(/9 von 12/.test(jtxt) && /947\.00/.test(jtxt), 'abgelegtes Jahres-PDF enthält die übernommenen Monate');
  console.log('ok - abgelegtes Jahres-PDF enthält 9 von 12 Monaten');
  await browser.close(); console.log('ALLE APP-TESTS OK');
})().catch((e) => { console.error('TESTFEHLER:', e.message); process.exit(1); });
