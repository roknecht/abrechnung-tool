const assert = require('assert');
const C = require('../src/core.js');

let n = 0; const ok = (name) => { n++; console.log('ok -', name); };
const S = { stundenlohn: 35, ferien: 8.33, ahv: 5.3, freibetrag: 1400 };

// 1) Beispiel aus der Design-Vorlage: 36 h, mit AHV
{
  const r = C.calcPerson({ ahvAbzug: true }, 3600, S);
  assert.strictEqual(r.lohnC, 126000); assert.strictEqual(r.ferienC, 10495); assert.strictEqual(r.bruttoC, 136495);
  assert.strictEqual(r.ahvC, 7235); assert.strictEqual(r.nettoC, 129260);
  assert.strictEqual(C.fmtMoney(r.bruttoC), "1'364.95"); assert.strictEqual(C.fmtMoney(r.nettoC), "1'292.60");
  ok('Vorlage 36 h: 1\'364.95 / AHV 72.35 / Netto 1\'292.60');
}

// 2) Gegenprobe mit unabhängiger Ganzzahl-Rechnung (BigInt) über alle Stundenwerte 0.01..250.00 h
{
  const half = (num, den) => (2n * num + den) / (2n * den); // kaufmännisch gerundet, num >= 0
  let cnt = 0;
  for (let hc = 1; hc <= 25000; hc++) {
    const lohn = BigInt(hc) * 35n; // Rappen: hc/100 h * 3500 Rp = hc * 35
    const lohnR = half(lohn, 5n) * 5n;
    const ferien = half(lohnR * 833n, 50000n) * 5n; // lohnR * 8.33 % in 5-Rappen-Einheiten
    const brutto = lohnR + ferien;
    const ahv = half(brutto * 53n, 5000n) * 5n;
    const r = C.calcPerson({ ahvAbzug: true }, hc, S);
    assert.strictEqual(BigInt(r.lohnC), lohnR, 'Lohn ' + hc);
    assert.strictEqual(BigInt(r.ferienC), ferien, 'Ferien ' + hc);
    assert.strictEqual(BigInt(r.ahvC), ahv, 'AHV ' + hc);
    assert.strictEqual(r.bruttoC % 5, 0); assert.strictEqual(r.nettoC % 5, 0);
    assert.strictEqual(r.nettoC, r.bruttoC - r.ahvC);
    cnt++;
  }
  ok(`Berechnung stimmt mit unabhängiger Rechnung überein (${cnt} Fälle)`);
}

// 3) Freibetrag: ohne AHV-Abzug
{
  const a = C.calcPerson({ ahvAbzug: false }, 3600, S);
  assert.strictEqual(a.ahvC, 0); assert.strictEqual(a.excess, false); assert.strictEqual(a.nettoC, a.bruttoC);
  const b = C.calcPerson({ ahvAbzug: false }, 4000, S); // 40 h: 1400.00 + 116.60 = 1516.60
  assert.strictEqual(b.lohnC, 140000); assert.strictEqual(b.ferienC, 11660); assert.strictEqual(b.bruttoC, 151660);
  assert.strictEqual(b.excess, true); assert.strictEqual(b.ahvC, 0);
  const c = C.calcPerson({ ahvAbzug: false }, 4000, S, { excessMode: 'abziehen' });
  assert.strictEqual(c.ahvBasisC, 11660); assert.strictEqual(c.ahvC, 620); // 116.60 x 5.3 % = 6.18 -> 6.20
  const edge = C.calcPerson({ ahvAbzug: false }, 3500, S); // 35 h = 1225 + 102.05 = 1327.05
  assert.strictEqual(edge.excess, false);
  ok('Freibetrag-Warnung ab CHF 1\'400.00 (nur ohne AHV-Abzug)');
}

// 4) Rundung
{
  assert.strictEqual(C.round5(2), 0); assert.strictEqual(C.round5(3), 5); assert.strictEqual(C.round5(7), 5);
  assert.strictEqual(C.round5(8), 10); assert.strictEqual(C.round5(12.5), 15);
  assert.strictEqual(C.fmtMoney(5), '0.05'); assert.strictEqual(C.fmtMoney(123456789), "1'234'567.89");
  ok('Rundung auf 5 Rappen und Format');
}

// 5) Verteilung auf Sonntage und Donnerstage (4/5 Stunden, wenn nötig so wenige 3er wie möglich)
{
  let tested = 0; let errs = 0; let with3 = 0;
  for (let m = 1; m <= 12; m++) {
    const days = C.sundaysThursdays(2026, m); const D = days.length;
    days.forEach((d) => assert.ok([0, 4].includes(C.weekday(d))));
    for (let T = 1; T <= 5 * D + 3; T++) {
      const res = C.distribute(T, days);
      const feas = (c) => { for (let k = 0; k + c <= D; k++) { const rest = T - 3 * c - 4 * k; if (rest >= 0 && rest <= k) return true; } return false; };
      let minC = -1; for (let c = 0; c <= D; c++) if (feas(c)) { minC = c; break; }
      if (minC < 0) { assert.ok(res.error, `Fehler erwartet T=${T} m=${m}`); errs++; continue; }
      assert.ok(!res.error, `kein Fehler erwartet T=${T} m=${m}: ${res.error}`);
      const sum = res.days.reduce((a, x) => a + x.hc, 0);
      assert.strictEqual(sum, T * 100, `Summe T=${T} m=${m}`);
      res.days.forEach((x) => { assert.ok([300, 400, 500].includes(x.hc)); assert.ok(days.includes(x.date)); });
      assert.strictEqual(res.days.filter((x) => x.hc === 300).length, minC, `Anzahl 3er T=${T} m=${m}`);
      if (minC) with3++;
      assert.strictEqual(new Set(res.days.map((x) => x.date)).size, res.days.length);
      tested++;
    }
  }
  [[1, true], [2, true], [3, false], [6, false], [7, false], [11, false], [13, false], [14, false]].forEach(([T, err]) => assert.strictEqual(!!C.distribute(T, C.sundaysThursdays(2026, 10)).error, err, 'T=' + T));
  assert.ok(C.distribute(36.5, C.sundaysThursdays(2026, 8)).error);
  ok(`Verteilung: Summe exakt in ${tested} Fällen (davon ${with3} mit 3-Stunden-Einsätzen), ${errs} unmögliche Totale gemeldet`);
}

// 6) Wochentage / Daten
{
  assert.strictEqual(C.weekdayName('2026-08-01'), 'Samstag'); assert.strictEqual(C.weekdayName('2026-10-21'), 'Mittwoch');
  assert.strictEqual(C.fmtDate('2026-08-01'), '01.08.2026'); assert.strictEqual(C.nextMonthFirst(2026, 12), '2027-01-01');
  assert.strictEqual(C.sundaysThursdays(2026, 8).length, 9); // So: 2,9,16,23,30 / Do: 6,13,20,27
  ok('Datumsfunktionen');
}

// 7) Clockify-CSV
{
  const persons = [
    { id: 'a', name: 'Anna Beispiel', kurzname: 'Anna Beispiel', email: 'anna@example.com', ahvAbzug: true },
    { id: 'b', name: 'Hans Probe', kurzname: 'Hans Probe', email: 'hans@example.com', clockifyKey: 'hans.clock@example.org', ahvAbzug: false },
  ];
  const head = 'Project,Client,Description,Task,User,Group,Email,Tags,Billable,Start Date,Start Time,End Date,End Time,Duration (h),Duration (decimal),Billable Rate (CHF),Billable Amount (CHF)';
  const csv = [head,
    '"","","Einsatz, Morgen","","Anna Beispiel","","anna@example.com","","No",08/01/2026,08:00:00 AM,08/01/2026,12:20:00 PM,04:20:00,4.33,0,0',
    ',,,,Anna Beispiel,,anna@example.com,,No,08/03/2026,10:00:00 PM,08/04/2026,02:00:00 AM,04:00:00,4.00,0,0',
    ',,,,Anna Beispiel,,anna@example.com,,No,08/03/2026,10:00:00 PM,08/04/2026,02:00:00 AM,04:00:00,4.00,0,0',
    ',,,,Hans Probe,,hans.clock@example.org,,No,08/05/2026,09:00:00 AM,08/05/2026,02:30:00 PM,05:30:00,5.50,0,0',
    ',,,,Hans Probe,,hans.clock@example.org,,No,08/05/2026,03:00:00 PM,08/05/2026,04:15:00 PM,01:15:00,1.25,0,0',
    ',,,,Hans Probe,,hans.clock@example.org,,No,07/31/2026,09:00:00 AM,07/31/2026,10:00:00 AM,01:00:00,1.00,0,0',
    ',,,,Fremd Person,,fremd@example.com,,No,08/05/2026,09:00:00 AM,08/05/2026,10:00:00 AM,01:00:00,1.00,0,0',
  ].join('\n');
  const r = C.importClockify(csv, 2026, 8, persons);
  assert.deepStrictEqual(r.errors, []);
  assert.strictEqual(r.byPerson.a.days['2026-08-01'], 433);
  assert.strictEqual(r.byPerson.a.days['2026-08-03'], 800); // Dublette zählt (mit Warnung), Starttag
  assert.ok(r.warnings.some((w) => w.includes('Dublette')));
  assert.ok(r.warnings.some((w) => w.includes('Mitternacht')));
  assert.strictEqual(r.byPerson.b.days['2026-08-05'], 675); // 5.50 + 1.25
  assert.strictEqual(r.outside.length, 1); assert.strictEqual(r.unmatched.length, 1);
  assert.strictEqual(r.unmatched[0].user, 'Fremd Person');
  ok('Clockify-CSV (englisch, US-Datum, Anführungszeichen, Mitternacht, Dublette, anderer Monat, Fremder)');

  const de = ['Benutzer;E-Mail;Startdatum;Startzeit;Enddatum;Endzeit;Dauer (h);Dauer (dezimal)',
    'Hans Probe;hans@example.com;21.08.2026;09:00;21.08.2026;11:20;02:20:00;2,33'].join('\r\n');
  const r2 = C.importClockify(de, 2026, 8, persons);
  assert.deepStrictEqual(r2.errors, []); assert.strictEqual(r2.byPerson.b.days['2026-08-21'], 233);
  ok('Clockify-CSV (deutsch, Semikolon, Punktdatum)');

  const bad = C.importClockify('a,b\n1,2', 2026, 8, persons);
  assert.ok(bad.errors.length > 0);
  ok('Unbekanntes Format wird gemeldet');
}

console.log(`\n${n} Testgruppen bestanden`);
