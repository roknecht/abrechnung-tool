// Nachbau der Google-Dienste (Drive, Tabellen, Gmail) für Tests – nur erfundene Daten, kein Netz.
const fs = require('fs'); const path = require('path'); const vm = require('vm');

function makeGoogle(opts) {
  opts = opts || {};
  let nextId = 1; const id = (p) => p + (nextId++);
  const files = new Map(); const folders = new Map();
  const iter = (arr) => { let i = 0; return { hasNext: () => i < arr.length, next: () => arr[i++] }; };

  function folder(name, parent) {
    const f = { _id: id('fo'), _name: name, _parent: parent || null, _trashed: false,
      getId: () => f._id, getName: () => f._name,
      getFolders: () => iter([...folders.values()].filter((x) => x._parent === f && !x._trashed)),
      getFiles: () => iter([...files.values()].filter((x) => x._parent === f && !x._trashed)),
      getFilesByType: (mime) => iter([...files.values()].filter((x) => x._parent === f && !x._trashed && x._mime === mime)),
      createFolder: (n) => folder(n, f),
      createFile: (blob) => file(blob.name, blob.mime, f, blob.bytes),
    };
    folders.set(f._id, f); return f;
  }
  function file(name, mime, parent, bytes) {
    const f = { _id: id('fi'), _name: name, _mime: mime, _parent: parent, _trashed: false, _bytes: bytes,
      getId: () => f._id, getName: () => f._name, setTrashed: (t) => { f._trashed = !!t; },
      moveTo: (fo) => { f._parent = fo; return f; }, getParents: () => iter(f._parent ? [f._parent] : []),
    };
    files.set(f._id, f); return f;
  }

  // Tabellen
  function sheet(rows) {
    const s = { rows: rows || [], formulas: {}, frozen: 0, bold: [],
      getDataRange: () => ({ getValues: () => s.rows.map((r) => r.slice()) }),
      clear: () => { s.rows = []; s.formulas = {}; },
      setFrozenRows: (n) => { s.frozen = n; },
      getRange: (r, c, nr = 1, nc = 1) => {
        const rg = {
          setValues: (v) => { for (let i = 0; i < v.length; i++) { s.rows[r - 1 + i] = s.rows[r - 1 + i] || []; for (let j = 0; j < v[i].length; j++) s.rows[r - 1 + i][c - 1 + j] = v[i][j]; } return rg; },
          setValue: (v) => { s.rows[r - 1] = s.rows[r - 1] || []; s.rows[r - 1][c - 1] = v; return rg; },
          setFormulas: (v) => { for (let j = 0; j < v[0].length; j++) { s.formulas[`${r},${c + j}`] = v[0][j]; s.rows[r - 1] = s.rows[r - 1] || []; s.rows[r - 1][c - 1 + j] = v[0][j]; } return rg; },
          setNumberFormat: () => rg, setFontWeight: (w) => { s.bold.push([r, w]); return rg; },
        };
        return rg;
      },
    };
    // Lücken im Array auffüllen (wie getValues: rechteckig)
    const gv = s.getDataRange; s.getDataRange = () => { const w = Math.max(0, ...s.rows.map((r) => (r || []).length)); return { getValues: () => s.rows.map((r) => Array.from({ length: w }, (_, j) => ((r || [])[j] === undefined ? '' : r[j]))) }; };
    void gv; return s;
  }
  const spreads = new Map();
  function spreadsheet(name, parent, rows) {
    const f = file(name, 'application/vnd.google-apps.spreadsheet', parent, null);
    const ss = { _file: f, _sheets: [sheet(rows)], getId: () => f._id, getName: () => f._name, getUrl: () => 'https://docs.example/' + f._id, getSheets: () => ss._sheets };
    spreads.set(f._id, ss); return ss;
  }

  const myDrive = folder('Meine Ablage');
  const main = folder(opts.mainName || 'Assistenzpersonenabrechnungen', myDrive);
  const stunden = spreadsheet('Stundenerfassung Assistenz', main, []);

  const drafts = []; let draftId = 1;
  let getMessageCalls = 0;
  const GmailApp = {
    getDrafts: () => drafts.filter((d) => !d._deleted),
    // vereinfachte Gmail-Suche: in:drafts subject:"…" (Wortsuche wie Gmail: Teilstring genügt)
    search: (q) => {
      const m = q.match(/subject:"([^"]*)"/); const s = m ? m[1] : '';
      return drafts.filter((d) => !d._deleted && /in:drafts/.test(q) && d.subject.includes(s.replace(/^\[TEST\] /, '')))
        .map((d) => ({ getMessages: () => [{ isDraft: () => true, getSubject: () => d.subject, getId: () => 'm' + d._id }] }));
    },
    createDraft: (to, subject, body, o) => { const d = { _id: 'dr' + (draftId++), to, subject, body, cc: o && o.cc, attachments: (o && o.attachments) || [], getId: () => d._id, getMessageId: () => 'm' + d._id, getMessage: () => { getMessageCalls++; return { getSubject: () => d.subject }; }, deleteDraft: () => { d._deleted = true; } }; drafts.push(d); return d; },
    _calls: () => getMessageCalls,
  };

  const props = Object.assign({ ABRUF_KEY: 'testkey-abruf-0123456789' }, opts.props || {});
  const ctx = {
    PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => (k in props ? props[k] : null) }) },
    SpreadsheetApp: {
      getActiveSpreadsheet: () => ({ getId: () => stunden.getId(), getSheetByName: (n) => (opts.erfassungSheets || {})[n] || null, insertSheet: (n) => { const s = sheet([]); (opts.erfassungSheets || (opts.erfassungSheets = {}))[n] = s; return s; } }),
      openById: (i) => { const s = spreads.get(i); if (!s || s._file._trashed) throw new Error('nicht gefunden'); return s; },
      create: (name) => spreadsheet(name, myDrive, []),
    },
    DriveApp: {
      getFileById: (i) => { const f = files.get(i); if (!f) throw new Error('Datei nicht gefunden'); return f; },
      getFolderById: (i) => { const f = folders.get(i); if (!f) throw new Error('Ordner nicht gefunden'); return f; },
    },
    MimeType: { GOOGLE_SHEETS: 'application/vnd.google-apps.spreadsheet' },
    GmailApp,
    Utilities: { base64Decode: (s) => Array.from(Buffer.from(s, 'base64')).map((b) => (b > 127 ? b - 256 : b)), newBlob: (bytes, mime, name) => ({ bytes, mime, name }), formatDate: (d) => String(d) },
    MailApp: { sendEmail: () => { throw new Error('MailApp.sendEmail darf hier nicht aufgerufen werden'); }, getRemainingDailyQuota: () => 100 },
    Session: { getEffectiveUser: () => ({ getEmail: () => 'besitzer@example.com' }) },
    Logger: { log: () => {} },
    LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
    ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (t) => ({ t, setMimeType() { return this; } }) },
    JSON, Date, String, Number, isFinite, isNaN, Math, RegExp, Object, Array,
  };
  vm.createContext(ctx);
  vm.runInContext(fs.readFileSync(path.join(__dirname, '..', 'erfassung', 'Code.gs'), 'utf8'), ctx);
  const post = (body) => JSON.parse(ctx.doPost({ postData: { contents: JSON.stringify(body) } }).t);
  const get = (params) => JSON.parse(ctx.doGet({ parameter: params }).t);
  const live = (fo) => [...files.values()].filter((f) => f._parent === fo && !f._trashed);
  return { ctx, post, get, main, myDrive, files, folders, folder, file, spreadsheet, spreads, drafts, live, props };
}
module.exports = { makeGoogle };
