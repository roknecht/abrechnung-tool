// UI-Test mit erfundenen Daten (Headless-Chromium, Handy-Format)
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const assert = require('assert');
const OUT = path.join(__dirname, 'ui-out'); fs.rmSync(OUT, { recursive: true, force: true }); fs.mkdirSync(OUT, { recursive: true });
const URL = 'http://localhost:8765/';
const PIN = '123456';

(async () => {
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 390, height: 844 }, acceptDownloads: true, deviceScaleFactor: 2 });
  const page = await ctx.newPage();
  const errors = []; page.on('pageerror', (e) => errors.push('pageerror: ' + e.message)); page.on('console', (m) => { if (m.type() === 'error') errors.push('console: ' + m.text()); });
  page.on('dialog', (d) => d.accept(d.type() === 'prompt' ? (d.message().includes('Neue PIN') ? '654321' : PIN) : undefined));
  const shot = (n) => page.screenshot({ path: path.join(OUT, n + '.png'), fullPage: true });
  const step = (s) => console.log('ok -', s);

  await page.goto(URL);
  // 1) Einrichtung
  await page.getByPlaceholder('PIN (6–8 Ziffern)').fill(PIN); await page.getByPlaceholder('PIN wiederholen').fill(PIN);
  await page.getByRole('button', { name: 'Mit erfundenen Beispieldaten starten' }).click();
  await page.getByText('Abrechnungsmonat').waitFor(); await shot('01-start'); step('Einrichtung mit PIN und Beispieldaten');

  // 2) Beispiel-CSV laden
  await page.getByRole('button', { name: 'Beispiel-CSV laden' }).click();
  await page.getByText('eingelesen').waitFor();
  const body1 = await page.innerText('body');
  assert.ok(body1.includes('Unbekannter Benutzer'), 'unbekannter Benutzer wird gemeldet');
  assert.ok(body1.includes('über Mitternacht'), 'Mitternacht wird gemeldet');
  assert.ok(body1.includes('Keine Einträge in diesem Monat gefunden'), 'fehlende Erfassung (Peter) wird abgefragt');
  assert.ok(body1.includes('Achtung: AHV-Lohn über CHF 1\'400.00'), 'Freibetrag-Warnung (Hans)');
  assert.ok(body1.includes('Noch offen'), 'Blocker sichtbar');
  assert.ok(await page.getByRole('button', { name: 'Dokumente erstellen' }).isDisabled(), 'Erstellen gesperrt');
  await shot('02-import'); step('CSV-Import mit Warnungen, Erstellen gesperrt');

  // 3) Entscheidungen treffen
  await page.getByRole('button', { name: 'Ja, nicht gearbeitet' }).click();
  await page.locator('select').filter({ hasText: 'Bitte wählen' }).selectOption('abziehen');
  await page.getByPlaceholder('z. B. 36').fill('36'); await page.getByPlaceholder('z. B. 36').blur();
  await page.getByRole('button', { name: 'Verteilung vorschlagen' }).click();
  await page.getByText('Summe stimmt mit dem Total').waitFor();
  assert.ok(!(await page.getByRole('button', { name: 'Dokumente erstellen' }).isDisabled()), 'Erstellen freigegeben');
  await shot('03-kontrolle'); step('Entscheidungen: nicht gearbeitet, AHV-Vorgehen, Verteilung Summe stimmt');

  // 4) Verteilung von Hand ändern -> Blocker
  const hrsInputs = page.locator('.card', { hasText: 'Maria Demo' }).locator('input.hrs');
  const first = hrsInputs.first(); const old = await first.inputValue();
  await first.fill('9'); await first.blur();
  await page.getByText('≠ Total').waitFor();
  assert.ok(await page.getByRole('button', { name: 'Dokumente erstellen' }).isDisabled(), 'Abweichende Summe sperrt Erstellen');
  await page.locator('.card', { hasText: 'Maria Demo' }).locator('input.hrs').first().fill(old); await page.locator('.card', { hasText: 'Maria Demo' }).locator('input.hrs').first().blur();
  await page.getByText('Summe stimmt mit dem Total').waitFor(); step('Abweichende Summe wird blockiert, Korrektur gibt frei');

  // 5) Dokumente erstellen
  await page.getByRole('button', { name: 'Dokumente erstellen' }).click();
  await page.getByText('Dokumente erstellt').waitFor({ timeout: 20000 }); await shot('04-fertig');
  const names = await page.locator('.file span').allInnerTexts();
  console.log(names.join(' | '));
  assert.ok(names.some((n) => n.includes('Lohnabrechnung Anna Beispiel')) && names.some((n) => n.includes('Stundenübersicht Maria Demo')) && names.some((n) => n.startsWith('Jahresübersicht')));
  assert.ok(names.some((n) => n.includes('Lohnabrechnung Peter Test')) && !names.some((n) => n.includes('Stundenübersicht Peter Test')), 'nicht gearbeitet: nur Lohnabrechnung (0.00)');
  const downloads = []; page.on('download', (d) => downloads.push(d));
  await page.getByRole('button', { name: 'Alle Dateien speichern/teilen' }).click(); await page.waitForTimeout(1500);
  // Der Test-Browser meldet bei Namen mit Umlaut nur "download": Reihenfolge = Reihenfolge der Dateiliste
  for (let i = 0; i < downloads.length; i++) await downloads[i].saveAs(path.join(OUT, names[i]));
  assert.strictEqual(downloads.length, 8, 'je 2 PDFs für 3 Personen + Lohnabrechnung 0.00 für Peter + Jahresübersicht'); step('8 PDFs erstellt, für Peter nur Lohnabrechnung 0.00');

  // 6) Sperre: neu laden
  await page.reload(); await page.getByPlaceholder('PIN').waitFor();
  await page.getByPlaceholder('PIN').fill('000000'); await page.getByRole('button', { name: 'Entsperren' }).click(); await page.getByText('PIN falsch').waitFor();
  await page.getByPlaceholder('PIN').fill(PIN); await page.getByRole('button', { name: 'Entsperren' }).click();
  await page.getByText('Abrechnungsmonat').waitFor();
  const stored = await page.evaluate(() => localStorage.getItem('abrechnung_vault_v1'));
  assert.ok(!/Anna|Beispiel|Muster/.test(stored), 'gespeicherte Daten sind verschlüsselt'); step('Falsche PIN abgewiesen, Daten verschlüsselt gespeichert, Entwurf nach Neustart da');
  assert.ok((await page.innerText('body')).includes('Maria Demo'));

  // 7) Jahresübersicht
  await page.getByRole('button', { name: 'Jahr', exact: true }).click(); await page.getByText('Abgerechnete Monate: 1 von 12').waitFor(); await shot('05-jahr'); step('Jahresübersicht zeigt den Monat');

  // 8) Sicherung und Wiederherstellung
  await page.getByRole('button', { name: 'Einstellungen' }).click();
  const dl = page.waitForEvent('download'); await page.getByRole('button', { name: 'Sicherung speichern' }).click(); const bk = await dl; const bkPath = path.join(OUT, 'sicherung.json'); await bk.saveAs(bkPath);
  await shot('06-einstellungen');
  await page.evaluate(() => localStorage.clear()); await page.reload();
  await page.getByPlaceholder('PIN (6–8 Ziffern)').waitFor();
  await page.locator('input[type=file]').setInputFiles(bkPath); await page.getByText('Sicherung gewählt').waitFor();
  await page.getByPlaceholder('PIN (6–8 Ziffern)').fill(PIN); await page.getByRole('button', { name: 'Sicherung laden' }).click();
  await page.getByText('Abrechnungsmonat').waitFor();
  await page.getByRole('button', { name: 'Jahr', exact: true }).click(); await page.getByText('Abgerechnete Monate: 1 von 12').waitFor(); step('Sicherung exportiert und nach Löschen wiederhergestellt');

  console.log(errors.length ? 'FEHLER:\n' + errors.join('\n') : 'keine Browser-Fehler');
  await browser.close(); if (errors.length) process.exit(1);
})().catch((e) => { console.error('TESTFEHLER:', e.message); process.exit(1); });
