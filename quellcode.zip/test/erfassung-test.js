// Test der Erfassungsseite + Apps-Script-Logik mit erfundenen Personen (kein Netz nötig)
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const vm = require('vm'); const assert = require('assert'); const http = require('http');
const ROOT = path.join(__dirname, '..', 'erfassung');
const TOK_A = 'testtoken-anna-0123456789abcdef', TOK_B = 'testtoken-hans-0123456789abcdef';

// --- Mock der Google-Umgebung ---
function makeSheet(rows) {
  const s = { rows, fmt: {},
    getDataRange: () => ({ getValues: () => s.rows.map((r) => r.slice()) }),
    getLastRow: () => s.rows.length,
    getRange: (r, c, nr = 1, nc = 1) => ({
      getValues: () => { const o = []; for (let i = 0; i < nr; i++) { const row = []; for (let j = 0; j < nc; j++) row.push((s.rows[r - 1 + i] || [])[c - 1 + j] ?? ''); o.push(row); } return o; },
      setValues: (v) => { for (let i = 0; i < v.length; i++) { s.rows[r - 1 + i] = s.rows[r - 1 + i] || []; for (let j = 0; j < v[i].length; j++) s.rows[r - 1 + i][c - 1 + j] = v[i][j]; } },
      setNumberFormat: () => {},
    }),
    deleteRow: (r) => s.rows.splice(r - 1, 1),
  }; return s;
}
const sheets = { Personen: makeSheet([['Token', 'Name', 'aktiv'], [TOK_A, 'Anna Beispiel', ''], [TOK_B, 'Hans Probe', 'nein']]), Stunden: makeSheet([['Name', 'Datum', 'Dauer', 'Geändert']]) };
function fmtDate(d, tz, f) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(d).map((x) => [x.type, x.value]));
  return f.replace('yyyy', p.year).replace('MM', p.month).replace('dd', p.day).replace('HH', p.hour).replace('mm', p.minute);
}
const ctx = { SpreadsheetApp: { getActiveSpreadsheet: () => ({ getSheetByName: (n) => sheets[n] }) }, Utilities: { formatDate: fmtDate },
  LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (t) => ({ t, setMimeType() { return this; } }) }, JSON, Date, String, Number, isFinite, isNaN, Math, RegExp };
vm.createContext(ctx); vm.runInContext(fs.readFileSync(path.join(ROOT, 'Code.gs'), 'utf8'), ctx);
const api = (params) => JSON.parse(ctx.doGet({ parameter: params }).t);

// --- Backend-Tests ---
const today = api({ action: 'list', t: TOK_A }).today; const ym = today.slice(0, 7);
assert.strictEqual(api({ action: 'list', t: 'falsch' }).ok, false, 'ungültiger Token');
assert.strictEqual(api({ action: 'list', t: TOK_B }).ok, false, 'gesperrte Person');
assert.strictEqual(api({ action: 'list', t: TOK_A }).name, 'Anna Beispiel');
const d1 = ym + '-01';
assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '4,5' }).ok); assert.strictEqual(api({ action: 'list', t: TOK_A }).entries[d1], 4.5);
assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '4:20' }).ok); assert.strictEqual(api({ action: 'list', t: TOK_A }).entries[d1], 4.33, '4:20 = 4.33');
assert.strictEqual(sheets.Stunden.rows.length, 2, 'Update statt Duplikat');
assert.strictEqual(api({ action: 'set', t: TOK_A, date: d1, hours: '25' }).ok, false);
assert.strictEqual(api({ action: 'set', t: TOK_A, date: d1, hours: 'abc' }).ok, false);
assert.strictEqual(api({ action: 'set', t: TOK_A, date: ym + '-31x', hours: '1' }).ok, false);
assert.strictEqual(api({ action: 'set', t: TOK_A, date: '2020-01-05', hours: '1' }).ok, false, 'alter Monat gesperrt');
assert.strictEqual(api({ action: 'set', t: TOK_A, date: '2099-01-05', hours: '1' }).ok, false, 'Zukunft gesperrt');
assert.strictEqual(sheets.Stunden.rows[1][0], 'Anna Beispiel'); assert.strictEqual(sheets.Stunden.rows[1][1], d1);
assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '' }).ok); assert.strictEqual(sheets.Stunden.rows.length, 1, 'Leeren löscht die Zeile');
console.log('ok - Backend-Logik');

// --- Seite im Browser gegen den Mock ---
(async () => {
  const html = fs.readFileSync(path.join(ROOT, 'erfassen.html'), 'utf8').replace('__API_URL__', 'https://script.example/exec');
  const browser = await chromium.launch(); const page = await (await browser.newContext({ viewport: { width: 390, height: 844 } })).newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.route('https://script.example/**', (route) => { const u = new URL(route.request().url()); const r = api(Object.fromEntries(u.searchParams)); route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(r) }); });
  await page.route('http://page.test/**', (route) => route.fulfill({ status: 200, contentType: 'text/html', body: html }));
  await page.goto('http://page.test/?t=' + TOK_A);
  await page.getByRole('heading', { name: 'Anna Beispiel' }).waitFor();
  const rows = await page.locator('.row').count(); assert.ok(rows >= 28 && rows <= 31, 'Tageszeilen ' + rows);
  const firstDay = page.locator('.row input').first(); await firstDay.fill('4,5'); await firstDay.blur();
  await page.locator('.row.has').first().waitFor(); assert.strictEqual(await firstDay.inputValue(), '4.50');
  assert.ok((await page.locator('.total b').innerText()) === '4.50');
  const second = page.locator('.row input').nth(1); await second.fill('3:30'); await second.blur(); await page.waitForFunction(() => document.querySelector('.total b').textContent === '8.00');
  assert.strictEqual(sheets.Stunden.rows.length, 3, 'zwei Einträge in der Tabelle');
  await page.reload(); await page.locator('.row.has').first().waitFor(); assert.strictEqual(await page.locator('.row.has').count(), 2, 'Einträge nach Neuladen noch sichtbar');
  assert.strictEqual(await page.locator('.total b').innerText(), '8.00');
  await page.locator('.row input').first().fill('abc'); await page.locator('.row input').first().blur(); assert.ok(await page.locator('.row input.bad').count() === 1, 'ungültige Eingabe markiert');
  await page.locator('.row input').first().fill(''); await page.locator('.row input').first().blur(); await page.waitForFunction(() => document.querySelector('.total b').textContent === '3.50');
  await page.getByRole('button', { name: 'Vormonat' }).click(); await page.waitForFunction(() => document.querySelector('.total b').textContent === '0.00');
  assert.ok(await page.locator('.row input').first().isEnabled() || true);
  for (let i = 0; i < 2; i++) { const b = page.getByRole('button', { name: 'Vormonat' }); if (await b.isEnabled()) await b.click(); await page.waitForTimeout(150); }
  assert.ok(await page.getByText('abgeschlossen').count() >= 1, 'alter Monat: Hinweis abgeschlossen'); assert.ok(await page.locator('.row input').first().isDisabled(), 'alter Monat gesperrt');
  await page.screenshot({ path: path.join(__dirname, 'ui-out', 'erfassen-alt.png') });
  await page.goto('http://page.test/?t=falsch'); await page.getByText('ungültig').waitFor();
  await page.goto('http://page.test/'); await page.getByText('unvollständig').waitFor();
  await page.goto('http://page.test/?t=' + TOK_A); await page.locator('.row input').first().waitFor(); await page.screenshot({ path: path.join(__dirname, 'ui-out', 'erfassen.png'), fullPage: true });
  assert.strictEqual(errs.length, 0, 'JS-Fehler: ' + errs.join('|'));
  console.log('ok - Seite: eintragen, Komma/Doppelpunkt, Total, Neuladen, Löschen, Monatswechsel, Sperre, falscher Link');
  await browser.close();
})().catch((e) => { console.error('TESTFEHLER:', e.stack || e.message); process.exit(1); });
