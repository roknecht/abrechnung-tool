// Test der Erfassungsseite + Apps-Script-Logik mit erfundenen Personen (kein Netz nötig)
const { chromium } = require('/opt/npm-tools/node_modules/playwright');
const fs = require('fs'); const path = require('path'); const vm = require('vm'); const assert = require('assert'); const http = require('http');
const ROOT = path.join(__dirname, '..', 'erfassung');
const TOK_A = 'testtoken-anna-0123456789abcdef', TOK_B = 'testtoken-hans-0123456789abcdef';

// --- Mock der Google-Umgebung ---
function makeSheet(rows) {
  const s = { rows, fmt: {},
    getDataRange: () => ({ getValues: () => s.rows.map((r) => r.slice()) }),
    getLastRow: () => s.rows.length,
    getRange: (r, c, nr = 1, nc = 1) => ({
      getValues: () => { const o = []; for (let i = 0; i < nr; i++) { const row = []; for (let j = 0; j < nc; j++) row.push((s.rows[r - 1 + i] || [])[c - 1 + j] ?? ''); o.push(row); } return o; },
      setValues: (v) => { for (let i = 0; i < v.length; i++) { s.rows[r - 1 + i] = s.rows[r - 1 + i] || []; for (let j = 0; j < v[i].length; j++) s.rows[r - 1 + i][c - 1 + j] = v[i][j]; } },
      setNumberFormat: () => {},
    }),
    deleteRow: (r) => s.rows.splice(r - 1, 1),
  }; return s;
}
const sheets = { Personen: makeSheet([['Token', 'Name', 'aktiv'], [TOK_A, 'Anna Beispiel', ''], [TOK_B, 'Hans Probe', 'nein']]), Stunden: makeSheet([['Name', 'Datum', 'Dauer', 'Geändert']]) };
function fmtDate(d, tz, f) {
  const p = Object.fromEntries(new Intl.DateTimeFormat('en-GB', { timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).formatToParts(d).map((x) => [x.type, x.value]));
  return f.replace('yyyy', p.year).replace('MM', p.month).replace('dd', p.day).replace('HH', p.hour).replace('mm', p.minute);
}
const mails = []; let mailFail = false;
// «Heute» im nachgebauten Script = 15. des laufenden Monats, damit der Test auch am Monatsanfang läuft (Tage in der Zukunft sind gesperrt).
const FIX = (() => { const n = new Date(); return new Date(n.getFullYear(), n.getMonth(), 15, 12).getTime(); })();
class FixDate extends Date { constructor(...a) { if (a.length) super(...a); else super(FIX); } static now() { return FIX; } }
const ctx = { PropertiesService: { getScriptProperties: () => ({ getProperty: (k) => (k === 'ABRUF_KEY' ? 'testkey-abruf-0123456789' : null) }) }, SpreadsheetApp: { getActiveSpreadsheet: () => ({ getSheetByName: (n) => sheets[n] || null, insertSheet: (n) => (sheets[n] = makeSheet([])) }) }, Utilities: { formatDate: fmtDate },
  MailApp: { sendEmail: (to, subject, body) => { if (mailFail) throw new Error('Mail-Fehler'); mails.push({ to, subject, body }); } }, Session: { getEffectiveUser: () => ({ getEmail: () => 'besitzer@example.test' }) },
  LockService: { getScriptLock: () => ({ waitLock() {}, releaseLock() {} }) },
  ContentService: { MimeType: { JSON: 'json' }, createTextOutput: (t) => ({ t, setMimeType() { return this; } }) }, JSON, Date: FixDate, String, Number, isFinite, isNaN, Math, RegExp };
vm.createContext(ctx); vm.runInContext(fs.readFileSync(path.join(ROOT, 'Code.gs'), 'utf8'), ctx);
const api = (params) => JSON.parse(ctx.doGet({ parameter: params }).t);

// --- Backend-Tests ---
const today = api({ action: 'list', t: TOK_A }).today; const ym = today.slice(0, 7);
assert.strictEqual(api({ action: 'list', t: 'falsch' }).ok, false, 'ungültiger Token');
assert.strictEqual(api({ action: 'list', t: TOK_B }).ok, false, 'gesperrte Person');
assert.strictEqual(api({ action: 'list', t: TOK_A }).name, 'Anna Beispiel');
const d1 = ym + '-01';
assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '4,5' }).ok); assert.strictEqual(api({ action: 'list', t: TOK_A }).entries[d1], 4.5);
assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '4.25' }).ok); assert.strictEqual(api({ action: 'list', t: TOK_A }).entries[d1], 4.25, '4.25 ok');
for (const good of ['0.25', '0,75', '1', '12', '12.00', '7.5', '4.50']) assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: good }).ok, 'gültig: ' + good);
for (const bad of ['4:30', '3.33', '4.3', '4.26', '0.1', '12.25', '13', '24', '-1', '4.5h', '4,,5', '1e1', ' . ']) { const before = JSON.stringify(sheets.Stunden.rows); assert.strictEqual(api({ action: 'set', t: TOK_A, date: d1, hours: bad }).ok, false, 'abgelehnt: ' + bad); assert.strictEqual(JSON.stringify(sheets.Stunden.rows), before, 'nichts gespeichert: ' + bad); }
assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '4.25' }).ok);
assert.strictEqual(sheets.Stunden.rows.length, 2, 'Update statt Duplikat');
assert.strictEqual(api({ action: 'set', t: TOK_A, date: d1, hours: 'abc' }).ok, false);
assert.strictEqual(api({ action: 'set', t: TOK_A, date: ym + '-31x', hours: '1' }).ok, false);
assert.strictEqual(api({ action: 'set', t: TOK_A, date: '2020-01-05', hours: '1' }).ok, false, 'alter Monat gesperrt');
assert.strictEqual(api({ action: 'set', t: TOK_A, date: '2099-01-05', hours: '1' }).ok, false, 'Zukunft gesperrt');
assert.strictEqual(sheets.Stunden.rows[1][0], 'Anna Beispiel'); assert.strictEqual(sheets.Stunden.rows[1][1], d1);
assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '' }).ok); assert.strictEqual(sheets.Stunden.rows.length, 1, 'Leeren löscht die Zeile');
console.log('ok - Backend-Logik');

// --- Abschluss, Mail, Sperre (erfundene Daten) ---
{
  const prev = (() => { const y = +ym.slice(0, 4), m = +ym.slice(5, 7); return m === 1 ? (y - 1) + '-12' : y + '-' + String(m - 1).padStart(2, '0'); })();
  const pd = prev + '-15';
  assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '4,5' }).ok); assert.ok(api({ action: 'set', t: TOK_A, date: pd, hours: '2.25' }).ok);
  assert.strictEqual(api({ action: 'list', t: TOK_A }).closed, false, 'zu Beginn offen');
  assert.strictEqual(api({ action: 'submit', t: 'falsch', m: ym }).ok, false, 'ungültiger Link kann nicht abschicken');
  assert.strictEqual(api({ action: 'submit', t: TOK_A, m: '2020-01' }).ok, false, 'alter Monat');
  assert.strictEqual(api({ action: 'submit', t: TOK_A, m: 'abc' }).ok, false, 'Monat ungültig');
  const r1 = api({ action: 'submit', t: TOK_A, m: ym });
  assert.ok(r1.ok && r1.total === 4.5 && r1.days === 1 && r1.mail === true, 'Abschicken ok: ' + JSON.stringify(r1));
  assert.strictEqual(mails.length, 1); assert.strictEqual(mails[0].to, 'besitzer@example.test');
  assert.ok(mails[0].subject.includes('Anna Beispiel') && mails[0].subject.includes('Stunden übermittelt') && !mails[0].subject.includes('erneut'), mails[0].subject);
  assert.ok(mails[0].body.includes('4.50') && mails[0].body.includes('1 Tag'), mails[0].body);
  assert.ok(!/AHV|Strasse/.test(mails[0].body), 'keine sensiblen Angaben in der Mail');
  const ab = sheets.Abschluss.rows; assert.strictEqual(ab.length, 2); assert.deepStrictEqual([ab[1][0], ab[1][1], ab[1][2], ab[1][4], ab[1][5]], ['Anna Beispiel', ym, 4.5, 'abgeschickt', 1]);
  assert.strictEqual(api({ action: 'list', t: TOK_A }).closed, true, 'gesperrt');
  assert.strictEqual(api({ action: 'list', t: TOK_A, m: prev }).closed, false, 'anderer Monat bleibt offen');
  assert.strictEqual(api({ action: 'set', t: TOK_A, date: d1, hours: '1' }).ok, false, 'Eintragen im abgeschickten Monat gesperrt');
  assert.ok(api({ action: 'set', t: TOK_A, date: pd, hours: '3' }).ok, 'Vormonat unabhängig');
  const r2 = api({ action: 'submit', t: TOK_A, m: ym }); assert.ok(r2.ok && r2.already === true); assert.strictEqual(mails.length, 1, 'keine doppelte Mail');
  assert.ok(api({ action: 'reopen', t: TOK_A, m: ym }).ok); assert.strictEqual(api({ action: 'list', t: TOK_A }).closed, false, 'wieder offen');
  assert.strictEqual(api({ action: 'reopen', t: TOK_A, m: '2020-01' }).ok, false, 'alter Monat nicht öffnen');
  assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '5' }).ok);
  const r3 = api({ action: 'submit', t: TOK_A, m: ym }); assert.ok(r3.ok && r3.total === 5);
  assert.strictEqual(mails.length, 2); assert.ok(mails[1].subject.includes('(erneut)'), mails[1].subject); assert.strictEqual(sheets.Abschluss.rows[1][5], 2); assert.strictEqual(sheets.Abschluss.rows.length, 2, 'dieselbe Zeile');
  // Roger öffnet von Hand: Status «offen» oder Zeile löschen
  sheets.Abschluss.rows[1][4] = 'offen'; assert.strictEqual(api({ action: 'list', t: TOK_A }).closed, false, 'Status offen');
  sheets.Abschluss.rows[1][4] = 'abgeschickt'; assert.strictEqual(api({ action: 'list', t: TOK_A }).closed, true); sheets.Abschluss.rows.splice(1, 1); assert.strictEqual(api({ action: 'list', t: TOK_A }).closed, false, 'Zeile gelöscht');
  // Mail-Fehler verhindert das Abschicken nicht
  mailFail = true; const r4 = api({ action: 'submit', t: TOK_A, m: ym }); assert.ok(r4.ok && r4.mail === false); assert.strictEqual(api({ action: 'list', t: TOK_A }).closed, true, 'trotz Mail-Fehler gespeichert'); mailFail = false;
  assert.ok(api({ action: 'reopen', t: TOK_A, m: ym }).ok);
  // Aufräumen für die Seitentests
  assert.ok(api({ action: 'set', t: TOK_A, date: d1, hours: '' }).ok); assert.ok(api({ action: 'set', t: TOK_A, date: pd, hours: '' }).ok);
  assert.strictEqual(sheets.Stunden.rows.length, 1, 'alles aufgeräumt');
  mails.length = 0;
  console.log('ok - Abschluss, Sperre, Wiedereröffnen, Mail');
}

// --- Seite im Browser gegen den Mock ---
(async () => {
  const html = fs.readFileSync(path.join(ROOT, 'erfassen.html'), 'utf8').replace('__API_URL__', 'https://script.example/exec');
  const browser = await chromium.launch(); const page = await (await browser.newContext({ viewport: { width: 390, height: 844 } })).newPage();
  const errs = []; page.on('pageerror', (e) => errs.push(e.message));
  await page.route('https://script.example/**', (route) => { const u = new URL(route.request().url()); const r = api(Object.fromEntries(u.searchParams)); route.fulfill({ status: 200, contentType: 'application/json', headers: { 'access-control-allow-origin': '*' }, body: JSON.stringify(r) }); });
  await page.route('http://page.test/**', (route) => route.fulfill({ status: 200, contentType: 'text/html', body: html }));
  await page.goto('http://page.test/?t=' + TOK_A);
  await page.getByRole('heading', { name: 'Anna Beispiel' }).waitFor();
  const rows = await page.locator('.row').count(); assert.ok(rows >= 28 && rows <= 31, 'Tageszeilen ' + rows);
  const firstDay = page.locator('.row input').first(); await firstDay.fill('4,5'); await firstDay.blur();
  await page.locator('.row.has').first().waitFor(); assert.strictEqual(await firstDay.inputValue(), '4.50');
  assert.ok((await page.locator('.total b').innerText()) === '4.50');
  const second = page.locator('.row input').nth(1); await second.fill('3,5'); await second.blur(); await page.waitForFunction(() => document.querySelector('.total b').textContent === '8.00');
  assert.strictEqual(sheets.Stunden.rows.length, 3, 'zwei Einträge in der Tabelle');
  await page.reload(); await page.locator('.row.has').first().waitFor(); assert.strictEqual(await page.locator('.row.has').count(), 2, 'Einträge nach Neuladen noch sichtbar');
  assert.strictEqual(await page.locator('.total b').innerText(), '8.00');
  for (const bad of ['abc', '4:30', '3.33', '12.25']) { await page.locator('.row input').first().fill(bad); await page.locator('.row input').first().blur(); assert.ok(await page.locator('.row input.bad').count() === 1, 'ungültige Eingabe markiert: ' + bad); assert.ok(await page.getByText('Viertelstunden').count() >= 1, 'Fehlermeldung sichtbar'); assert.strictEqual(sheets.Stunden.rows.length, 3, 'nichts gespeichert: ' + bad); }
  await page.locator('.row input').first().fill(''); await page.locator('.row input').first().blur(); await page.waitForFunction(() => document.querySelector('.total b').textContent === '3.50');
  await page.getByRole('button', { name: 'Vormonat' }).click(); await page.waitForFunction(() => document.querySelector('.total b').textContent === '0.00');
  assert.ok(await page.locator('.row input').first().isEnabled() || true);
  for (let i = 0; i < 2; i++) { const b = page.getByRole('button', { name: 'Vormonat' }); if (await b.isEnabled()) await b.click(); await page.waitForTimeout(150); }
  assert.ok(await page.getByText('abgeschlossen').count() >= 1, 'alter Monat: Hinweis abgeschlossen'); assert.ok(await page.locator('.row input').first().isDisabled(), 'alter Monat gesperrt');
  await page.screenshot({ path: path.join(__dirname, 'ui-out', 'erfassen-alt.png') });
  await page.goto('http://page.test/?t=falsch'); await page.getByText('ungültig').waitFor();
  await page.goto('http://page.test/'); await page.getByText('unvollständig').waitFor();
  await page.goto('http://page.test/?t=' + TOK_A); await page.locator('.row input').first().waitFor(); await page.screenshot({ path: path.join(__dirname, 'ui-out', 'erfassen.png'), fullPage: true });
  // --- Prüfen, Abschicken, Danke, Nochmals bearbeiten ---
  await page.locator('.row input').nth(1).fill('3,5'); await page.locator('.row input').nth(1).blur(); await page.waitForFunction(() => document.querySelector('.total b').textContent === '3.50');
  await page.locator('.row input').first().fill('abc'); await page.getByRole('button', { name: 'Prüfen und abschliessen' }).click();
  assert.ok(await page.getByText('rot markierte').count() >= 1, 'schlechte Eingabe blockiert die Übersicht'); assert.strictEqual(await page.locator('.tbl').count(), 0, 'noch keine Übersicht');
  await page.locator('.row input').first().fill(''); await page.locator('.row input').first().blur();
  await page.getByRole('button', { name: 'Prüfen und abschliessen' }).click(); await page.getByRole('button', { name: 'Stunden abschicken' }).waitFor();
  assert.strictEqual(await page.locator('.tr').count(), 1, 'Übersicht zeigt nur Tage mit Stunden'); assert.strictEqual(await page.locator('.total b').innerText(), '3.50');
  await page.screenshot({ path: path.join(__dirname, 'ui-out', 'erfassen-uebersicht.png'), fullPage: true });
  await page.getByRole('button', { name: 'Zurück zum Bearbeiten' }).click(); await page.locator('.row input').first().waitFor();
  assert.strictEqual(mails.length, 0, 'bisher keine Mail');
  await page.getByRole('button', { name: 'Prüfen und abschliessen' }).click(); await page.getByRole('button', { name: 'Stunden abschicken' }).click();
  await page.getByText('Vielen Dank!').waitFor(); assert.ok(await page.getByText('sind übermittelt und gespeichert (Total 3.50 Stunden)').count() === 1, 'Danke-Meldung mit Total');
  assert.strictEqual(await page.locator('.tr').count(), 1); assert.strictEqual(await page.locator('.row input').count(), 0, 'keine Eingabefelder mehr');
  assert.strictEqual(mails.length, 1, 'genau eine Mail'); assert.ok(mails[0].subject.includes('Anna Beispiel'));
  await page.screenshot({ path: path.join(__dirname, 'ui-out', 'erfassen-danke.png'), fullPage: true });
  await page.reload(); await page.getByText('Vielen Dank!').waitFor();
  await page.getByRole('button', { name: 'Nochmals bearbeiten' }).click(); await page.locator('.row input').first().waitFor();
  assert.strictEqual(await page.locator('.total b').innerText(), '3.50', 'Einträge nach Wiedereröffnen sichtbar');
  await page.locator('.row input').first().fill('1'); await page.locator('.row input').first().blur(); await page.waitForFunction(() => document.querySelector('.total b').textContent === '4.50');
  await page.getByRole('button', { name: 'Prüfen und abschliessen' }).click(); await page.getByRole('button', { name: 'Stunden abschicken' }).click(); await page.getByText('Vielen Dank!').waitFor();
  assert.strictEqual(mails.length, 2); assert.ok(mails[1].subject.includes('(erneut)'));
  await page.getByRole('button', { name: 'Vormonat' }).click(); await page.waitForFunction(() => !document.querySelector('.thanks'));
  assert.ok(await page.getByRole('button', { name: 'Prüfen und abschliessen' }).count() === 1, 'Vormonat noch offen');
  assert.strictEqual(errs.length, 0, 'JS-Fehler: ' + errs.join('|'));
  console.log('ok - Seite: eintragen, Komma, Viertelstunden-Prüfung, Total, Neuladen, Löschen, Monatswechsel, Sperre, falscher Link, Übersicht, Abschicken, Danke, Nochmals bearbeiten');
  await browser.close();
})().catch((e) => { console.error('TESTFEHLER:', e.stack || e.message); process.exit(1); });
