/* PDF-Erzeugung (pdf-lib, Standardschrift Helvetica). Layout nach der Design-Vorlage (A4). */
(function (root) {
  'use strict';
  const C = root.Core;
  const W = 595.28; const H = 841.89;

  async function setup(PDFLib, landscape) {
    const { PDFDocument, StandardFonts, rgb } = PDFLib;
    const doc = await PDFDocument.create();
    const page = doc.addPage(landscape ? [H, W] : [W, H]);
    const f = {
      r: await doc.embedFont(StandardFonts.Helvetica), b: await doc.embedFont(StandardFonts.HelveticaBold),
      i: await doc.embedFont(StandardFonts.HelveticaOblique), bi: await doc.embedFont(StandardFonts.HelveticaBoldOblique),
    };
    const sets = {}; Object.keys(f).forEach((k) => { sets[k] = new Set(f[k].getCharacterSet()); });
    const ph = page.getHeight();
    const hex = (h) => { const n = parseInt(h.slice(1), 16); return rgb(((n >> 16) & 255) / 255, ((n >> 8) & 255) / 255, (n & 255) / 255); };
    const TRANSLIT = { 'Ł': 'L', 'ł': 'l', 'ő': 'o', 'Ő': 'O', 'ű': 'u', 'Ű': 'U', 'đ': 'd', 'Đ': 'D', 'ı': 'i', '’': "'", '‘': "'", '“': '"', '”': '"' };
    const clean = (s, k) => {
      let out = '';
      for (const ch of String(s)) {
        if (sets[k].has(ch.codePointAt(0))) { out += ch; continue; }
        const base = TRANSLIT[ch] || ch.normalize('NFD').replace(/[̀-ͯ]/g, '');
        out += [...base].every((c) => sets[k].has(c.codePointAt(0))) ? base : '?';
      }
      return out;
    };
    const ctx = {
      doc, page, f, rgb, hex, pw: page.getWidth(), ph,
      width: (s, size, k) => f[k || 'r'].widthOfTextAtSize(clean(s, k || 'r'), size),
      // base = Abstand der Grundlinie vom oberen Seitenrand
      text(s, x, base, size, k, color, align) {
        k = k || 'r'; s = clean(s, k); if (s === '') return;
        const w = f[k].widthOfTextAtSize(s, size);
        const xx = align === 'right' ? x - w : (align === 'center' ? x - w / 2 : x);
        page.drawText(s, { x: xx, y: ph - base, size, font: f[k], color: color || rgb(0, 0, 0) });
      },
      line(x1, top, x2, thick, color) {
        page.drawLine({ start: { x: x1, y: ph - top }, end: { x: x2, y: ph - top }, thickness: thick, color: color || rgb(0, 0, 0) });
      },
      rect(x, top, w, h, color) { page.drawRectangle({ x, y: ph - top - h, width: w, height: h, color }); },
    };
    return ctx;
  }

  const addr = (p) => [p.anrede, p.name, p.strasse, p.plzOrt].filter(Boolean);

  /* ---------------- Lohnabrechnung (klassisch, schwarz) ---------------- */
  async function lohnabrechnung(PDFLib, d) {
    const x = await setup(PDFLib, false);
    const { employer: e, person: p, y, m, calc: c } = d;
    x.doc.setTitle(`Lohnabrechnung ${C.monthLabel(y, m)} ${p.kurzname || p.name}`);
    const L = 60; const R = 541.5; const RX = 324; const fs = 10.1; const lh = 14.7;
    const colA = R; const colR = R - 82.5 - 7.5; const colE = colR - 75 - 7.5;

    // Kopf
    [e.name, e.strasse, e.ort].forEach((s, i) => x.text(s, L, 59 + i * lh, fs, 'r'));
    x.text('Lohnabrechnung', RX, 59, fs, 'b'); x.text(C.monthLabel(y, m), RX, 59 + lh, fs, 'b');
    // Empfänger (Fensterposition)
    const rt = 48 + 3 * lh + 42;
    addr(p).forEach((s, i) => x.text(s, RX, rt + 11 + i * lh, fs, 'r'));
    // Datum / AHV-Nr.
    let y0 = rt + 4 * lh + 48;
    x.text('Abrechnungsdatum', L, y0 + 11.5, fs, 'r'); x.text(C.fmtDate(C.nextMonthFirst(y, m)), L + 112.5, y0 + 11.5, fs, 'r');
    x.text('AHV-Nr.', L, y0 + 27.25, fs, 'r'); x.text(p.ahvNr || '', L + 112.5, y0 + 27.25, fs, 'r');
    let t = y0 + 31.5 + 18; const rh = 17.25;

    const money = (v) => C.fmtMoney(v);
    const row = (cells, o) => {
      o = o || {}; if (o.mt) t += o.mt;
      const k = o.bold ? (o.italic ? 'bi' : 'b') : (o.italic ? 'i' : 'r');
      const size = o.size || fs; const h = o.h || rh;
      if (o.topLine) x.line(L, t, R, 0.75);
      const base = t + h / 2 + size * 0.35;
      if (cells[0]) x.text(cells[0], L, base, size, k);
      if (cells[1]) x.text(cells[1], colE, base, size, k, null, 'right');
      if (cells[2]) x.text(cells[2], colR, base, size, k, null, 'right');
      if (cells[3]) x.text(cells[3], colA, base, size, k, null, 'right');
      t += h;
    };

    row(['Text', 'Einheit', 'Ansatz', 'Betrag'], { bold: true });
    x.line(L, t, R, 1.1);
    row(['Monatslohn', '', '', '0.00']);
    row(['Stundenlohn', `${C.fmtHc(c.hc)} x`, money(c.rateC), money(c.lohnC)]);
    row(['Überstunden', '0.00 x', '0.00', '0.00']);
    row(['Nachtpauschale', '0 x', '0.00', '0.00']);
    row(['Ferienentschädigung', `${Number(d.settings.ferien).toFixed(2)}%`, '', money(c.ferienC)]);
    row(['Spesen', '', '', '0.00']);
    row(['Kinder-/Ausbildungszulage', '', '', '0.00']);
    row(['Korrekturen'], { bold: true, italic: true });
    row(['Stundenlohn', '', '', '0.00']);
    row(['Spesen', '', '', '0.00']);
    row(['Kinder-/Ausbildungszulage', '', '', '0.00']);
    row(['Bruttolohn', '', '', money(c.bruttoC)], { bold: true, topLine: true, mt: 1.5 });
    row(['AHV-Lohn', '', '', money(c.ahvLohnC)], { bold: true });
    row(['Abzüge'], { bold: true, mt: 13.5 });
    const base = money(c.ahvLohnC);
    row(['AHV/IV/EO', C.fmtPct(c.ahvRate, 3), money(c.ahvBasisC), money(c.ahvC)]);
    row(['Arbeitslosenversicherung (ALV)', '0.00%', base, '0.00']);
    row(['Berufliche Vorsorge (Pensionskassenbeitrag)', '', '', '0.00']);
    row(['Nichtberufsunfallversicherung (NBU)', '0.0000%', base, '0.00']);
    row(['Krankentaggeldversicherung', '0.0000%', base, '0.00']);
    row(['Quellensteuer', '0.00%', base, '0.00']);
    row(['Total Abzüge', '', '', money(c.abzuegeC)], { bold: true, topLine: true, mt: 1.5 });
    // Nettolohn, doppelt unterstrichen
    t += 16.5; const nh = 21; const nsize = 11.25;
    const nb = t + nh / 2 + nsize * 0.35;
    x.text('Nettolohn', L, nb, nsize, 'b'); x.text('CHF', colR, nb, nsize, 'b', null, 'right'); x.text(money(c.nettoC), colA, nb, nsize, 'b', null, 'right');
    x.line(L, t + nh + 1.5, R, 0.75); x.line(L, t + nh + 3.5, R, 0.75);
    t += nh + 3.5 + 18;
    // Optionale Zahlungsangabe (ohne Überschrift)
    if (p.zahlung) String(p.zahlung).split(/\r?\n/).filter(Boolean).slice(0, 3).forEach((s, i) => x.text(s, L, t + 10 + i * lh, fs, 'r'));
    x.text('Bitte Lohnabrechnung überprüfen und Unstimmigkeiten melden. Danke.', L, H - 42 - 3, fs, 'r');
    return x.doc.save();
  }

  /* ---------------- Stundenübersicht (ruhiges Grün) ---------------- */
  async function stundenuebersicht(PDFLib, d) {
    const x = await setup(PDFLib, false);
    const { employer: e, person: p, y, m } = d; const days = d.days; // [{date, hc}]
    x.doc.setTitle(`Stundenübersicht ${C.monthLabel(y, m)} ${p.kurzname || p.name}`);
    const acc = x.hex('#4E8A5C'); const tint = x.hex('#EAF4EC'); const ink = x.hex('#1B2126'); const mut = x.hex('#5A6570'); const hair = x.hex('#E3E6E8');
    const L = 48; const R = W - 48; const lh = 14.7;
    x.text('ARBEITGEBER', L, 50, 8.25, 'r', mut);
    x.text(e.name, L, 66, 10.5, 'b', ink); x.text(e.strasse, L, 66 + lh, 10.5, 'r', ink); x.text(e.ort, L, 66 + 2 * lh, 10.5, 'r', ink);
    x.text('Stundenübersicht', R, 62, 19.5, 'b', acc, 'right');
    x.text(`Assistenz · ${C.monthLabel(y, m)}`, R, 80, 11.25, 'r', ink, 'right');
    x.line(L, 106, R, 1.5, acc);
    // Person
    x.text('ASSISTENZPERSON', L, 135, 8.25, 'r', mut);
    x.text(p.name, L, 151, 10.5, 'b', ink); x.text(p.strasse, L, 151 + lh, 10.5, 'r', ink); x.text(p.plzOrt, L, 151 + 2 * lh, 10.5, 'r', ink);
    const einsaetze = String(days.length); const ansatz = `CHF ${C.fmtMoney(C.toCents(d.settings.stundenlohn))}`;
    const vw = Math.max(x.width(einsaetze, 10.5, 'b'), x.width(ansatz, 10.5, 'b'));
    x.text('Einsätze', R - vw - 12, 151 + lh, 10.5, 'r', mut, 'right'); x.text(einsaetze, R, 151 + lh, 10.5, 'b', ink, 'right');
    x.text('Stundenansatz', R - vw - 12, 151 + 2 * lh, 10.5, 'r', mut, 'right'); x.text(ansatz, R, 151 + 2 * lh, 10.5, 'b', ink, 'right');
    // Tabelle
    const top = 151 + 2 * lh + 4 + 21;
    const boxH = 40; const footTop = H - 42 - 20;
    const avail = footTop - 14 - boxH - 16.5 - top;
    const rh = Math.min(22.5, avail / (days.length + 1)); const size = Math.min(10.5, rh * 0.5 + 2);
    const col2 = L + 120; const colH = R;
    let t = top;
    const b = (tt) => tt + rh / 2 + size * 0.35;
    x.text('Datum', L, b(t), size, 'b', ink); x.text('Wochentag', col2 + 12, b(t), size, 'b', ink); x.text('Stunden', colH, b(t), size, 'b', ink, 'right');
    t += rh; x.line(L, t, R, 1.1, ink);
    days.forEach((dd) => {
      x.text(C.fmtDate(dd.date), L, b(t), size, 'r', ink); x.text(C.weekdayName(dd.date), col2 + 12, b(t), size, 'r', mut);
      x.text(C.fmtHc(dd.hc), colH, b(t), size, 'r', ink, 'right');
      t += rh; x.line(L, t, R, 0.5, hair);
    });
    const total = days.reduce((a, q) => a + q.hc, 0);
    t += 16.5;
    x.rect(L, t, R - L, boxH, tint); x.line(L, t, R, 1.5, acc);
    x.text('Total Stunden', L + 12, t + 25, 12, 'b', ink); x.text(C.fmtHc(total), R - 12, t + 26, 15, 'b', ink, 'right');
    x.line(L, footTop, R, 0.5, hair);
    x.text(`Grundlage für die Lohnabrechnung ${C.monthLabel(y, m)}.`, L, footTop + 15, 9, 'r', mut);
    return x.doc.save();
  }

  /* ---------------- Jahresübersicht (A4 quer) ---------------- */
  async function jahresuebersicht(PDFLib, d) {
    const x = await setup(PDFLib, true);
    const { employer: e, persons, year, months } = d;
    x.doc.setTitle(`Jahresübersicht Löhne Assistenz ${year}`);
    const acc = x.hex('#4E8A5C'); const tint = x.hex('#EAF4EC'); const ink = x.hex('#1B2126'); const mut = x.hex('#5A6570'); const hair = x.hex('#E3E6E8');
    const PW = H; const PH = W; const L = 36; const R = PW - 36; const lh = 14;
    const yt = C.yearTotals(months, persons, year);
    x.text('ARBEITGEBER', L, 44, 8.25, 'r', mut); x.text(e.name, L, 59, 10.5, 'b', ink);
    x.text('Jahresübersicht', R, 56, 19.5, 'b', acc, 'right'); x.text(`Assistenz · ${year}`, R, 73, 11.25, 'r', ink, 'right');
    x.line(L, 86, R, 1.5, acc);
    // Kennzahlen
    const ahvNames = persons.filter((p) => p.ahvAbzug).map((p) => p.vorname).join(' + ');
    const kpis = [
      ['Ausbezahlt netto', `CHF ${C.fmtMoney(yt.tot.netto)}`],
      [`Bruttolöhne ${ahvNames}`, `CHF ${C.fmtMoney(yt.tot.bruttoAhv)}`],
      ['Total Stunden', C.fmtHc(yt.tot.hc)],
      ['Abgerechnete Monate', `${yt.tot.count} von 12`],
    ];
    const gap = 10; const kw = (R - L - gap * 3) / 4; const kt = 100;
    kpis.forEach((k, i) => {
      const kx = L + i * (kw + gap); x.rect(kx, kt, kw, 46, tint); x.line(kx, kt, kx + kw, 1.5, acc);
      x.text(k[0], kx + 10, kt + 17, 8.5, 'r', mut); x.text(k[1], kx + 10, kt + 36, 14, 'b', ink);
    });
    // Tabelle
    const cols = []; persons.forEach((p) => { if (p.ahvAbzug) { cols.push({ p, k: 'bruttoC', lab: 'Brutto' }); cols.push({ p, k: 'nettoC', lab: 'Netto' }); } else cols.push({ p, k: 'nettoC', lab: 'Netto' }); });
    const monW = 78; const hoursW = 84; const sep = 14;
    const cw = (R - L - monW - hoursW - sep) / cols.length;
    const cx = (i) => L + monW + (i + 1) * cw; // rechte Kante der Spalte i
    const hx = R;
    const ht = 162; const rh = 21;
    // Kopfzeile 1: Personennamen
    persons.forEach((p) => {
      const idx = cols.map((c, i) => (c.p === p ? i : -1)).filter((i) => i >= 0);
      const left = L + monW + idx[0] * cw; const right = L + monW + (idx[idx.length - 1] + 1) * cw;
      x.text(p.vorname || p.name, (left + right) / 2, ht + 11, 10, 'b', ink, 'center');
    });
    x.text('Monat', L, ht + 24, 9, 'b', ink);
    cols.forEach((c, i) => x.text(c.lab, cx(i) - 6, ht + 24, 9, 'r', mut, 'right'));
    // Total-Stunden-Block
    const blockL = R - hoursW;
    x.rect(blockL, ht - 2, hoursW, 2 + 26 + rh * 13 + 2, tint);
    x.text('Total Stunden', R - 6, ht + 24, 9, 'b', ink, 'right');
    x.line(L, ht + 30, R, 1.1, ink);
    let t = ht + 30;
    const base = (tt) => tt + rh / 2 + 3.5;
    yt.rows.forEach((r) => {
      x.text(C.MONATE[r.m - 1], L, base(t), 9.5, 'r', ink);
      if (!r.empty) {
        cols.forEach((c, i) => { const v = r.per[c.p.id]; if (v) x.text(C.fmtMoney(v[c.k]), cx(i) - 6, base(t), 9.5, 'r', ink, 'right'); });
        x.text(C.fmtHc(r.hc), R - 6, base(t), 9.5, 'b', ink, 'right');
      }
      t += rh; x.line(L, t, blockL - 0.01, 0.5, hair); x.line(blockL, t, R, 0.5, hair);
    });
    x.line(L, t, R, 1.1, ink);
    x.text('Total', L, base(t), 9.5, 'b', ink);
    cols.forEach((c, i) => x.text(C.fmtMoney(yt.tot.perPerson[c.p.id][c.k]), cx(i) - 6, base(t), 9.5, 'b', ink, 'right'));
    x.text(C.fmtHc(yt.tot.hc), R - 6, base(t), 9.5, 'b', ink, 'right');
    // Fusszeile
    const noAhv = persons.filter((p) => !p.ahvAbzug).map((p) => p.name);
    const hint = noAhv.length ? `Kein AHV-Abzug bei ${noAhv.join(' und ')} (es sind nur Nettolöhne ausgewiesen). Bei den übrigen Personen: Brutto = AHV-Lohn, Netto nach Abzug AHV/IV/EO.` : 'Brutto = AHV-Lohn, Netto nach Abzug AHV/IV/EO.';
    const last = Object.keys(months).filter((k) => k.startsWith(`${year}-`)).sort().pop();
    const stand = last ? C.monthLabel(year, Number(last.slice(5))) : String(year);
    x.line(L, PH - 36 - 20, R, 0.5, hair);
    x.text(hint, L, PH - 36 - 6, 8, 'r', mut); x.text(`Stand: ${stand}`, R, PH - 36 - 6, 8, 'r', mut, 'right');
    return x.doc.save();
  }

  const api = { lohnabrechnung, stundenuebersicht, jahresuebersicht };
  root.Pdf = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
