/* Oberfläche der App. Alle Daten bleiben im Gerät (verschlüsselt mit der PIN). */
(function () {
  'use strict';
  const C = window.Core; const P = window.Pdf;
  const VAULT_KEY = 'abrechnung_vault_v1';
  const ABRUF_URL = 'https://script.google.com/macros/s/AKfycbzLURthGVd_o-W2aUW4RnsYRjn0UkTwVO19m7v2Hhtq-QFdGDQF5GkG---faGoFl-iuAg/exec';
  const ITER = 250000;
  const enc = new TextEncoder(); const dec = new TextDecoder();

  /* ---------- kleine Helfer ---------- */
  function h(tag, props) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === 'class') el.className = v;
      else if (k === 'value') el.value = v;
      else if (k === 'checked') el.checked = !!v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else if (v !== false && v != null) el.setAttribute(k, v);
    }
    for (const c of [].slice.call(arguments, 2).flat(Infinity)) { if (c == null || c === false) continue; el.append(c.nodeType ? c : document.createTextNode(String(c))); }
    return el;
  }
  const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(s); };
  const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  const uid = () => 'p' + Math.random().toString(36).slice(2, 9);

  /* ---------- Verschlüsselung ---------- */
  async function deriveKey(pin, salt, iter) {
    const km = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function encryptWith(key, obj) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(obj))));
    return { iv: b64(iv), ct: b64(ct) };
  }
  async function decryptWith(key, blob) {
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(blob.iv) }, key, unb64(blob.ct));
    return JSON.parse(dec.decode(pt));
  }

  /* ---------- Zustand ---------- */
  const S = { key: null, salt: null, data: null, tab: 'abr', result: null, editing: null, busy: false, msg: null };
  const root = document.getElementById('app');

  const emptyData = () => ({
    v: 1, settings: { stundenlohn: 35, ferien: 8.33, ahv: 5.3, freibetrag: 1400, abrufKey: '' },
    employer: { name: '', strasse: '', ort: '', email: '' }, persons: [], months: {}, draft: null,
  });
  // vaultGen: wird beim Löschen/Ersetzen aller Daten erhöht, damit ein noch laufender Speichervorgang sie nicht wiederherstellt
  let vaultGen = 0;
  async function save() {
    const gen = vaultGen; const blob = await encryptWith(S.key, S.data);
    if (gen !== vaultGen) return;
    localStorage.setItem(VAULT_KEY, JSON.stringify({ v: 1, salt: b64(S.salt), iter: ITER, iv: blob.iv, ct: blob.ct }));
  }
  let saveTimer = null;
  function saveSoon() { clearTimeout(saveTimer); saveTimer = setTimeout(() => { saveTimer = null; save().catch(() => {}); }, 400); }
  // Sofort speichern (z. B. «gesendet»), ohne die 0.4 s Wartezeit
  function saveNow() { clearTimeout(saveTimer); saveTimer = null; if (S.key && S.data) save().catch(() => {}); }
  // Offenen Speichervorgang sofort erledigen (vor dem Sperren, beim Wechsel in den Hintergrund)
  function flushSave() { if (saveTimer) saveNow(); }
  // Vor dem Löschen/Ersetzen aller Daten: offenes und laufendes Speichern verwerfen
  function dropSaves() { clearTimeout(saveTimer); saveTimer = null; vaultGen++; }

  /* ---------- Sperre / Start ---------- */
  function lock() { flushSave(); S.key = null; S.data = null; S.result = null; S.editing = null; render(); }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { S.hiddenAt = Date.now(); flushSave(); } else if (S.key && S.hiddenAt && Date.now() - S.hiddenAt > 120000) lock();
  });

  function viewOnboarding() {
    const pin1 = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'new-password', maxlength: 8, placeholder: 'PIN (6–8 Ziffern)' });
    const pin2 = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'new-password', maxlength: 8, placeholder: 'PIN wiederholen' });
    const err = h('p', { class: 'err' });
    const fileIn = h('input', { type: 'file', accept: '.json,application/json', class: 'hidden', onchange: async (ev) => {
      const f = ev.target.files[0]; if (!f) return;
      try { S.pendingBackup = JSON.parse(await f.text()); if (!S.pendingBackup.ct) throw new Error('x'); err.textContent = 'Sicherung gewählt. PIN der Sicherung eingeben und „Sicherung laden“ tippen.'; err.className = 'ok'; loadBtn.disabled = false; } catch (e) { err.className = 'err'; err.textContent = 'Das ist keine gültige Sicherungsdatei.'; }
    } });
    const loadBtn = h('button', { class: 'btn sec', disabled: true, onclick: async () => {
      err.className = 'err';
      if (!/^\d{6,8}$/.test(pin1.value)) { err.textContent = 'PIN der Sicherung eingeben (6–8 Ziffern).'; return; }
      try {
        const b = S.pendingBackup; const salt = unb64(b.salt); const key = await deriveKey(pin1.value, salt, b.iter || ITER);
        const data = await decryptWith(key, b);
        S.key = key; S.salt = salt; S.data = data; localStorage.setItem(VAULT_KEY, JSON.stringify(b)); S.tab = 'abr'; render();
      } catch (e) { err.textContent = 'PIN falsch oder Datei beschädigt.'; }
    } }, 'Sicherung laden');
    const start = async (demo) => {
      err.className = 'err';
      if (!/^\d{6,8}$/.test(pin1.value)) { err.textContent = 'Die PIN muss aus 6 bis 8 Ziffern bestehen.'; return; }
      if (pin1.value !== pin2.value) { err.textContent = 'Die beiden PIN stimmen nicht überein.'; return; }
      S.salt = crypto.getRandomValues(new Uint8Array(16)); S.key = await deriveKey(pin1.value, S.salt, ITER);
      S.data = emptyData(); if (demo) loadDemo(S.data); await save(); S.tab = demo ? 'abr' : 'set'; render();
    };
    return h('div', { class: 'center mid' },
      h('h1', {}, 'Abrechnung'),
      h('p', { class: 'muted' }, 'Erster Start. Lege eine PIN fest. Alle Angaben bleiben verschlüsselt in diesem Gerät. Merke dir die PIN gut: Ohne PIN lassen sich die Daten nur mit einer Sicherungsdatei wiederherstellen.'),
      pin1, pin2, err,
      h('button', { class: 'btn', onclick: () => start(false) }, 'Leer starten'),
      h('button', { class: 'btn sec', onclick: () => start(true) }, 'Mit erfundenen Beispieldaten starten'),
      h('hr'), h('p', { class: 'muted' }, 'Oder eine bestehende Sicherung laden (PIN oben eingeben):'),
      h('button', { class: 'btn sec', onclick: () => fileIn.click() }, 'Sicherungsdatei wählen'), loadBtn, fileIn);
  }

  function viewLock() {
    const pin = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'current-password', maxlength: 8, placeholder: 'PIN' });
    const err = h('p', { class: 'err' });
    const go = async () => {
      err.textContent = '';
      try {
        const v = JSON.parse(localStorage.getItem(VAULT_KEY)); const salt = unb64(v.salt);
        const key = await deriveKey(pin.value, salt, v.iter); const data = await decryptWith(key, v);
        S.key = key; S.salt = salt; S.data = data; render();
      } catch (e) { err.textContent = 'PIN falsch.'; pin.value = ''; }
    };
    pin.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    return h('div', { class: 'center mid lock' }, h('h1', {}, 'Abrechnung'), h('p', { class: 'muted' }, 'Gesperrt'), pin, err, h('button', { class: 'btn', onclick: go }, 'Entsperren'),
      h('p', { class: 'muted small' }, 'PIN vergessen? Dann nur mit einer Sicherungsdatei: Daten löschen und beim Start die Sicherung laden. ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); if (confirm('Wirklich ALLE Daten in diesem Gerät löschen? Das geht nur mit einer Sicherungsdatei rückgängig.') && confirm('Letzte Rückfrage: Alles löschen?')) { dropSaves(); localStorage.removeItem(VAULT_KEY); render(); } } }, 'Alle Daten löschen')));
  }

  /* ---------- Beispieldaten (erfunden) ---------- */
  function loadDemo(d) {
    d.employer = { name: 'Max Muster', strasse: 'Musterstrasse 1', ort: '8000 Zürich', email: 'max@example.com' };
    d.persons = [
      { id: 'demo1', anrede: 'Frau', name: 'Anna Beispiel', kurzname: 'Anna Beispiel', vorname: 'Anna', strasse: 'Beispielweg 2', plzOrt: '3000 Bern', email: 'anna@example.com', ahvNr: '756.0000.0000.02', ahvAbzug: true, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo2', anrede: 'Herr', name: 'Hans Probe', kurzname: 'Hans Probe', vorname: 'Hans', strasse: 'Probestrasse 3', plzOrt: '4000 Basel', email: 'hans@example.com', ahvNr: '756.0000.0000.03', ahvAbzug: false, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo3', anrede: 'Herr', name: 'Peter Test', kurzname: 'Peter Test', vorname: 'Peter', strasse: 'Testgasse 4', plzOrt: '5000 Aarau', email: 'peter@example.com', ahvNr: '756.0000.0000.04', ahvAbzug: false, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo4', anrede: 'Frau', name: 'Maria Demo', kurzname: 'Maria Demo', vorname: 'Maria', strasse: 'Demoplatz 5', plzOrt: '6000 Luzern', email: 'maria@example.com', ahvNr: '756.0000.0000.05', ahvAbzug: true, pauschal: true, clockifyKey: '', zahlung: '' },
    ];
  }
  function demoCsv(y, m, persons) {
    const head = 'Project,Client,Description,Task,User,Group,Email,Tags,Billable,Start Date,Start Time,End Date,End Time,Duration (h),Duration (decimal),Billable Rate (CHF),Billable Amount (CHF)';
    const rows = [head]; const dm = (d) => `${C.pad(m)}/${C.pad(d)}/${y}`;
    const add = (p, d, st, en, dur, endDay) => rows.push(`,,,,${p.name},,${p.email},,No,${dm(d)},${st},${dm(endDay || d)},${en},${dur},${(Number(dur.split(':')[0]) + Number(dur.split(':')[1]) / 60).toFixed(2)},0,0`);
    const a = persons.find((p) => p.id === 'demo1'); const b = persons.find((p) => p.id === 'demo2');
    if (a) { [[2, '4:00'], [6, '5:00'], [11, '4:20'], [17, '5:00'], [24, '4:00']].forEach(([d, du]) => add(a, d, '08:00:00', '12:00:00', du)); add(a, 27, '22:00:00', '02:00:00', '4:00', 28); }
    if (b) { for (let d = 3; d <= 28; d += 2) add(b, d, '09:00:00', '13:00:00', d % 4 ? '3:30' : '2:45'); }
    rows.push(`,,,,Gast Beispiel,,gast@example.com,,No,${dm(5)},09:00:00,${dm(5)},10:00:00,1:00,1.00,0,0`);
    return rows.join('\n');
  }

  /* ---------- Entwurf der Monatsabrechnung ---------- */
  function prevMonth() { const t = new Date(); let y = t.getFullYear(); let m = t.getMonth(); if (m === 0) { m = 12; y--; } return { y, m }; }
  function ensureDraft() {
    const d = S.data;
    if (!d.draft) { const { y, m } = prevMonth(); d.draft = { key: C.monthKey(y, m), days: {}, csvHc: {}, skip: {}, excess: {}, pTotal: {}, pending: {}, manual: {}, later: {}, korr: {}, info: null }; }
    // later: «Später nachtragen» (keine Dokumente, keine E-Mail, in der Jahresübersicht leer)
    // korr: Korrektur einer schon gesendeten Abrechnung (mit dem Stand vor der Korrektur zum Abbrechen)
    if (!d.draft.later) d.draft.later = {};
    if (!d.draft.korr) d.draft.korr = {};
    return d.draft;
  }
  const keyYM = (k) => ({ y: Number(k.slice(0, 4)), m: Number(k.slice(5)) });
  const dayHc = (dr, id) => (dr.days[id] || []).reduce((a, q) => a + q.hc, 0);
  function resetDraft(key) { S.data.draft = { key, days: {}, csvHc: {}, skip: {}, excess: {}, pTotal: {}, pending: {}, manual: {}, later: {}, korr: {}, info: null }; S.result = null; S.run = null; S.ablage = null; saveSoon(); }
  // Schon gesendet und nicht in Korrektur: Diese Person ist für den Monat erledigt.
  const sentLocked = (dr, pid) => !!sentOf(dr.key)[pid] && !dr.korr[pid];

  function applyCsv(text, filename) {
    const dr = ensureDraft(); const { y, m } = keyYM(dr.key); const d = S.data;
    const res = C.importClockify(text, y, m, d.persons.filter((p) => !p.pauschal));
    if (res.errors.length) { dr.info = { errors: res.errors, headers: res.headers || null, filename }; saveSoon(); return; }
    const keep = {}; d.persons.filter((p) => p.pauschal).forEach((p) => { keep[p.id] = dr.days[p.id] || []; });
    dr.days = keep; dr.csvHc = {}; dr.skip = {}; dr.excess = {}; dr.pending = {}; dr.manual = {};
    d.persons.filter((p) => !p.pauschal).forEach((p) => {
      const bp = res.byPerson[p.id];
      dr.days[p.id] = bp ? Object.keys(bp.days).sort().map((dt) => ({ date: dt, hc: bp.days[dt] })) : [];
      dr.csvHc[p.id] = bp ? Object.values(bp.days).reduce((a, v) => a + v, 0) : 0;
    });
    dr.info = { errors: [], warnings: res.warnings, unmatched: res.unmatched, outside: res.outside.length, rows: res.rows, filename };
    S.result = null; saveSoon();
  }

  /* ---------- Stunden direkt von der Erfassungsseite holen ---------- */
  async function fetchHours() {
    const dr = ensureDraft(); const d = S.data; const key = (d.settings.abrufKey || '').trim();
    const fail = (msg) => { dr.info = { errors: [msg], headers: null, filename: 'Stundenerfassung' }; S.fetching = false; saveSoon(); render(); };
    if (!key) { S.tab = 'set'; S.msg = 'Bitte zuerst den Abruf-Schlüssel eintragen.'; render(); return; }
    S.fetching = true; render();
    let r;
    try {
      const resp = await fetch(ABRUF_URL + '?action=export&m=' + encodeURIComponent(dr.key) + '&k=' + encodeURIComponent(key), { method: 'GET', redirect: 'follow' });
      r = await resp.json();
    } catch (e) { return fail('Keine Verbindung zur Stundenerfassung. Bitte Internet prüfen und nochmals versuchen.'); }
    if (!r || !r.ok) return fail((r && r.error) || 'Unbekannter Fehler beim Abruf.');
    const ab = r.abschluss || [];
    const old = { days: JSON.parse(JSON.stringify(dr.days)), skip: Object.assign({}, dr.skip), excess: Object.assign({}, dr.excess), manual: Object.assign({}, dr.manual || {}) };
    if (!r.rows) { d.persons.filter((p) => !p.pauschal).forEach((p) => { dr.days[p.id] = []; dr.csvHc[p.id] = 0; }); dr.skip = {}; dr.excess = {}; dr.info = { errors: ['Für diesen Monat sind in der Stundenerfassung noch keine Stunden eingetragen.'], headers: null, filename: 'Stundenerfassung', abschluss: ab }; }
    else {
      applyCsv(r.csv, 'Stundenerfassung ' + dr.key);
      if (dr.info && dr.info.errors && dr.info.errors.length) { S.fetching = false; saveSoon(); render(); return; }
      dr.info.abschluss = ab;
    }
    d.persons.filter((p) => p.pauschal).forEach((p) => { if (old.excess[p.id]) dr.excess[p.id] = old.excess[p.id]; });
    // Nur Stunden von Personen übernehmen, die den Monat abgeschickt haben (Status «abgeschickt» im Blatt «Abschluss»).
    // Bestehende Stunden in der App werden nur nach Rückfrage durch abgeschickte Stunden ersetzt.
    dr.pending = {}; dr.manual = {};
    const sig = (arr) => (arr || []).map((q) => q.date + ':' + q.hc).sort().join('|');
    const keepOld = (p) => { dr.days[p.id] = old.days[p.id] || []; if (old.excess[p.id]) dr.excess[p.id] = old.excess[p.id]; if (old.manual[p.id]) dr.manual[p.id] = true; };
    d.persons.filter((p) => !p.pauschal).forEach((p) => {
      const a = absOf(ab, p); const sub = !!a && a.status === 'abgeschickt';
      const oldDays = old.days[p.id] || []; const oldHc = oldDays.reduce((x, q) => x + q.hc, 0);
      const newHc = dayHc(dr, p.id);
      // Schon gesendet (ohne Korrektur): Stand in der App bleibt, keine Rückfrage.
      if (sentLocked(dr, p.id)) { if (oldDays.length) keepOld(p); if (old.skip[p.id]) dr.skip[p.id] = true; return; }
      // «Später nachtragen»: Sobald die Person abgeschickt hat, kommen die Stunden normal herein.
      if (sub && dr.later[p.id]) delete dr.later[p.id];
      if (!sub) {
        dr.pending[p.id] = newHc;
        if (old.manual[p.id] && oldDays.length) { keepOld(p); delete dr.csvHc[p.id]; }
        else { dr.days[p.id] = []; dr.csvHc[p.id] = 0; if (old.skip[p.id]) dr.skip[p.id] = true; }
        return;
      }
      if (old.skip[p.id]) {
        if (newHc > 0 && confirm(`${p.kurzname}: In der App steht «Hat nicht gearbeitet». Abgeschickt wurden ${C.fmtHc(newHc)} h.\n\nMit den abgeschickten Stunden überschreiben?`)) return;
        dr.skip[p.id] = true; dr.days[p.id] = []; return;
      }
      if (!oldDays.length || sig(oldDays) === sig(dr.days[p.id])) { if (oldDays.length) keepOld(p); return; }
      const was = `${C.fmtHc(oldHc)} h (${oldDays.length} Einsätze${old.manual[p.id] ? ', manuell eingetragen' : ''})`;
      if (confirm(`${p.kurzname}: In der App stehen schon ${was}. Abgeschickt wurden ${C.fmtHc(newHc)} h.\n\nMit den abgeschickten Stunden überschreiben?`)) return;
      keepOld(p);
    });
    S.fetching = false; S.result = null; saveSoon(); render();
  }
  const absOf = (ab, p) => ab.find((x) => C.norm(x.name) === C.norm(p.kurzname) || C.norm(x.name) === C.norm(p.name));
  /* Hinweise zum Abschluss: wer hat den Monat abgeschickt, stimmen die Totale? */
  function abschlussNotes(dr) {
    const ab = dr.info && dr.info.abschluss; if (!ab) return [];
    const out = [];
    S.data.persons.filter((p) => !p.pauschal && !dr.skip[p.id] && !sentLocked(dr, p.id)).forEach((p) => {
      const a = absOf(ab, p);
      const hc = dayHc(dr, p.id); const pend = (dr.pending || {})[p.id];
      if (!a || a.status !== 'abgeschickt') out.push(`${p.kurzname}: hat den Monat noch nicht abgeschickt${a && a.status === 'offen' ? ' (wieder zum Bearbeiten geöffnet)' : ''}${hc > 0 ? ' – in der App stehen deine manuell eingetragenen Stunden' : (pend > 0 ? ` – ${C.fmtHc(pend)} h eingetragen, aber noch nicht übernommen` : '')}.`);
      else if (Math.round(a.total * 100) !== hc) out.push(`${p.kurzname}: Total beim Abschicken ${a.total.toFixed(2)} h, jetzt ${C.fmtHc(hc)} h – nach dem Abschicken geändert?`);
    });
    return out;
  }

  /* ---------- Berechnung für die Kontrolle ---------- */
  function evaluate() {
    const d = S.data; const dr = ensureDraft(); const rows = []; const blockers = [];
    const g = sentOf(dr.key); const kg = korrOf(dr.key); const rec0 = d.months[dr.key];
    d.persons.forEach((p) => {
      const days = dr.days[p.id] || []; const hc = dayHc(dr, p.id); const skip = !!dr.skip[p.id];
      const r = { p, days, hc, skip };
      // Schon gesendet: erledigt, Werte aus der erstellten Abrechnung. Ändern nur über «Korrektur».
      if (g[p.id] && !dr.korr[p.id]) { r.state = 'sent'; r.sentAt = g[p.id]; r.korrAt = kg[p.id] || null; r.rec = (rec0 && rec0.persons && rec0.persons[p.id]) || null; rows.push(r); return; }
      // Nicht gearbeitet: Lohnabrechnung mit 0.00 (ohne Stundenübersicht), Monat in der Jahresübersicht mit 0.00
      if (skip) { r.state = 'skip'; r.calc = C.calcPerson(p, 0, d.settings, {}); rows.push(r); return; }
      // Später nachtragen: keine Dokumente, keine E-Mail, in der Jahresübersicht leer
      if (dr.later[p.id] && !days.length) { r.state = 'later'; rows.push(r); return; }
      if (!p.pauschal && dr.pending && dr.pending[p.id] != null && !days.length) { r.state = 'pending'; blockers.push(`${p.kurzname}: hat den Monat noch nicht abgeschickt – später nochmals «Stunden holen».`); rows.push(r); return; }
      if (hc <= 0) { r.state = 'missing'; blockers.push(`${p.kurzname}: keine Stunden erfasst – bitte entscheiden.`); rows.push(r); return; }
      if (p.pauschal) {
        const t = dr.pTotal[p.id];
        if (t == null || Math.round(t * 100) !== hc) blockers.push(`${p.kurzname}: Summe der Tage (${C.fmtHc(hc)}) entspricht nicht dem Stundentotal${t != null ? ' (' + Number(t).toFixed(2) + ')' : ''}.`);
      }
      r.calc = C.calcPerson(p, hc, d.settings, { excessMode: dr.excess[p.id] });
      if (r.calc.excess && !dr.excess[p.id]) blockers.push(`${p.kurzname}: AHV-Lohn über CHF ${C.fmtMoney(C.toCents(d.settings.freibetrag))} – bitte Vorgehen wählen.`);
      r.state = 'ok'; rows.push(r);
    });
    const targets = rows.filter((r) => r.state === 'ok' || r.state === 'skip');
    return { rows, blockers, targets, totalHc: rows.reduce((a, r) => a + (r.state === 'ok' ? r.hc : (r.state === 'sent' && r.rec ? r.rec.hc || 0 : 0)), 0) };
  }

  /* ---------- Dokumente erstellen ---------- */
  async function createDocs() {
    const d = S.data; const dr = ensureDraft(); const ev = evaluate(); const { y, m } = keyYM(dr.key);
    if (ev.blockers.length || !ev.targets.length) return;
    const old = d.months[dr.key] && !d.months[dr.key].imported ? d.months[dr.key] : null;
    const korrT = ev.targets.filter((r) => dr.korr[r.p.id]);
    const ask = [];
    if (old && ev.targets.some((r) => !dr.korr[r.p.id] && old.persons && old.persons[r.p.id])) ask.push('Für diesen Monat wurden schon Dokumente erstellt. Neu erstellen und den Eintrag in der Jahresübersicht ersetzen?');
    if (korrT.length) ask.push(`Korrektur für ${korrT.map((r) => r.p.kurzname).join(', ')}: Die neuen Dokumente ersetzen beim Ablegen die gesendeten im Drive. Die Person erhält eine E-Mail mit «(korrigiert)» im Betreff.`);
    if (ask.length && !confirm(ask.join('\n\n'))) return;
    S.busy = true; render();
    try {
      // Gesendete Personen behalten ihren Eintrag; «Später nachtragen» bleibt in der Jahresübersicht leer.
      const files = []; const rec = { created: new Date().toISOString(), persons: old ? Object.assign({}, old.persons) : {} };
      ev.rows.filter((r) => r.state === 'later').forEach((r) => { delete rec.persons[r.p.id]; });
      for (const r of ev.targets) {
        if (r.state === 'skip') {
          const lohn0 = await P.lohnabrechnung(window.PDFLib, { employer: d.employer, person: r.p, y, m, calc: r.calc, settings: d.settings });
          files.push({ name: `${dr.key} Lohnabrechnung ${r.p.kurzname}.pdf`, bytes: lohn0, person: r.p.kurzname, pid: r.p.id });
          rec.persons[r.p.id] = { hc: 0, bruttoC: 0, nettoC: 0, nichtGearbeitet: true };
          continue;
        }
        if (r.state !== 'ok') continue;
        const days = r.days.slice().sort((a, b) => a.date.localeCompare(b.date));
        const lohn = await P.lohnabrechnung(window.PDFLib, { employer: d.employer, person: r.p, y, m, calc: r.calc, settings: d.settings });
        const std = await P.stundenuebersicht(window.PDFLib, { employer: d.employer, person: r.p, y, m, days, settings: d.settings });
        files.push({ name: `${dr.key} Lohnabrechnung ${r.p.kurzname}.pdf`, bytes: lohn, person: r.p.kurzname, pid: r.p.id });
        files.push({ name: `${dr.key} Stundenübersicht ${r.p.kurzname}.pdf`, bytes: std, person: r.p.kurzname, pid: r.p.id });
        rec.persons[r.p.id] = { hc: r.hc, bruttoC: r.calc.bruttoC, nettoC: r.calc.nettoC };
      }
      d.months[dr.key] = rec; await save();
      const jb = await P.jahresuebersicht(window.PDFLib, { employer: d.employer, persons: d.persons, year: y, months: d.months });
      files.push({ name: `Jahresübersicht Löhne Assistenz ${y}.pdf`, bytes: jb, person: 'Jahresübersicht', pid: null });
      S.result = { key: dr.key, year: y, files: files.map((f) => ({ name: f.name, person: f.person, pid: f.pid, blob: new Blob([f.bytes], { type: 'application/pdf' }) })) };
      S.ablage = null; S.run = null;
    } catch (e) { alert('Fehler beim Erstellen der Dokumente: ' + e.message); }
    S.busy = false; render();
  }
  const openBlob = (f) => window.open(URL.createObjectURL(f.blob), '_blank');

  /* ---------- Ansicht: Abrechnung ---------- */
  function numInput(value, onset, opts) {
    return h('input', Object.assign({ type: 'text', inputmode: 'decimal', value, onchange: (e) => { const v = Number(String(e.target.value).replace(',', '.')); onset(isFinite(v) ? v : 0); } }, opts || {}));
  }
  function viewAbr() {
    const d = S.data; const dr = ensureDraft(); const { y, m } = keyYM(dr.key); const ev = evaluate();
    const wrap = h('div', {});
    if (!d.persons.length) return h('div', { class: 'card' }, h('p', {}, 'Es sind noch keine Assistenzpersonen erfasst. Bitte zuerst unter „Einstellungen“ Arbeitgeber und Personen eintragen.'), h('button', { class: 'btn', onclick: () => { S.tab = 'set'; render(); } }, 'Zu den Einstellungen'));

    // Monat
    const mSel = h('select', { onchange: (e) => { if (hasDraftData(dr) && !confirm('Der Entwurf des aktuellen Monats geht verloren. Fortfahren?')) { render(); return; } resetDraft(C.monthKey(y, Number(e.target.value))); render(); } },
      C.MONATE.map((n, i) => h('option', { value: i + 1, selected: i + 1 === m }, n)));
    const yNow = new Date().getFullYear();
    const ySel = h('select', { onchange: (e) => { if (hasDraftData(dr) && !confirm('Der Entwurf des aktuellen Monats geht verloren. Fortfahren?')) { render(); return; } resetDraft(C.monthKey(Number(e.target.value), m)); render(); } },
      [yNow - 2, yNow - 1, yNow, yNow + 1].map((yy) => h('option', { value: yy, selected: yy === y }, yy)));
    const fileIn = h('input', { type: 'file', accept: '.csv,text/csv,text/plain', class: 'hidden', onchange: async (e) => { const f = e.target.files[0]; if (!f) return; applyCsv(await f.text(), f.name); render(); } });
    wrap.append(h('div', { class: 'card' }, h('h2', {}, 'Abrechnungsmonat'), h('div', { class: 'row' }, mSel, ySel),
      h('p', { class: 'muted small' }, `Abrechnungsdatum: ${C.fmtDate(C.nextMonthFirst(y, m))}`),
      h('button', { class: 'btn', disabled: S.fetching, onclick: fetchHours }, S.fetching ? 'Hole Stunden …' : 'Stunden holen'),
      h('button', { class: 'linkbtn', onclick: () => fileIn.click() }, 'Reserve: stattdessen CSV-Datei einlesen'), fileIn,
      d.persons.some((p) => p.id.startsWith('demo')) ? h('button', { class: 'btn sec', onclick: () => { applyCsv(demoCsv(y, m, d.persons), 'Beispiel.csv'); render(); } }, 'Beispiel-CSV laden (erfunden)') : null,
      sentNames(dr.key).length ? h('p', { class: 'ok small' }, 'Lohnabrechnungen für diesen Monat bereits gesendet: ' + sentNames(dr.key).join(', ') + '.') : null,
      infoBlock(dr)));

    // Personen
    ev.rows.forEach((r) => wrap.append(personCard(r, dr, y, m)));

    // Kontrolle
    const tbl = h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, ['Person', 'Std.', 'Brutto', 'AHV', 'Netto'].map((t, i) => h('th', { class: i ? 'r' : '' }, t)))),
      h('tbody', {}, ev.rows.map((r) => { const v = rowVals(r); return h('tr', {}, h('td', { class: 'wrap' }, r.p.kurzname, v.note ? h('div', { class: 'muted small' }, v.note) : null), h('td', { class: 'r' }, v.std),
        h('td', { class: 'r' }, v.b != null ? C.fmtMoney(v.b) : ''), h('td', { class: 'r' }, v.a != null ? C.fmtMoney(v.a) : ''), h('td', { class: 'r' }, v.n != null ? C.fmtMoney(v.n) : '')); })),
      h('tfoot', {}, h('tr', {}, h('td', { class: 'wrap' }, 'Total aller Personen'), h('td', { class: 'r' }, C.fmtHc(ev.totalHc)), h('td', {}), h('td', {}), h('td', { class: 'r' }, C.fmtMoney(ev.rows.reduce((a, r) => a + (rowVals(r).n || 0), 0))))));
    const csvDiff = ev.rows.filter((r) => !r.p.pauschal && r.state === 'ok' && dr.csvHc[r.p.id] != null && dr.info && !dr.info.errors.length && dr.csvHc[r.p.id] !== r.hc);
    wrap.append(h('div', { class: 'card' }, h('h2', {}, 'Kontrolle'), h('div', { class: 'scroll' }, tbl),
      csvDiff.map((r) => h('p', { class: 'warn' }, `${r.p.kurzname}: Stunden von Hand geändert (CSV: ${C.fmtHc(dr.csvHc[r.p.id])}, jetzt: ${C.fmtHc(r.hc)}).`)),
      ev.blockers.length ? h('div', { class: 'blockers' }, h('strong', {}, 'Noch offen:'), ev.blockers.map((b) => h('p', {}, b))) : docsHint(ev),
      h('button', { class: 'btn', disabled: !!ev.blockers.length || !ev.targets.length || S.busy, onclick: createDocs }, S.busy ? 'Erstelle …' : 'Dokumente erstellen')));

    if (S.result && S.result.key === dr.key) wrap.append(resultCard());
    return wrap;
  }
  const hasDraftData = (dr) => Object.values(dr.days).some((a) => a.length) || Object.keys(dr.skip).length || Object.keys(dr.later || {}).length || Object.keys(dr.korr || {}).length;
  /* Werte einer Zeile in der Kontrolle (gesendete Personen: aus der erstellten Abrechnung) */
  function rowVals(r) {
    if (r.state === 'sent') { const x = r.rec; if (!x) return { std: '✓', note: 'gesendet' }; return { std: C.fmtHc(x.hc || 0), b: x.bruttoC, n: x.nettoC, a: x.bruttoC - x.nettoC, note: x.nichtGearbeitet ? 'gesendet · nicht gearbeitet' : 'gesendet' }; }
    if (r.state === 'later') return { std: 'später', note: 'später nachtragen' };
    const c = r.calc;
    return { std: r.state === 'ok' ? C.fmtHc(r.hc) : (r.state === 'skip' ? '0.00' : (r.state === 'pending' ? 'offen' : '?')), b: c ? c.bruttoC : null, a: c ? c.ahvC : null, n: c ? c.nettoC : null,
      note: r.state === 'skip' ? 'nicht gearbeitet' : (ensureDraft().korr[r.p.id] ? 'Korrektur' : '') };
  }
  /* Hinweis über dem Button «Dokumente erstellen»: für wen entstehen Dokumente? */
  function docsHint(ev) {
    const later = ev.rows.filter((r) => r.state === 'later').map((r) => r.p.kurzname);
    const sent = ev.rows.filter((r) => r.state === 'sent');
    const out = [];
    if (!ev.targets.length) out.push(h('p', { class: 'ok' }, sent.length ? 'Für diesen Monat ist alles gesendet. Für eine Änderung bei der Person «Korrektur» wählen.' : 'Für diesen Monat gibt es noch nichts zu erstellen.'));
    else out.push(h('p', { class: 'ok' }, 'Alles geprüft. Die Dokumente können erstellt werden' + (sent.length || later.length ? ' für: ' + ev.targets.map((r) => r.p.kurzname + (ensureDraft().korr[r.p.id] ? ' (Korrektur)' : '')).join(', ') : '') + '.'));
    if (later.length) out.push(h('p', { class: 'warn small' }, `Später nachtragen: ${later.join(', ')} – keine Dokumente, keine E-Mail, in der Jahresübersicht leer.`));
    return h('div', {}, out);
  }

  function infoBlock(dr) {
    const i = dr.info; if (!i) return null;
    if (i.errors && i.errors.length) return h('div', { class: 'blockers' }, h('strong', {}, `Datei „${i.filename}“ konnte nicht gelesen werden:`), i.errors.map((e) => h('p', {}, e)), i.headers ? h('p', { class: 'small' }, 'Gefundene Spalten: ' + i.headers.join(' | ')) : null);
    const out = [h('p', { class: 'ok small' }, `„${i.filename}“ eingelesen: ${i.rows} Zeilen.`)];
    if (i.outside) out.push(h('p', { class: 'warn small' }, `${i.outside} Einträge liegen in anderen Monaten und wurden ignoriert.`));
    (i.unmatched || []).forEach((u) => out.push(h('p', { class: 'warn small' }, `Unbekannter Benutzer „${u.user}“ (${u.count} Einträge, ${C.fmtHc(u.hc)} h) – keiner Person zugeordnet. Der Kurzname in den Einstellungen muss genau so geschrieben sein wie der Name im Blatt «Personen».`)));
    abschlussNotes(dr).forEach((w) => out.push(h('p', { class: 'warn small' }, w)));
    (i.warnings || []).forEach((w) => out.push(h('p', { class: 'warn small' }, w)));
    return h('div', {}, out);
  }

  function personCard(r, dr, y, m) {
    const p = r.p; const days = dr.days[p.id] || (dr.days[p.id] = []);
    const used = new Set(days.map((q) => q.date)); const mdays = C.monthDays(y, m);
    if (!S.open) S.open = {};
    // Letzte Zeile gelöscht: wieder die Auswahl zeigen (eintragen, nicht gearbeitet, später nachtragen)
    if (!p.pauschal && !days.length) delete S.open[p.id];
    const isOpen = !!S.open[p.id];
    const touch = () => { if (!p.pauschal) { if (!dr.manual) dr.manual = {}; dr.manual[p.id] = true; } };
    const openEdit = () => { S.open[p.id] = true; };
    const pendR = !!(dr.pending && dr.pending[p.id] != null && !p.pauschal);
    const pOk = !p.pauschal || (dr.pTotal[p.id] != null && Math.round(dr.pTotal[p.id] * 100) === r.hc);
    const ready = r.state === 'ok' && pOk && !(r.calc && r.calc.excess && !dr.excess[p.id]) && !(pendR && !days.length);
    const later = r.state === 'later'; const sent = r.state === 'sent'; const korr = !!dr.korr[p.id];
    const card = h('div', { class: 'card' + (sent ? ' ready' : (ready ? ' ready' : (later ? ' later' : ''))) },
      h('div', { class: 'row between' }, h('h3', {}, p.kurzname),
        h('span', { class: 'row tags' },
          sent ? h('span', { class: 'tag go' }, '✓ gesendet') : (later ? h('span', { class: 'tag later' }, 'später nachtragen') : (ready || r.state === 'skip' ? h('span', { class: 'tag' + (ready ? ' go' : '') }, '✓ bereit') : null)),
          korr ? h('span', { class: 'tag korr' }, 'Korrektur') : null,
          h('span', { class: 'tag' }, p.ahvAbzug ? 'mit AHV-Abzug' : 'ohne AHV-Abzug'))));
    // Schon gesendet: nur Übersicht und «Korrektur»
    if (sent) {
      const x = r.rec;
      card.append(h('p', { class: 'muted small' }, x ? (x.nichtGearbeitet ? 'Nicht gearbeitet · Lohnabrechnung 0.00' : `${C.fmtHc(x.hc || 0)} h · Brutto CHF ${C.fmtMoney(x.bruttoC)} · Netto CHF ${C.fmtMoney(x.nettoC)}`) : 'Für diesen Monat abgerechnet.'),
        h('p', { class: 'ok small' }, `Gesendet am ${r.sentAt}` + (r.korrAt ? ` · Korrektur gesendet am ${r.korrAt}` : '')),
        h('button', { class: 'btn sec', onclick: () => {
          // Stand vor der Korrektur merken, damit «Korrektur abbrechen» ihn wiederherstellt.
          dr.korr[p.id] = { days: JSON.parse(JSON.stringify(dr.days[p.id] || [])), skip: !!dr.skip[p.id], pTotal: dr.pTotal[p.id], excess: dr.excess[p.id] };
          S.result = null; saveSoon(); render();
        } }, 'Korrektur'),
        h('p', { class: 'muted small' }, 'Mit «Korrektur» kannst du die Stunden ändern und die korrigierte Abrechnung senden. Die neuen Dokumente ersetzen die alten im Drive.'));
      return card;
    }
    if (korr) {
      card.append(h('div', { class: 'korrbox' }, h('p', {}, `Korrektur (gesendet am ${sentOf(dr.key)[p.id]}): Stunden ändern, dann «Dokumente erstellen» und «Senden, ablegen und sichern». ${p.vorname || p.kurzname} erhält die korrigierte Abrechnung (Betreff mit «(korrigiert)»).`),
        h('button', { class: 'btn sec small', onclick: () => {
          const k = dr.korr[p.id]; dr.days[p.id] = k.days || [];
          if (k.skip) dr.skip[p.id] = true; else delete dr.skip[p.id];
          if (k.pTotal != null) dr.pTotal[p.id] = k.pTotal; else delete dr.pTotal[p.id];
          if (k.excess) dr.excess[p.id] = k.excess; else delete dr.excess[p.id];
          delete dr.korr[p.id]; delete S.open[p.id]; S.result = null; saveSoon(); render();
        } }, 'Korrektur abbrechen')));
    }
    if (r.state === 'skip') {
      card.append(h('p', { class: 'muted' }, 'Hat in diesem Monat nicht gearbeitet – es wird eine Lohnabrechnung mit 0.00 erstellt (ohne Stundenübersicht).'),
        h('button', { class: 'btn sec', onclick: () => { delete dr.skip[p.id]; saveSoon(); render(); } }, 'Rückgängig'));
      return card;
    }
    const pend = dr.pending && dr.pending[p.id] != null && !p.pauschal;
    const notWorked = (ask) => h('button', { class: 'btn sec', onclick: () => { if (ask && !confirm(ask)) return; dr.skip[p.id] = true; delete dr.later[p.id]; delete S.open[p.id]; saveSoon(); render(); } }, 'Hat nicht gearbeitet');
    const startEntry = () => { if (!p.pauschal) { days.push({ date: mdays.find((x) => !used.has(x)) || mdays[0], hc: 0 }); touch(); } delete dr.later[p.id]; openEdit(); saveSoon(); render(); };
    if (later) {
      card.append(h('p', {}, 'Die Stunden werden später nachgetragen. Für diese Person entstehen jetzt keine Dokumente und keine E-Mail; in der Jahresübersicht bleibt der Monat leer.'),
        h('p', { class: 'small' }, pend ? 'Sobald die Person den Monat abgeschickt hat: «Stunden holen», dann «Dokumente erstellen» und «Senden, ablegen und sichern» – nur für sie.' : 'Später die Stunden eintragen, dann «Dokumente erstellen» und «Senden, ablegen und sichern» – nur für sie.'),
        h('div', { class: 'row' }, h('button', { class: 'btn', onclick: startEntry }, pend ? 'Manuell eintragen' : 'Stunden eintragen'),
          h('button', { class: 'btn sec', onclick: () => { delete dr.later[p.id]; saveSoon(); render(); } }, 'Rückgängig')));
      return card;
    }
    if (pend) {
      const ph = dr.pending[p.id];
      card.append(h('p', { class: 'warn' }, days.length
        ? 'Noch nicht abgeschickt. Die Stunden unten hast du manuell eingetragen.'
        : `Noch nicht abgeschickt${ph > 0 ? ` (${C.fmtHc(ph)} h eingetragen)` : ''}. Die Stunden werden übernommen, sobald die Person den Monat abgeschickt hat. Dann nochmals «Stunden holen».`));
    }
    if (!days.length && !isOpen) {
      if (!pend) card.append(h('p', { class: 'muted' }, p.pauschal ? 'Noch keine Stunden für diesen Monat.' : 'Keine Stunden in diesem Monat.'));
      card.append(h('div', { class: 'row' }, h('button', { class: 'btn', onclick: startEntry }, pend ? 'Manuell eintragen' : 'Stunden eintragen'),
        notWorked(pend ? `${p.kurzname} hat den Monat nicht abgeschickt. Wirklich «nicht gearbeitet» (Lohnabrechnung mit 0.00)?` : '')));
      // Bei einer Korrektur gibt es kein «Später nachtragen» (die Person hat schon eine Abrechnung erhalten).
      if (!korr) card.append(h('button', { class: 'btn sec', onclick: () => { dr.later[p.id] = true; delete dr.skip[p.id]; delete S.open[p.id]; saveSoon(); render(); } }, 'Später nachtragen'));
      return card;
    }
    if (days.length) {
      card.append(h('div', { class: 'row between' }, h('strong', {}, `${days.length} Einsätze · ${C.fmtHc(r.hc)} h`),
        h('button', { class: 'btn sec small', onclick: () => { if (isOpen) delete S.open[p.id]; else openEdit(); render(); } }, isOpen ? 'Schliessen' : 'Bearbeiten')));
    }
    if (isOpen && p.pauschal) {
      const sat = C.sundaysThursdays(y, m);
      const msg = h('p', { class: 'err small' });
      card.append(h('p', { class: 'muted small' }, 'Stundentotal eingeben, dann wird auf Sonntage und Donnerstage verteilt (je 4 oder 5 Stunden, wenn nötig auch 3).'),
        h('label', {}, 'Stundentotal im Monat'), numInput(dr.pTotal[p.id] != null ? dr.pTotal[p.id] : '', (v) => { dr.pTotal[p.id] = v; saveSoon(); }, { placeholder: 'z. B. 36' }),
        h('button', { class: 'btn', onclick: () => {
          const t = dr.pTotal[p.id]; const res = C.distribute(t, sat);
          if (res.error) { msg.textContent = res.error; return; } days.splice(0, days.length, ...res.days); saveSoon(); render();
        } }, 'Verteilung vorschlagen'), msg);
      if (!days.length) card.append(h('div', { class: 'row' }, h('button', { class: 'btn sec', onclick: () => { delete S.open[p.id]; render(); } }, 'Abbrechen'), notWorked('')));
    }
    if (isOpen && days.length) {
      const first = mdays.find((x) => !used.has(x)) || mdays[0];
      const list = h('div', { class: 'days' });
      days.forEach((q, idx) => list.append(h('div', { class: 'dayrow' },
        h('input', { type: 'date', value: q.date, min: mdays[0], max: mdays[mdays.length - 1], onchange: (e) => { if (e.target.value) { q.date = e.target.value; days.sort((a, b) => a.date.localeCompare(b.date)); touch(); saveSoon(); render(); } } }),
        h('span', { class: 'wd' }, C.weekdayName(q.date).slice(0, 2)),
        numInput(q.hc ? (q.hc / 100).toFixed(2) : '', (v) => { q.hc = Math.round(v * 100); touch(); saveSoon(); render(); }, { class: 'hrs' }),
        h('button', { class: 'x', title: 'Zeile löschen', onclick: () => { days.splice(idx, 1); touch(); saveSoon(); render(); } }, '×'))));
      card.append(list, h('div', { class: 'row between' }, h('button', { class: 'btn sec small', onclick: () => { days.push({ date: first, hc: 0 }); days.sort((a, b) => a.date.localeCompare(b.date)); touch(); saveSoon(); render(); } }, '+ Tag')));
    }
    if (p.pauschal && days.length && dr.pTotal[p.id] != null) {
      const ok = Math.round(dr.pTotal[p.id] * 100) === r.hc;
      card.append(h('p', { class: ok ? 'ok small' : 'err small' }, ok ? `Summe stimmt mit dem Total (${Number(dr.pTotal[p.id]).toFixed(2)} h) überein.` : `Summe ${C.fmtHc(r.hc)} h ≠ Total ${Number(dr.pTotal[p.id]).toFixed(2)} h.`));
    }
    if (r.calc && r.calc.excess) {
      const sel = h('select', { onchange: (e) => { if (e.target.value) dr.excess[p.id] = e.target.value; else delete dr.excess[p.id]; saveSoon(); render(); } },
        h('option', { value: '' }, 'Bitte wählen …'),
        h('option', { value: 'ohne', selected: dr.excess[p.id] === 'ohne' }, 'Ohne AHV-Abzug abrechnen'),
        h('option', { value: 'abziehen', selected: dr.excess[p.id] === 'abziehen' }, `AHV nur auf Teil über ${C.fmtMoney(C.toCents(S.data.settings.freibetrag))}`));
      card.append(h('div', { class: 'blockers' }, h('strong', {}, 'Achtung: AHV-Lohn über CHF ' + C.fmtMoney(C.toCents(S.data.settings.freibetrag))),
        h('p', {}, `Der AHV-Lohn beträgt CHF ${C.fmtMoney(r.calc.bruttoC)}. Möglicherweise muss auf den übersteigenden Teil AHV abgezogen werden (Freibetrag für Personen im Rentenalter). Bitte entscheiden:`), sel));
    }
    if (r.calc) card.append(h('p', { class: 'muted small' }, `Brutto CHF ${C.fmtMoney(r.calc.bruttoC)} · AHV ${C.fmtMoney(r.calc.ahvC)} · Netto CHF ${C.fmtMoney(r.calc.nettoC)}`));
    return card;
  }

  function resultCard() {
    const r = S.result; const files = r.files; const mails = mailsFor(r);
    const out = h('div', { class: 'card done' }, h('h2', {}, 'Dokumente erstellt'),
      h('p', { class: 'muted small' }, 'Bitte prüfen: «Ansehen» öffnet das PDF, «E-Mail-Vorschau» zeigt die E-Mail. Die Dateien liegen erst in diesem Gerät.'));
    const fileRow = (f) => h('div', { class: 'file' }, h('span', {}, f.name),
      h('div', { class: 'row' }, h('button', { class: 'btn sec small', onclick: () => openBlob(f) }, 'Ansehen')));
    mails.forEach((e) => {
      const p = S.data.persons.find((x) => x.id === e.pid);
      out.append(h('div', { class: 'pblock' }, h('div', { class: 'row between' }, h('h3', {}, p.kurzname), e.korr ? h('span', { class: 'tag korr' }, 'Korrektur') : null),
        files.filter((f) => f.pid === e.pid).map(fileRow),
        h('details', { class: 'mailprev' }, h('summary', {}, e.done ? `E-Mail-Vorschau · gesendet` : 'E-Mail-Vorschau'),
          h('div', { class: 'small' }, h('b', {}, 'An: '), e.to || '–'), h('div', { class: 'small' }, h('b', {}, 'CC: '), e.cc || '–'),
          h('div', { class: 'small' }, h('b', {}, 'Betreff: '), (isTest() ? '[TEST] ' : '') + e.subject),
          h('pre', {}, e.body),
          h('div', { class: 'small muted' }, 'Anhänge: ' + files.filter((f) => f.pid === e.pid).map((f) => f.name).join(', ')))));
    });
    files.filter((f) => f.pid === null).forEach((f) => out.append(h('div', { class: 'pblock' }, h('h3', {}, 'Jahresübersicht'), fileRow(f))));
    out.append(googleBlock(r, mails));
    return out;
  }

  /* ---------- Google: Ablage im Drive, Gmail-Entwürfe und Senden (über das eigene Google-Script) ---------- */
  const isTest = () => S.data.persons.length > 0 && S.data.persons.every((p) => p.id.startsWith('demo'));
  async function scriptPost(body) {
    const key = (S.data.settings.abrufKey || '').trim();
    if (!key) throw new Error('Bitte zuerst unter „Einstellungen“ den Abruf-Schlüssel eintragen.');
    let resp;
    try {
      // Ohne eigenen Content-Type (text/plain), damit der Browser keine Vorabfrage schickt.
      resp = await fetch(ABRUF_URL, { method: 'POST', redirect: 'follow', body: JSON.stringify(Object.assign({ k: key, test: isTest() }, body)) });
    } catch (e) { throw new Error('Keine Verbindung zu Google. Bitte Internet prüfen und nochmals versuchen.'); }
    let r; try { r = await resp.json(); } catch (e) { throw new Error('Unerwartete Antwort von Google (ist das Script neu bereitgestellt?).'); }
    if (!r || !r.ok) throw new Error((r && r.error) || 'Unbekannter Fehler.');
    return r;
  }
  const blobB64 = async (blob) => b64(new Uint8Array(await blob.arrayBuffer()));

  async function driveAblegen() {
    const r = S.result; const d = S.data;
    const persons = d.persons.filter((p) => r.files.some((f) => f.pid === p.id));
    const steps = [{ label: `Google Tabelle „Jahresübersicht Löhne Assistenz ${r.year}“` }, { label: 'Jahresübersicht (PDF)' }].concat(persons.map((p) => ({ label: r.files.some((f) => f.pid === p.id && /Stundenübersicht/.test(f.name)) ? `${p.kurzname}: Lohnabrechnung und Stundenübersicht` : `${p.kurzname}: Lohnabrechnung (nicht gearbeitet)`, pid: p.id })));
    S.ablage = { running: true, steps, done: false }; render();
    const run = async (st, fn) => { st.state = 'run'; render(); try { const res = await fn(); st.state = 'ok'; st.msg = res || ''; } catch (e) { st.state = 'err'; st.msg = e.message; } render(); return st.state === 'ok'; };
    // 1) Tabelle zuerst: Die Sicherung im Script verhindert, dass ältere Monate verloren gehen.
    const ys = C.yearSheet(d.months, d.persons, r.year);
    const okSheet = await run(steps[0], async () => { const x = await scriptPost({ action: 'jahr_schreiben', year: r.year, header: ys.header, rows: ys.rows }); return x.neu ? 'neu angelegt' : 'aktualisiert'; });
    if (!okSheet) { steps.slice(1).forEach((s) => { s.state = 'skip'; s.msg = 'nicht ausgeführt'; }); S.ablage.running = false; render(); return; }
    const jf = r.files.find((f) => f.pid === null);
    await run(steps[1], async () => {
      // Jahres-PDF jetzt neu erstellen: Seit «Dokumente erstellen» können Monate übernommen worden sein.
      jf.blob = new Blob([await P.jahresuebersicht(window.PDFLib, { employer: d.employer, persons: d.persons, year: r.year, months: d.months })], { type: 'application/pdf' }); const x = await scriptPost({ action: 'ablegen', ordner: '', files: [{ name: jf.name, b64: await blobB64(jf.blob) }] }); return x.files[0].ersetzt ? 'alte Version im Papierkorb' : 'neu'; });
    for (const st of steps.slice(2)) {
      const p = d.persons.find((x) => x.id === st.pid);
      await run(st, async () => {
        const fl = []; for (const f of r.files.filter((x) => x.pid === p.id)) fl.push({ name: f.name, b64: await blobB64(f.blob) });
        const x = await scriptPost({ action: 'ablegen', ordner: p.kurzname, files: fl });
        const rep = x.files.reduce((a, f) => a + f.ersetzt, 0); return `Ordner „${x.ordner}“` + (rep ? `, ${rep} alte Version(en) im Papierkorb` : '');
      });
    }
    S.ablage.running = false; S.ablage.done = steps.every((s) => s.state === 'ok'); render();
  }

  /* Gesendete Lohnabrechnungen dauerhaft merken (verschlüsselt im Gerät und in der Sicherung), damit nach einem Neustart nicht nochmals gesendet wird. */
  const sentOf = (key) => ((S.data.gesendet || {})[key] || {});
  const korrOf = (key) => ((S.data.korrigiert || {})[key] || {});
  const nowTxt = () => { const t = new Date(); const z = (n) => String(n).padStart(2, '0'); return `${z(t.getDate())}.${z(t.getMonth() + 1)}.${t.getFullYear()} ${z(t.getHours())}:${z(t.getMinutes())}`; };
  function markSent(key, pid, test) { const d = S.data; if (!d.gesendet) d.gesendet = {}; if (!d.gesendet[key]) d.gesendet[key] = {}; d.gesendet[key][pid] = nowTxt() + (test ? ' (Test)' : ''); saveNow(); }
  // Korrektur gesendet: «gesendet am» bleibt, dazu «Korrektur gesendet am»; die Person ist danach wieder gesperrt.
  function markKorr(key, pid, test) { const d = S.data; if (!d.korrigiert) d.korrigiert = {}; if (!d.korrigiert[key]) d.korrigiert[key] = {}; d.korrigiert[key][pid] = nowTxt() + (test ? ' (Test)' : ''); const dr = ensureDraft(); if (dr.key === key) delete dr.korr[pid]; saveNow(); }
  function sentNames(key) { const g = sentOf(key); const k = korrOf(key); return S.data.persons.filter((p) => g[p.id]).map((p) => `${p.kurzname} (${g[p.id]}${k[p.id] ? ', Korrektur ' + k[p.id] : ''})`); }

  function mailDraft(p, key, ohneStunden, korr) {
    const { y, m } = keyYM(key); const d = S.data; const mon = C.MONATE[m - 1];
    const lohn = korr ? 'korrigierte Lohnabrechnung' : 'Lohnabrechnung';
    const satz = ohneStunden ? `Hier ist deine ${lohn} vom ${mon}.` : `Hier ist deine ${lohn} vom ${mon} mit der Stundenübersicht.`;
    return {
      pid: p.id, to: p.email || '', cc: d.employer.email || '', korr: !!korr,
      subject: `Lohnabrechnung ${C.monthLabel(y, m)} / ${p.kurzname}` + (korr ? ' (korrigiert)' : ''),
      body: `${p.anrede === 'Herr' ? 'Lieber' : 'Liebe'} ${p.vorname}\n\n${satz}\n\nVielen Dank für deine Unterstützung! ❤️\n\nLiebe Grüsse\nRoger`,
    };
  }
  /* E-Mails zu den erstellten Dokumenten. done = schon gesendet (wird nicht nochmals gesendet). */
  function mailsFor(r) {
    const d = S.data; const dr = ensureDraft(); const g = sentOf(r.key);
    return d.persons.filter((p) => r.files.some((f) => f.pid === p.id)).map((p) => {
      const korr = !!(g[p.id] && dr.key === r.key && dr.korr[p.id]);
      const e = mailDraft(p, r.key, !r.files.some((f) => f.pid === p.id && /Stundenübersicht/.test(f.name)), korr || !!(S.run && S.run.korr && S.run.korr[p.id]));
      e.done = !!(g[p.id] && !korr);
      return e;
    });
  }
  function entwProbs(list) {
    const d = S.data; const probs = [];
    list.forEach((e) => { const p = d.persons.find((x) => x.id === e.pid); if (!e.to) probs.push(`${p.kurzname}: keine E-Mail-Adresse in den Einstellungen.`); });
    if (!d.employer.email) probs.push('Arbeitgeber: keine E-Mail-Adresse für CC in den Einstellungen.');
    return probs;
  }

  /* Ein Schritt: im Drive ablegen → Gmail-Entwürfe → senden → Sicherung.
     Gesendet wird nur, wenn Ablage und alle Entwürfe geklappt haben. Wiederholbar: schon Gesendetes wird nie nochmals gesendet. */
  async function ablegenSendenSichern() {
    const r = S.result; const mails = mailsFor(r).filter((e) => !e.done);
    if (!mails.length || entwProbs(mails).length) return;
    const zeilen = mails.map((e) => `• ${e.to}${e.cc ? ' (CC ' + e.cc + ')' : ''}${e.korr ? ' – Korrektur' : ''}`).join('\n');
    if (!confirm(`Im Drive ablegen und ${mails.length} E-Mail${mails.length === 1 ? '' : 's'} jetzt wirklich senden?\n\n${zeilen}\n\nDas Senden kann nicht rückgängig gemacht werden. Danach wird die Sicherung im Drive abgelegt.`)) return;
    S.run = { running: true, mails, korr: Object.fromEntries(mails.filter((e) => e.korr).map((e) => [e.pid, true])) }; render();
    const stop = (msg) => { S.run.running = false; S.run.err = msg; render(); };
    // 1) Drive
    await driveAblegen();
    if (!S.ablage.done) return stop('Die Ablage im Drive ist nicht vollständig. Es wurde nichts gesendet. Details unten.');
    // 2) Entwürfe (ersetzen gleichnamige; das Script prüft die erlaubten Empfänger)
    for (const e of mails) {
      e.state = 'run'; e.msg = ''; render();
      try {
        const fl = []; for (const f of r.files.filter((x) => x.pid === e.pid)) fl.push({ name: f.name, b64: await blobB64(f.blob) });
        const x = await scriptPost({ action: 'entwurf', to: e.to, cc: e.cc, subject: e.subject, body: e.body, files: fl });
        e.state = 'ok'; e.msg = x.ersetzt ? 'Entwurf ersetzt' : 'Entwurf erstellt'; e.draftId = x.id;
      } catch (err) { e.state = 'err'; e.msg = err.message; }
      render();
    }
    if (mails.some((e) => e.state !== 'ok')) return stop('Nicht alle Gmail-Entwürfe konnten erstellt werden. Es wurde nichts gesendet. Details unten.');
    // 3) Senden
    for (const e of mails) {
      e.sendState = 'run'; render();
      try {
        const x = await scriptPost({ action: 'senden', draftId: e.draftId });
        e.sendState = 'ok'; e.sendMsg = x.simuliert ? 'Test: Senden geprüft, nicht wirklich gesendet (@example.com)' : (e.korr ? 'Korrektur gesendet' : 'gesendet');
        if (e.korr) markKorr(r.key, e.pid, !!x.simuliert); else markSent(r.key, e.pid, !!x.simuliert);
      } catch (err) { e.sendState = 'err'; e.sendMsg = err.message; }
      render();
    }
    // 4) Sicherung
    if (mails.some((e) => e.sendState === 'ok')) await sicherungAblegen();
    S.run.running = false;
    if (mails.some((e) => e.sendState !== 'ok')) S.run.err = 'Nicht alle E-Mails wurden gesendet. Nochmals versuchen: Schon Gesendetes wird nicht nochmals gesendet.';
    else S.run.ok = true;
    render();
  }

  // Nach dem Senden: verschlüsselte Sicherung (mit «gesendet am …») im Drive-Hauptordner ablegen; ältere kommen in den Papierkorb.
  async function sicherungAblegen() {
    S.run.sich = { state: 'run', msg: '' }; render();
    try {
      await save();
      const t = new Date(); const tag = `${t.getFullYear()}-${String(t.getMonth() + 1).padStart(2, '0')}-${String(t.getDate()).padStart(2, '0')}`;
      const x = await scriptPost({ action: 'sicherung', name: `Sicherung Abrechnung ${tag}.json`, inhalt: localStorage.getItem(VAULT_KEY) });
      S.run.sich = { state: 'ok', msg: `${x.name} im Ordner «${x.ordner}»` + (x.ersetzt ? ` · ältere Sicherung${x.ersetzt === 1 ? '' : 'en'} im Papierkorb` : '') };
    } catch (err) { S.run.sich = { state: 'err', msg: err.message }; }
    render();
  }

  const MARK = { ok: '✓', err: '✗', run: '…', skip: '–' };
  const stepLine = (label, st) => h('div', { class: 'step ' + (st.state || '') }, h('span', { class: 'mk' }, MARK[st.state] || '○'), h('span', {}, label, st.msg ? h('div', { class: 'small ' + (st.state === 'err' ? 'err' : 'muted') }, st.msg) : null));

  function googleBlock(r, mails) {
    const out = h('div', { class: 'gblock' }, h('h2', {}, 'Senden, ablegen und sichern'));
    if (isTest()) out.append(h('p', { class: 'tag' }, 'Testmodus (erfundene Daten): nur Ordner „_TEST Beispieldaten“, nur Adressen @example.com'));
    const offen = mails.filter((e) => !e.done); const run = S.run;
    const busy = !!(run && (run.running || (run.sich && run.sich.state === 'run')));
    const probs = entwProbs(offen);
    if (run && run.ok) out.append(h('p', { class: 'ok' }, isTest() ? 'Test abgeschlossen: abgelegt, Senden geprüft, gesichert.' : 'Erledigt: im Drive abgelegt, gesendet und gesichert.'));
    if (run && run.err) out.append(h('div', { class: 'blockers' }, h('p', {}, run.err)));
    if (S.ablage && !S.ablage.running && S.ablage.steps[0].state === 'err' && /Jahresdaten übernehmen/.test(S.ablage.steps[0].msg || '')) {
      out.append(h('button', { class: 'btn sec', onclick: () => { S.tab = 'year'; render(); window.scrollTo(0, 0); } }, 'Zu „Jahr“: Jahresdaten übernehmen'));
    }
    if (offen.length) {
      if (!run) out.append(h('p', { class: 'muted small' }, 'Legt alles im Drive ab (PDFs, Google Tabelle und PDF der Jahresübersicht; alte Versionen in den Papierkorb), sendet die E-Mails (CC an den Arbeitgeber) und legt danach die Sicherung im Drive ab. Vorher kommt eine Rückfrage mit allen Empfängern. Klappt ein Schritt nicht, wird nichts gesendet.'));
      if (probs.length) out.append(h('div', { class: 'blockers' }, probs.map((x) => h('p', {}, x))));
      out.append(h('button', { class: 'btn', disabled: !!(busy || probs.length), onclick: ablegenSendenSichern },
        run && run.running ? 'Läuft …' : `${run && run.err ? 'Nochmals versuchen' : 'Senden, ablegen und sichern'} (${offen.length})`));
    } else if (!run) out.append(h('p', { class: 'ok' }, 'Diese Abrechnungen sind schon gesendet.'));
    // Fortschritt
    if (run) {
      if (S.ablage) { out.append(h('h3', { class: 'mt' }, 'Drive')); S.ablage.steps.forEach((s) => out.append(stepLine(s.label, s))); }
      if (run.mails.some((e) => e.state)) {
        out.append(h('h3', { class: 'mt' }, 'E-Mails'));
        run.mails.forEach((e) => { const p = S.data.persons.find((x) => x.id === e.pid); out.append(stepLine(`${p.kurzname}${e.korr ? ' (Korrektur)' : ''}: Entwurf`, e)); if (e.sendState) out.append(stepLine(`${p.kurzname}: Senden an ${e.to}`, { state: e.sendState, msg: e.sendMsg })); });
      }
      if (run.sich) {
        out.append(stepLine('Sicherung im Drive', run.sich));
        if (run.sich.state === 'err') out.append(h('button', { class: 'btn sec', onclick: sicherungAblegen }, 'Sicherung nochmals ablegen'));
      }
    }
    return out;
  }

  /* ---------- Jahresdaten einmalig aus der bestehenden Google Tabelle übernehmen ---------- */
  async function jahrLesen(year) {
    S.imp = { year, loading: true }; render();
    try {
      const x = await scriptPost({ action: 'jahr_lesen', year });
      if (!x.found) { S.imp = { year, errors: [`Im Drive gibt es keine Tabelle „${x.name}“. Es gibt nichts zu übernehmen.`] }; render(); return; }
      const res = C.parseYearSheet(x.values, S.data.persons);
      const add = []; const same = []; const diff = [];
      Object.keys(res.months).map(Number).sort((a, b) => a - b).forEach((m) => {
        const k = C.monthKey(year, m); const have = S.data.months[k]; const rec = res.months[m];
        if (!have) { add.push(m); return; }
        const dif = S.data.persons.filter((p) => { const a = have.persons && have.persons[p.id]; const b = rec.persons[p.id]; return (a ? a.nettoC : 0) !== (b ? b.nettoC : 0); });
        (dif.length ? diff : same).push(m);
      });
      S.imp = Object.assign({ year, name: x.name, add, same, diff }, res);
    } catch (e) { S.imp = { year, errors: [e.message] }; }
    render();
  }
  function jahrUebernehmen() {
    const imp = S.imp; const now = new Date().toISOString();
    imp.add.forEach((m) => { const rec = imp.months[m]; S.data.months[C.monthKey(imp.year, m)] = { created: now, imported: true, hcTotal: rec.hcTotal, persons: rec.persons }; });
    const n = imp.add.length; S.imp = { year: imp.year, doneMsg: `${n} Monat${n === 1 ? '' : 'e'} übernommen. Bitte unter „Einstellungen“ eine neue Sicherung speichern.` };
    save().catch(() => {}); render();
  }
  function importBlock(year) {
    const imp = S.imp && S.imp.year === year ? S.imp : null; const out = h('div', { class: 'card' }, h('h2', {}, 'Jahresdaten aus Google übernehmen'));
    if (!imp) {
      out.append(h('p', { class: 'muted small' }, `Übernimmt einmalig die Monate aus der bestehenden Google Tabelle „Jahresübersicht Löhne Assistenz ${year}“ (z. B. Monate, die noch im Chat abgerechnet wurden). Monate, die schon in der App sind, bleiben unverändert.`),
        h('button', { class: 'btn sec', onclick: () => jahrLesen(year) }, 'Tabelle lesen und prüfen'));
      return out;
    }
    if (imp.loading) { out.append(h('p', { class: 'muted' }, 'Lese Tabelle …')); return out; }
    if (imp.doneMsg) { out.append(h('p', { class: 'ok' }, imp.doneMsg)); return out; }
    if (imp.errors && imp.errors.length) {
      out.append(h('div', { class: 'blockers' }, h('strong', {}, 'Nicht übernommen:'), imp.errors.map((e) => h('p', {}, e))), (imp.warnings || []).map((w) => h('p', { class: 'warn small' }, w)),
        h('button', { class: 'btn sec', onclick: () => jahrLesen(year) }, 'Nochmals lesen'));
      return out;
    }
    out.append(h('p', { class: 'small muted' }, 'Zuordnung der Spalten: ' + imp.cols.map((c) => `«${c.header}» → ${c.p.kurzname} ${c.k === 'bruttoC' ? 'Brutto' : 'Netto'}`).join(' · ')));
    imp.warnings.forEach((w) => out.append(h('p', { class: 'warn small' }, w)));
    const cols = C.yearColumns(S.data.persons);
    if (imp.add.length) {
      out.append(h('p', {}, h('strong', {}, 'Neu in die App: '), imp.add.map((m) => C.MONATE[m - 1]).join(', ')));
      out.append(h('div', { class: 'scroll' }, h('table', { class: 'tbl' },
        h('thead', {}, h('tr', {}, h('th', {}, 'Monat'), cols.map((c) => h('th', { class: 'r' }, c.label)), h('th', { class: 'r' }, 'Stunden'))),
        h('tbody', {}, imp.add.map((m) => { const rec = imp.months[m]; return h('tr', {}, h('td', {}, C.MONATE[m - 1]), cols.map((c) => h('td', { class: 'r' }, rec.persons[c.p.id] ? C.fmtMoney(rec.persons[c.p.id][c.k]) : '')), h('td', { class: 'r' }, rec.hcTotal != null ? C.fmtHc(rec.hcTotal) : '?')); })))));
    } else out.append(h('p', { class: 'ok' }, 'Alle Monate der Tabelle sind schon in der App.'));
    if (imp.same.length) out.append(h('p', { class: 'muted small' }, 'Schon in der App (gleich): ' + imp.same.map((m) => C.MONATE[m - 1]).join(', ')));
    if (imp.diff.length) out.append(h('p', { class: 'warn small' }, 'Schon in der App, aber andere Beträge als in der Tabelle (App-Werte bleiben): ' + imp.diff.map((m) => C.MONATE[m - 1]).join(', ')));
    out.append(h('div', { class: 'row' },
      h('button', { class: 'btn', disabled: !imp.add.length, onclick: jahrUebernehmen }, 'Übernehmen'),
      h('button', { class: 'btn sec', onclick: () => { S.imp = null; render(); } }, 'Abbrechen')));
    return out;
  }

  /* ---------- Ansicht: Jahresübersicht ---------- */
  function viewYear() {
    const d = S.data; const yNow = new Date().getFullYear(); const year = S.year || yNow;
    const ySel = h('select', { onchange: (e) => { S.year = Number(e.target.value); render(); } }, [yNow - 2, yNow - 1, yNow, yNow + 1].map((yy) => h('option', { value: yy, selected: yy === year }, yy)));
    const yt = C.yearTotals(d.months, d.persons, year);
    const cols = C.yearColumns(d.persons).map((c) => [c.p, c.k, c.k === 'bruttoC' ? 'Brutto' : 'Netto']);
    const tbl = h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, h('th', {}, 'Monat'), cols.map((c) => h('th', { class: 'r' }, `${c[0].vorname} ${c[2]}`)), h('th', { class: 'r' }, 'Stunden'))),
      h('tbody', {}, yt.rows.map((r) => h('tr', {}, h('td', {}, C.MONATE[r.m - 1]), cols.map((c) => h('td', { class: 'r' }, !r.empty && r.per[c[0].id] ? C.fmtMoney(r.per[c[0].id][c[1]]) : '')), h('td', { class: 'r' }, r.empty ? '' : C.fmtHc(r.hc))))),
      h('tfoot', {}, h('tr', {}, h('td', {}, 'Total'), cols.map((c) => h('td', { class: 'r' }, C.fmtMoney(yt.tot.perPerson[c[0].id][c[1]]))), h('td', { class: 'r' }, C.fmtHc(yt.tot.hc)))));
    return h('div', {}, h('div', { class: 'card' }, h('h2', {}, 'Jahresübersicht'), h('div', { class: 'row' }, ySel), h('div', { class: 'scroll' }, tbl), h('p', { class: 'muted small' }, 'Für alle Spalten die Tabelle seitlich wischen.'),
      h('p', { class: 'muted small' }, `Abgerechnete Monate: ${yt.tot.count} von 12 · Ausbezahlt netto: CHF ${C.fmtMoney(yt.tot.netto)}`),
      h('button', { class: 'btn', onclick: async () => {
        const bytes = await P.jahresuebersicht(window.PDFLib, { employer: d.employer, persons: d.persons, year, months: d.months });
        S.lastYearFile = { name: `Jahresübersicht Löhne Assistenz ${year}.pdf`, year, blob: new Blob([bytes], { type: 'application/pdf' }) }; render();
      } }, 'PDF erstellen'),
      S.lastYearFile && S.lastYearFile.year === year ? h('div', { class: 'row' }, h('button', { class: 'btn sec', onclick: () => openBlob(S.lastYearFile) }, 'Ansehen')) : null,
      h('p', { class: 'muted small' }, 'Wenn ein Monat falsch erfasst wurde, in „Abrechnung“ denselben Monat neu erstellen: Der Eintrag wird ersetzt.')),
      importBlock(year));
  }

  /* ---------- Ansicht: Einstellungen ---------- */
  function field(label, value, onset, opts) {
    return h('label', { class: 'f' }, h('span', {}, label), h('input', Object.assign({ type: 'text', value: value == null ? '' : value, onchange: (e) => { onset(e.target.value.trim()); saveSoon(); } }, opts || {})));
  }
  function viewSettings() {
    const d = S.data; const out = h('div', {});
    if (S.msg) { out.append(h('div', { class: 'blockers' }, h('p', {}, S.msg))); S.msg = null; }
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Arbeitgeber (Briefkopf)'),
      field('Name', d.employer.name, (v) => { d.employer.name = v; }), field('Strasse', d.employer.strasse, (v) => { d.employer.strasse = v; }),
      field('PLZ Ort', d.employer.ort, (v) => { d.employer.ort = v; }), field('E-Mail (für CC)', d.employer.email, (v) => { d.employer.email = v; })));
    const num = (k, label) => field(label, d.settings[k], (v) => { const n = Number(String(v).replace(',', '.')); if (isFinite(n) && n >= 0) d.settings[k] = n; }, { inputmode: 'decimal' });
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Sätze'), num('stundenlohn', 'Stundenlohn (CHF)'), num('ferien', 'Ferienentschädigung (%)'), num('ahv', 'AHV/IV/EO (%)'), num('freibetrag', 'Freibetrag pro Monat ohne AHV-Abzug (CHF)'),
      h('p', { class: 'muted small' }, 'ALV, BVG, NBU, Krankentaggeld und Quellensteuer sind fest auf 0.')));
    // Personen
    const pc = h('div', { class: 'card' }, h('h2', {}, 'Assistenzpersonen'));
    d.persons.forEach((p) => {
      if (S.editing === p.id) { pc.append(personForm(p)); return; }
      pc.append(h('div', { class: 'file' }, h('span', {}, h('strong', {}, p.kurzname), h('br'), h('span', { class: 'muted small' }, `${p.ahvAbzug ? 'mit' : 'ohne'} AHV-Abzug${p.pauschal ? ' · Stunden nach Total' : ''}`)),
        h('button', { class: 'btn sec small', onclick: () => { S.editing = p.id; render(); } }, 'Bearbeiten')));
    });
    pc.append(h('button', { class: 'btn sec', onclick: () => { const p = { id: uid(), anrede: 'Frau', name: '', kurzname: '', vorname: '', strasse: '', plzOrt: '', email: '', ahvNr: '', ahvAbzug: true, pauschal: false, clockifyKey: '', zahlung: '' }; d.persons.push(p); S.editing = p.id; render(); } }, '+ Person hinzufügen'));
    out.append(pc);
    // Sicherung
    const fileIn = h('input', { type: 'file', accept: '.json,application/json', class: 'hidden', onchange: async (e) => {
      const f = e.target.files[0]; if (!f) return;
      const pin = prompt('PIN der Sicherung eingeben:'); if (!pin) return;
      try { const b = JSON.parse(await f.text()); const key = await deriveKey(pin, unb64(b.salt), b.iter); const data = await decryptWith(key, b);
        if (!confirm('Alle aktuellen Daten durch die Sicherung ersetzen?')) return;
        dropSaves(); S.key = key; S.salt = unb64(b.salt); S.data = data; localStorage.setItem(VAULT_KEY, JSON.stringify(b)); S.tab = 'abr'; render();
      } catch (err) { alert('PIN falsch oder Datei beschädigt.'); }
    } });
    out.append(h('details', { class: 'card', open: !!S.secOpen, ontoggle: (e) => { S.secOpen = e.target.open; } }, h('summary', {}, 'Sicherheit'),
      h('h3', {}, 'Abruf-Schlüssel'),
      field('Abruf-Schlüssel', d.settings.abrufKey || '', (v) => { d.settings.abrufKey = v; }, { type: 'password', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' }),
      h('p', { class: 'muted small' }, 'Damit holt „Stunden holen“ die Stunden direkt aus der Tabelle. Der Schlüssel bleibt verschlüsselt im Gerät und in der Sicherung.'),
      h('hr'),
      h('h3', {}, 'Sicherung und PIN'),
      h('p', { class: 'muted small' }, 'Die Sicherungsdatei ist mit deiner PIN verschlüsselt. Lege sie z. B. im Google-Drive-Ordner ab.'),
      h('button', { class: 'btn', onclick: async () => {
        await save(); const text = localStorage.getItem(VAULT_KEY); const name = `Sicherung Abrechnung ${new Date().toISOString().slice(0, 10)}.json`;
        const file = new File([text], name, { type: 'application/json' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); return; } catch (e) { if (e.name === 'AbortError') return; } }
        const a = h('a', { href: URL.createObjectURL(file), download: name }); document.body.append(a); a.click(); a.remove();
      } }, 'Sicherung speichern'),
      h('button', { class: 'btn sec', onclick: () => fileIn.click() }, 'Sicherung laden'), fileIn,
      h('button', { class: 'btn sec', onclick: async () => {
        const old = prompt('Aktuelle PIN:'); if (old == null) return;
        try { const v = JSON.parse(localStorage.getItem(VAULT_KEY)); await decryptWith(await deriveKey(old, unb64(v.salt), v.iter), v); } catch (e) { alert('PIN falsch.'); return; }
        const n1 = prompt('Neue PIN (6–8 Ziffern):'); if (n1 == null) return; if (!/^\d{6,8}$/.test(n1)) { alert('Die PIN muss aus 6 bis 8 Ziffern bestehen.'); return; }
        if (prompt('Neue PIN wiederholen:') !== n1) { alert('Die PIN stimmen nicht überein.'); return; }
        S.salt = crypto.getRandomValues(new Uint8Array(16)); S.key = await deriveKey(n1, S.salt, ITER); await save(); alert('PIN geändert. Bitte danach eine neue Sicherung speichern.');
      } }, 'PIN ändern'),
      h('button', { class: 'btn sec', onclick: lock }, 'Jetzt sperren'),
      !d.persons.some((p) => p.id.startsWith('demo')) && !d.persons.length ? h('button', { class: 'btn sec', onclick: () => { loadDemo(d); saveSoon(); render(); } }, 'Erfundene Beispieldaten laden') : null,
      h('button', { class: 'btn danger', onclick: () => { if (confirm('Wirklich ALLE Daten in diesem Gerät löschen? Das geht nur mit einer Sicherungsdatei rückgängig.') && confirm('Letzte Rückfrage: Alles löschen?')) { dropSaves(); localStorage.removeItem(VAULT_KEY); lock(); } } }, 'Alle Daten löschen')));
    return out;
  }
  function personForm(p) {
    const d = S.data;
    const chk = (label, k) => h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: p[k], onchange: (e) => { p[k] = e.target.checked; saveSoon(); } }), label);
    return h('div', { class: 'pform' },
      h('label', { class: 'f' }, h('span', {}, 'Anrede'), h('select', { onchange: (e) => { p.anrede = e.target.value; saveSoon(); } }, ['Frau', 'Herr'].map((a) => h('option', { selected: p.anrede === a }, a)))),
      field('Name auf Dokumenten (mit Zweitnamen)', p.name, (v) => { p.name = v; }), field('Kurzname für Dateien und Ordner', p.kurzname, (v) => { p.kurzname = v; }),
      field('Vorname (Anrede in der E-Mail)', p.vorname, (v) => { p.vorname = v; }), field('Strasse', p.strasse, (v) => { p.strasse = v; }), field('PLZ Ort', p.plzOrt, (v) => { p.plzOrt = v; }),
      field('E-Mail', p.email, (v) => { p.email = v; }, { inputmode: 'email' }), field('AHV-Nr.', p.ahvNr, (v) => { p.ahvNr = v; }),
      field('Name oder E-Mail in Clockify (falls anders)', p.clockifyKey, (v) => { p.clockifyKey = v; }),
      field('Zahlungsangabe unter dem Nettolohn (optional, z. B. IBAN)', p.zahlung, (v) => { p.zahlung = v; }),
      chk('AHV-Abzug', 'ahvAbzug'), chk('Keine Erfassung: Stunden nach Total auf Sonntage/Donnerstage verteilen', 'pauschal'),
      h('div', { class: 'row' }, h('button', { class: 'btn', onclick: () => { S.editing = null; render(); } }, 'Fertig'),
        h('button', { class: 'btn danger', onclick: () => { if (confirm(`${p.kurzname || 'Person'} löschen?`)) { d.persons = d.persons.filter((x) => x.id !== p.id); S.editing = null; saveSoon(); render(); } } }, 'Löschen')));
  }

  /* ---------- Rahmen ---------- */
  function render() {
    root.replaceChildren();
    if (!S.key) { root.append(localStorage.getItem(VAULT_KEY) ? viewLock() : viewOnboarding()); return; }
    const tabs = [['abr', 'Abrechnung'], ['year', 'Jahr'], ['set', 'Einstellungen']];
    const main = h('main', {}, S.tab === 'abr' ? viewAbr() : (S.tab === 'year' ? viewYear() : viewSettings()));
    root.append(h('header', {}, h('h1', {}, tabs.find((t) => t[0] === S.tab)[1])), main,
      h('nav', {}, tabs.map((t) => h('button', { class: S.tab === t[0] ? 'on' : '', onclick: () => { S.tab = t[0]; render(); window.scrollTo(0, 0); } }, t[1]))));
  }
  render();
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
