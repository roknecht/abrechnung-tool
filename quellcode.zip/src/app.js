/* Oberfläche der App. Alle Daten bleiben im Gerät (verschlüsselt mit der PIN). */
(function () {
  'use strict';
  const C = window.Core; const P = window.Pdf;
  const VAULT_KEY = 'abrechnung_vault_v1';
  const ABRUF_URL = 'https://script.google.com/macros/s/AKfycbzLURthGVd_o-W2aUW4RnsYRjn0UkTwVO19m7v2Hhtq-QFdGDQF5GkG---faGoFl-iuAg/exec';
  const ITER = 250000;
  const enc = new TextEncoder(); const dec = new TextDecoder();

  /* ---------- kleine Helfer ---------- */
  function h(tag, props) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === 'class') el.className = v;
      else if (k === 'value') el.value = v;
      else if (k === 'checked') el.checked = !!v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else if (v !== false && v != null) el.setAttribute(k, v);
    }
    for (const c of [].slice.call(arguments, 2).flat(Infinity)) { if (c == null || c === false) continue; el.append(c.nodeType ? c : document.createTextNode(String(c))); }
    return el;
  }
  const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(s); };
  const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  const uid = () => 'p' + Math.random().toString(36).slice(2, 9);

  /* ---------- Verschlüsselung ---------- */
  async function deriveKey(pin, salt, iter) {
    const km = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function encryptWith(key, obj) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(obj))));
    return { iv: b64(iv), ct: b64(ct) };
  }
  async function decryptWith(key, blob) {
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(blob.iv) }, key, unb64(blob.ct));
    return JSON.parse(dec.decode(pt));
  }

  /* ---------- Zustand ---------- */
  const S = { key: null, salt: null, data: null, tab: 'abr', result: null, editing: null, busy: false, msg: null };
  const root = document.getElementById('app');

  const emptyData = () => ({
    v: 1, settings: { stundenlohn: 35, ferien: 8.33, ahv: 5.3, freibetrag: 1400, abrufKey: '' },
    employer: { name: '', strasse: '', ort: '', email: '' }, persons: [], months: {}, draft: null,
  });
  async function save() {
    const blob = await encryptWith(S.key, S.data);
    localStorage.setItem(VAULT_KEY, JSON.stringify({ v: 1, salt: b64(S.salt), iter: ITER, iv: blob.iv, ct: blob.ct }));
  }
  let saveTimer = null;
  function saveSoon() { clearTimeout(saveTimer); saveTimer = setTimeout(() => save().catch(() => {}), 400); }

  /* ---------- Sperre / Start ---------- */
  function lock() { S.key = null; S.data = null; S.result = null; S.editing = null; render(); }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { S.hiddenAt = Date.now(); } else if (S.key && S.hiddenAt && Date.now() - S.hiddenAt > 120000) lock();
  });

  function viewOnboarding() {
    const pin1 = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'new-password', maxlength: 8, placeholder: 'PIN (6–8 Ziffern)' });
    const pin2 = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'new-password', maxlength: 8, placeholder: 'PIN wiederholen' });
    const err = h('p', { class: 'err' });
    const fileIn = h('input', { type: 'file', accept: '.json,application/json', class: 'hidden', onchange: async (ev) => {
      const f = ev.target.files[0]; if (!f) return;
      try { S.pendingBackup = JSON.parse(await f.text()); if (!S.pendingBackup.ct) throw new Error('x'); err.textContent = 'Sicherung gewählt. PIN der Sicherung eingeben und „Sicherung laden“ tippen.'; err.className = 'ok'; loadBtn.disabled = false; } catch (e) { err.className = 'err'; err.textContent = 'Das ist keine gültige Sicherungsdatei.'; }
    } });
    const loadBtn = h('button', { class: 'btn sec', disabled: true, onclick: async () => {
      err.className = 'err';
      if (!/^\d{6,8}$/.test(pin1.value)) { err.textContent = 'PIN der Sicherung eingeben (6–8 Ziffern).'; return; }
      try {
        const b = S.pendingBackup; const salt = unb64(b.salt); const key = await deriveKey(pin1.value, salt, b.iter || ITER);
        const data = await decryptWith(key, b);
        S.key = key; S.salt = salt; S.data = data; localStorage.setItem(VAULT_KEY, JSON.stringify(b)); S.tab = 'abr'; render();
      } catch (e) { err.textContent = 'PIN falsch oder Datei beschädigt.'; }
    } }, 'Sicherung laden');
    const start = async (demo) => {
      err.className = 'err';
      if (!/^\d{6,8}$/.test(pin1.value)) { err.textContent = 'Die PIN muss aus 6 bis 8 Ziffern bestehen.'; return; }
      if (pin1.value !== pin2.value) { err.textContent = 'Die beiden PIN stimmen nicht überein.'; return; }
      S.salt = crypto.getRandomValues(new Uint8Array(16)); S.key = await deriveKey(pin1.value, S.salt, ITER);
      S.data = emptyData(); if (demo) loadDemo(S.data); await save(); S.tab = demo ? 'abr' : 'set'; render();
    };
    return h('div', { class: 'center' },
      h('h1', {}, 'Abrechnung'),
      h('p', { class: 'muted' }, 'Erster Start. Lege eine PIN fest. Alle Angaben bleiben verschlüsselt in diesem Gerät. Merke dir die PIN gut: Ohne PIN lassen sich die Daten nur mit einer Sicherungsdatei wiederherstellen.'),
      pin1, pin2, err,
      h('button', { class: 'btn', onclick: () => start(false) }, 'Leer starten'),
      h('button', { class: 'btn sec', onclick: () => start(true) }, 'Mit erfundenen Beispieldaten starten'),
      h('hr'), h('p', { class: 'muted' }, 'Oder eine bestehende Sicherung laden (PIN oben eingeben):'),
      h('button', { class: 'btn sec', onclick: () => fileIn.click() }, 'Sicherungsdatei wählen'), loadBtn, fileIn);
  }

  function viewLock() {
    const pin = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'current-password', maxlength: 8, placeholder: 'PIN' });
    const err = h('p', { class: 'err' });
    const go = async () => {
      err.textContent = '';
      try {
        const v = JSON.parse(localStorage.getItem(VAULT_KEY)); const salt = unb64(v.salt);
        const key = await deriveKey(pin.value, salt, v.iter); const data = await decryptWith(key, v);
        S.key = key; S.salt = salt; S.data = data; render();
      } catch (e) { err.textContent = 'PIN falsch.'; pin.value = ''; }
    };
    pin.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    return h('div', { class: 'center' }, h('h1', {}, 'Abrechnung'), h('p', { class: 'muted' }, 'Gesperrt'), pin, err, h('button', { class: 'btn', onclick: go }, 'Entsperren'),
      h('p', { class: 'muted small' }, 'PIN vergessen? Dann nur mit einer Sicherungsdatei: Daten löschen und beim Start die Sicherung laden. ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); if (confirm('Wirklich ALLE Daten in diesem Gerät löschen? Das geht nur mit einer Sicherungsdatei rückgängig.')) { localStorage.removeItem(VAULT_KEY); render(); } } }, 'Alle Daten löschen')));
  }

  /* ---------- Beispieldaten (erfunden) ---------- */
  function loadDemo(d) {
    d.employer = { name: 'Max Muster', strasse: 'Musterstrasse 1', ort: '8000 Zürich', email: 'max@example.com' };
    d.persons = [
      { id: 'demo1', anrede: 'Frau', name: 'Anna Beispiel', kurzname: 'Anna Beispiel', vorname: 'Anna', strasse: 'Beispielweg 2', plzOrt: '3000 Bern', email: 'anna@example.com', ahvNr: '756.0000.0000.02', ahvAbzug: true, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo2', anrede: 'Herr', name: 'Hans Probe', kurzname: 'Hans Probe', vorname: 'Hans', strasse: 'Probestrasse 3', plzOrt: '4000 Basel', email: 'hans@example.com', ahvNr: '756.0000.0000.03', ahvAbzug: false, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo3', anrede: 'Herr', name: 'Peter Test', kurzname: 'Peter Test', vorname: 'Peter', strasse: 'Testgasse 4', plzOrt: '5000 Aarau', email: 'peter@example.com', ahvNr: '756.0000.0000.04', ahvAbzug: false, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo4', anrede: 'Frau', name: 'Maria Demo', kurzname: 'Maria Demo', vorname: 'Maria', strasse: 'Demoplatz 5', plzOrt: '6000 Luzern', email: 'maria@example.com', ahvNr: '756.0000.0000.05', ahvAbzug: true, pauschal: true, clockifyKey: '', zahlung: '' },
    ];
  }
  function demoCsv(y, m, persons) {
    const head = 'Project,Client,Description,Task,User,Group,Email,Tags,Billable,Start Date,Start Time,End Date,End Time,Duration (h),Duration (decimal),Billable Rate (CHF),Billable Amount (CHF)';
    const rows = [head]; const dm = (d) => `${C.pad(m)}/${C.pad(d)}/${y}`;
    const add = (p, d, st, en, dur, endDay) => rows.push(`,,,,${p.name},,${p.email},,No,${dm(d)},${st},${dm(endDay || d)},${en},${dur},${(Number(dur.split(':')[0]) + Number(dur.split(':')[1]) / 60).toFixed(2)},0,0`);
    const a = persons.find((p) => p.id === 'demo1'); const b = persons.find((p) => p.id === 'demo2');
    if (a) { [[2, '4:00'], [6, '5:00'], [11, '4:20'], [17, '5:00'], [24, '4:00']].forEach(([d, du]) => add(a, d, '08:00:00', '12:00:00', du)); add(a, 27, '22:00:00', '02:00:00', '4:00', 28); }
    if (b) { for (let d = 3; d <= 28; d += 2) add(b, d, '09:00:00', '13:00:00', d % 4 ? '3:30' : '2:45'); }
    rows.push(`,,,,Gast Beispiel,,gast@example.com,,No,${dm(5)},09:00:00,${dm(5)},10:00:00,1:00,1.00,0,0`);
    return rows.join('\n');
  }

  /* ---------- Entwurf der Monatsabrechnung ---------- */
  function prevMonth() { const t = new Date(); let y = t.getFullYear(); let m = t.getMonth(); if (m === 0) { m = 12; y--; } return { y, m }; }
  function ensureDraft() {
    const d = S.data;
    if (!d.draft) { const { y, m } = prevMonth(); d.draft = { key: C.monthKey(y, m), days: {}, csvHc: {}, skip: {}, excess: {}, pTotal: {}, pending: {}, manual: {}, info: null }; }
    return d.draft;
  }
  const keyYM = (k) => ({ y: Number(k.slice(0, 4)), m: Number(k.slice(5)) });
  const dayHc = (dr, id) => (dr.days[id] || []).reduce((a, q) => a + q.hc, 0);
  function resetDraft(key) { S.data.draft = { key, days: {}, csvHc: {}, skip: {}, excess: {}, pTotal: {}, pending: {}, manual: {}, info: null }; S.result = null; saveSoon(); }

  function applyCsv(text, filename) {
    const dr = ensureDraft(); const { y, m } = keyYM(dr.key); const d = S.data;
    const res = C.importClockify(text, y, m, d.persons.filter((p) => !p.pauschal));
    if (res.errors.length) { dr.info = { errors: res.errors, headers: res.headers || null, filename }; saveSoon(); return; }
    const keep = {}; d.persons.filter((p) => p.pauschal).forEach((p) => { keep[p.id] = dr.days[p.id] || []; });
    dr.days = keep; dr.csvHc = {}; dr.skip = {}; dr.excess = {}; dr.pending = {}; dr.manual = {};
    d.persons.filter((p) => !p.pauschal).forEach((p) => {
      const bp = res.byPerson[p.id];
      dr.days[p.id] = bp ? Object.keys(bp.days).sort().map((dt) => ({ date: dt, hc: bp.days[dt] })) : [];
      dr.csvHc[p.id] = bp ? Object.values(bp.days).reduce((a, v) => a + v, 0) : 0;
    });
    dr.info = { errors: [], warnings: res.warnings, unmatched: res.unmatched, outside: res.outside.length, rows: res.rows, filename };
    S.result = null; saveSoon();
  }

  /* ---------- Stunden direkt von der Erfassungsseite holen ---------- */
  async function fetchHours() {
    const dr = ensureDraft(); const d = S.data; const key = (d.settings.abrufKey || '').trim();
    const fail = (msg) => { dr.info = { errors: [msg], headers: null, filename: 'Stundenerfassung' }; S.fetching = false; saveSoon(); render(); };
    if (!key) { S.tab = 'set'; S.msg = 'Bitte zuerst den Abruf-Schlüssel eintragen.'; render(); return; }
    S.fetching = true; render();
    let r;
    try {
      const resp = await fetch(ABRUF_URL + '?action=export&m=' + encodeURIComponent(dr.key) + '&k=' + encodeURIComponent(key), { method: 'GET', redirect: 'follow' });
      r = await resp.json();
    } catch (e) { return fail('Keine Verbindung zur Stundenerfassung. Bitte Internet prüfen und nochmals versuchen.'); }
    if (!r || !r.ok) return fail((r && r.error) || 'Unbekannter Fehler beim Abruf.');
    const ab = r.abschluss || [];
    const old = { days: JSON.parse(JSON.stringify(dr.days)), skip: Object.assign({}, dr.skip), excess: Object.assign({}, dr.excess), manual: Object.assign({}, dr.manual || {}) };
    if (!r.rows) { d.persons.filter((p) => !p.pauschal).forEach((p) => { dr.days[p.id] = []; dr.csvHc[p.id] = 0; }); dr.skip = {}; dr.excess = {}; dr.info = { errors: ['Für diesen Monat sind in der Stundenerfassung noch keine Stunden eingetragen.'], headers: null, filename: 'Stundenerfassung', abschluss: ab }; }
    else {
      applyCsv(r.csv, 'Stundenerfassung ' + dr.key);
      if (dr.info && dr.info.errors && dr.info.errors.length) { S.fetching = false; saveSoon(); render(); return; }
      dr.info.abschluss = ab;
    }
    d.persons.filter((p) => p.pauschal).forEach((p) => { if (old.excess[p.id]) dr.excess[p.id] = old.excess[p.id]; });
    // Nur Stunden von Personen übernehmen, die den Monat abgeschickt haben (Status «abgeschickt» im Blatt «Abschluss»).
    // Bestehende Stunden in der App werden nur nach Rückfrage durch abgeschickte Stunden ersetzt.
    dr.pending = {}; dr.manual = {};
    const sig = (arr) => (arr || []).map((q) => q.date + ':' + q.hc).sort().join('|');
    const keepOld = (p) => { dr.days[p.id] = old.days[p.id] || []; if (old.excess[p.id]) dr.excess[p.id] = old.excess[p.id]; if (old.manual[p.id]) dr.manual[p.id] = true; };
    d.persons.filter((p) => !p.pauschal).forEach((p) => {
      const a = absOf(ab, p); const sub = !!a && a.status === 'abgeschickt';
      const oldDays = old.days[p.id] || []; const oldHc = oldDays.reduce((x, q) => x + q.hc, 0);
      const newHc = dayHc(dr, p.id);
      if (!sub) {
        dr.pending[p.id] = newHc;
        if (old.manual[p.id] && oldDays.length) { keepOld(p); delete dr.csvHc[p.id]; }
        else { dr.days[p.id] = []; dr.csvHc[p.id] = 0; if (old.skip[p.id]) dr.skip[p.id] = true; }
        return;
      }
      if (old.skip[p.id]) {
        if (newHc > 0 && confirm(`${p.kurzname}: In der App steht «Hat nicht gearbeitet». Abgeschickt wurden ${C.fmtHc(newHc)} h.\n\nMit den abgeschickten Stunden überschreiben?`)) return;
        dr.skip[p.id] = true; dr.days[p.id] = []; return;
      }
      if (!oldDays.length || sig(oldDays) === sig(dr.days[p.id])) { if (oldDays.length) keepOld(p); return; }
      const was = `${C.fmtHc(oldHc)} h (${oldDays.length} Einsätze${old.manual[p.id] ? ', manuell eingetragen' : ''})`;
      if (confirm(`${p.kurzname}: In der App stehen schon ${was}. Abgeschickt wurden ${C.fmtHc(newHc)} h.\n\nMit den abgeschickten Stunden überschreiben?`)) return;
      keepOld(p);
    });
    S.fetching = false; S.result = null; saveSoon(); render();
  }
  const absOf = (ab, p) => ab.find((x) => C.norm(x.name) === C.norm(p.kurzname) || C.norm(x.name) === C.norm(p.name));
  /* Hinweise zum Abschluss: wer hat den Monat abgeschickt, stimmen die Totale? */
  function abschlussNotes(dr) {
    const ab = dr.info && dr.info.abschluss; if (!ab) return [];
    const out = [];
    S.data.persons.filter((p) => !p.pauschal && !dr.skip[p.id]).forEach((p) => {
      const a = absOf(ab, p);
      const hc = dayHc(dr, p.id); const pend = (dr.pending || {})[p.id];
      if (!a || a.status !== 'abgeschickt') out.push(`${p.kurzname}: hat den Monat noch nicht abgeschickt${a && a.status === 'offen' ? ' (wieder zum Bearbeiten geöffnet)' : ''}${hc > 0 ? ' – in der App stehen deine manuell eingetragenen Stunden' : (pend > 0 ? ` – ${C.fmtHc(pend)} h eingetragen, aber noch nicht übernommen` : '')}.`);
      else if (Math.round(a.total * 100) !== hc) out.push(`${p.kurzname}: Total beim Abschicken ${a.total.toFixed(2)} h, jetzt ${C.fmtHc(hc)} h – nach dem Abschicken geändert?`);
    });
    return out;
  }

  /* ---------- Berechnung für die Kontrolle ---------- */
  function evaluate() {
    const d = S.data; const dr = ensureDraft(); const rows = []; const blockers = [];
    d.persons.forEach((p) => {
      const days = dr.days[p.id] || []; const hc = dayHc(dr, p.id); const skip = !!dr.skip[p.id];
      const r = { p, days, hc, skip };
      // Nicht gearbeitet: Lohnabrechnung mit 0.00 (ohne Stundenübersicht), Monat in der Jahresübersicht mit 0.00
      if (skip) { r.state = 'skip'; r.calc = C.calcPerson(p, 0, d.settings, {}); rows.push(r); return; }
      if (!p.pauschal && dr.pending && dr.pending[p.id] != null && !days.length) { r.state = 'pending'; blockers.push(`${p.kurzname}: hat den Monat noch nicht abgeschickt – später nochmals «Stunden holen».`); rows.push(r); return; }
      if (hc <= 0) { r.state = 'missing'; blockers.push(`${p.kurzname}: keine Stunden erfasst – bitte entscheiden.`); rows.push(r); return; }
      if (p.pauschal) {
        const t = dr.pTotal[p.id];
        if (t == null || Math.round(t * 100) !== hc) blockers.push(`${p.kurzname}: Summe der Tage (${C.fmtHc(hc)}) entspricht nicht dem Stundentotal${t != null ? ' (' + Number(t).toFixed(2) + ')' : ''}.`);
      }
      r.calc = C.calcPerson(p, hc, d.settings, { excessMode: dr.excess[p.id] });
      if (r.calc.excess && !dr.excess[p.id]) blockers.push(`${p.kurzname}: AHV-Lohn über CHF ${C.fmtMoney(C.toCents(d.settings.freibetrag))} – bitte Vorgehen wählen.`);
      r.state = 'ok'; rows.push(r);
    });
    return { rows, blockers, totalHc: rows.reduce((a, r) => a + (r.state === 'ok' ? r.hc : 0), 0) };
  }

  /* ---------- Dokumente erstellen ---------- */
  async function createDocs() {
    const d = S.data; const dr = ensureDraft(); const ev = evaluate(); const { y, m } = keyYM(dr.key);
    if (ev.blockers.length) return;
    if (d.months[dr.key] && !confirm('Für diesen Monat wurden schon Dokumente erstellt. Neu erstellen und den Eintrag in der Jahresübersicht ersetzen?')) return;
    S.busy = true; render();
    try {
      const files = []; const rec = { created: new Date().toISOString(), persons: {} };
      for (const r of ev.rows) {
        if (r.state === 'skip') {
          const lohn0 = await P.lohnabrechnung(window.PDFLib, { employer: d.employer, person: r.p, y, m, calc: r.calc, settings: d.settings });
          files.push({ name: `${dr.key} Lohnabrechnung ${r.p.kurzname}.pdf`, bytes: lohn0, person: r.p.kurzname, pid: r.p.id });
          rec.persons[r.p.id] = { hc: 0, bruttoC: 0, nettoC: 0, nichtGearbeitet: true };
          continue;
        }
        if (r.state !== 'ok') continue;
        const days = r.days.slice().sort((a, b) => a.date.localeCompare(b.date));
        const lohn = await P.lohnabrechnung(window.PDFLib, { employer: d.employer, person: r.p, y, m, calc: r.calc, settings: d.settings });
        const std = await P.stundenuebersicht(window.PDFLib, { employer: d.employer, person: r.p, y, m, days, settings: d.settings });
        files.push({ name: `${dr.key} Lohnabrechnung ${r.p.kurzname}.pdf`, bytes: lohn, person: r.p.kurzname, pid: r.p.id });
        files.push({ name: `${dr.key} Stundenübersicht ${r.p.kurzname}.pdf`, bytes: std, person: r.p.kurzname, pid: r.p.id });
        rec.persons[r.p.id] = { hc: r.hc, bruttoC: r.calc.bruttoC, nettoC: r.calc.nettoC };
      }
      d.months[dr.key] = rec; await save();
      const jb = await P.jahresuebersicht(window.PDFLib, { employer: d.employer, persons: d.persons, year: y, months: d.months });
      files.push({ name: `Jahresübersicht Löhne Assistenz ${y}.pdf`, bytes: jb, person: 'Jahresübersicht', pid: null });
      S.result = { key: dr.key, year: y, files: files.map((f) => ({ name: f.name, person: f.person, pid: f.pid, blob: new Blob([f.bytes], { type: 'application/pdf' }) })) };
      S.ablage = null; S.entw = null; S.kombi = null;
    } catch (e) { alert('Fehler beim Erstellen der Dokumente: ' + e.message); }
    S.busy = false; render();
  }
  async function shareFiles(list) {
    const files = list.map((f) => new File([f.blob], f.name, { type: 'application/pdf' }));
    if (navigator.canShare && navigator.canShare({ files })) { try { await navigator.share({ files }); return; } catch (e) { if (e.name === 'AbortError') return; } }
    list.forEach((f) => { const a = h('a', { href: URL.createObjectURL(f.blob), download: f.name }); document.body.append(a); a.click(); a.remove(); });
  }
  const openBlob = (f) => window.open(URL.createObjectURL(f.blob), '_blank');

  /* ---------- Ansicht: Abrechnung ---------- */
  function numInput(value, onset, opts) {
    return h('input', Object.assign({ type: 'text', inputmode: 'decimal', value, onchange: (e) => { const v = Number(String(e.target.value).replace(',', '.')); onset(isFinite(v) ? v : 0); } }, opts || {}));
  }
  function viewAbr() {
    const d = S.data; const dr = ensureDraft(); const { y, m } = keyYM(dr.key); const ev = evaluate();
    const wrap = h('div', {});
    if (!d.persons.length) return h('div', { class: 'card' }, h('p', {}, 'Es sind noch keine Assistenzpersonen erfasst. Bitte zuerst unter „Einstellungen“ Arbeitgeber und Personen eintragen.'), h('button', { class: 'btn', onclick: () => { S.tab = 'set'; render(); } }, 'Zu den Einstellungen'));

    // Monat
    const mSel = h('select', { onchange: (e) => { if (hasDraftData(dr) && !confirm('Der Entwurf des aktuellen Monats geht verloren. Fortfahren?')) { render(); return; } resetDraft(C.monthKey(y, Number(e.target.value))); render(); } },
      C.MONATE.map((n, i) => h('option', { value: i + 1, selected: i + 1 === m }, n)));
    const yNow = new Date().getFullYear();
    const ySel = h('select', { onchange: (e) => { if (hasDraftData(dr) && !confirm('Der Entwurf des aktuellen Monats geht verloren. Fortfahren?')) { render(); return; } resetDraft(C.monthKey(Number(e.target.value), m)); render(); } },
      [yNow - 2, yNow - 1, yNow, yNow + 1].map((yy) => h('option', { value: yy, selected: yy === y }, yy)));
    const fileIn = h('input', { type: 'file', accept: '.csv,text/csv,text/plain', class: 'hidden', onchange: async (e) => { const f = e.target.files[0]; if (!f) return; applyCsv(await f.text(), f.name); render(); } });
    wrap.append(h('div', { class: 'card' }, h('h2', {}, 'Abrechnungsmonat'), h('div', { class: 'row' }, mSel, ySel),
      h('p', { class: 'muted small' }, `Abrechnungsdatum: ${C.fmtDate(C.nextMonthFirst(y, m))}`),
      h('button', { class: 'btn', disabled: S.fetching, onclick: fetchHours }, S.fetching ? 'Hole Stunden …' : 'Stunden holen'),
      h('button', { class: 'linkbtn', onclick: () => fileIn.click() }, 'Reserve: stattdessen CSV-Datei einlesen'), fileIn,
      d.persons.some((p) => p.id.startsWith('demo')) ? h('button', { class: 'btn sec', onclick: () => { applyCsv(demoCsv(y, m, d.persons), 'Beispiel.csv'); render(); } }, 'Beispiel-CSV laden (erfunden)') : null,
      infoBlock(dr)));

    // Personen
    ev.rows.forEach((r) => wrap.append(personCard(r, dr, y, m)));

    // Kontrolle
    const tbl = h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, ['Person', 'Std.', 'Brutto', 'AHV', 'Netto'].map((t, i) => h('th', { class: i ? 'r' : '' }, t)))),
      h('tbody', {}, ev.rows.map((r) => h('tr', {}, h('td', { class: 'wrap' }, r.p.kurzname, r.state === 'skip' ? h('div', { class: 'muted small' }, 'nicht gearbeitet') : null), h('td', { class: 'r' }, r.state === 'ok' ? C.fmtHc(r.hc) : (r.state === 'skip' ? '0.00' : (r.state === 'pending' ? 'offen' : '?'))),
        h('td', { class: 'r' }, r.calc ? C.fmtMoney(r.calc.bruttoC) : ''), h('td', { class: 'r' }, r.calc ? C.fmtMoney(r.calc.ahvC) : ''), h('td', { class: 'r' }, r.calc ? C.fmtMoney(r.calc.nettoC) : '')))),
      h('tfoot', {}, h('tr', {}, h('td', { class: 'wrap' }, 'Total aller Personen'), h('td', { class: 'r' }, C.fmtHc(ev.totalHc)), h('td', {}), h('td', {}), h('td', { class: 'r' }, C.fmtMoney(ev.rows.reduce((a, r) => a + (r.calc ? r.calc.nettoC : 0), 0))))));
    const csvDiff = ev.rows.filter((r) => !r.p.pauschal && r.state === 'ok' && dr.csvHc[r.p.id] != null && dr.info && !dr.info.errors.length && dr.csvHc[r.p.id] !== r.hc);
    wrap.append(h('div', { class: 'card' }, h('h2', {}, 'Kontrolle'), h('div', { class: 'scroll' }, tbl),
      csvDiff.map((r) => h('p', { class: 'warn' }, `${r.p.kurzname}: Stunden von Hand geändert (CSV: ${C.fmtHc(dr.csvHc[r.p.id])}, jetzt: ${C.fmtHc(r.hc)}).`)),
      ev.blockers.length ? h('div', { class: 'blockers' }, h('strong', {}, 'Noch offen:'), ev.blockers.map((b) => h('p', {}, b))) : h('p', { class: 'ok' }, 'Alles geprüft. Die Dokumente können erstellt werden.'),
      h('button', { class: 'btn', disabled: !!ev.blockers.length || S.busy, onclick: createDocs }, S.busy ? 'Erstelle …' : 'Dokumente erstellen')));

    if (S.result && S.result.key === dr.key) wrap.append(resultCard());
    return wrap;
  }
  const hasDraftData = (dr) => Object.values(dr.days).some((a) => a.length) || Object.keys(dr.skip).length;

  function infoBlock(dr) {
    const i = dr.info; if (!i) return null;
    if (i.errors && i.errors.length) return h('div', { class: 'blockers' }, h('strong', {}, `Datei „${i.filename}“ konnte nicht gelesen werden:`), i.errors.map((e) => h('p', {}, e)), i.headers ? h('p', { class: 'small' }, 'Gefundene Spalten: ' + i.headers.join(' | ')) : null);
    const out = [h('p', { class: 'ok small' }, `„${i.filename}“ eingelesen: ${i.rows} Zeilen.`)];
    if (i.outside) out.push(h('p', { class: 'warn small' }, `${i.outside} Einträge liegen in anderen Monaten und wurden ignoriert.`));
    (i.unmatched || []).forEach((u) => out.push(h('p', { class: 'warn small' }, `Unbekannter Benutzer „${u.user}“ (${u.count} Einträge, ${C.fmtHc(u.hc)} h) – keiner Person zugeordnet. Der Kurzname in den Einstellungen muss genau so geschrieben sein wie der Name im Blatt «Personen».`)));
    abschlussNotes(dr).forEach((w) => out.push(h('p', { class: 'warn small' }, w)));
    (i.warnings || []).forEach((w) => out.push(h('p', { class: 'warn small' }, w)));
    return h('div', {}, out);
  }

  function personCard(r, dr, y, m) {
    const p = r.p; const days = dr.days[p.id] || (dr.days[p.id] = []);
    const used = new Set(days.map((q) => q.date)); const mdays = C.monthDays(y, m);
    if (!S.open) S.open = {};
    const isOpen = !!S.open[p.id];
    const touch = () => { if (!p.pauschal) { if (!dr.manual) dr.manual = {}; dr.manual[p.id] = true; } };
    const openEdit = () => { S.open[p.id] = true; };
    const card = h('div', { class: 'card' },
      h('div', { class: 'row between' }, h('h3', {}, p.kurzname), h('span', { class: 'tag' }, p.ahvAbzug ? 'mit AHV-Abzug' : 'ohne AHV-Abzug')));
    if (r.state === 'skip') {
      card.append(h('p', { class: 'muted' }, 'Hat in diesem Monat nicht gearbeitet – es wird eine Lohnabrechnung mit 0.00 erstellt (ohne Stundenübersicht).'),
        h('button', { class: 'btn sec', onclick: () => { delete dr.skip[p.id]; saveSoon(); render(); } }, 'Rückgängig'));
      return card;
    }
    const pend = dr.pending && dr.pending[p.id] != null && !p.pauschal;
    const notWorked = (ask) => h('button', { class: 'btn sec', onclick: () => { if (ask && !confirm(ask)) return; dr.skip[p.id] = true; delete S.open[p.id]; saveSoon(); render(); } }, 'Hat nicht gearbeitet');
    const startEntry = () => { if (!p.pauschal) { days.push({ date: mdays.find((x) => !used.has(x)) || mdays[0], hc: 0 }); touch(); } openEdit(); saveSoon(); render(); };
    if (pend) {
      const ph = dr.pending[p.id];
      card.append(h('p', { class: 'warn' }, days.length
        ? 'Noch nicht abgeschickt. Die Stunden unten hast du manuell eingetragen.'
        : `Noch nicht abgeschickt${ph > 0 ? ` (${C.fmtHc(ph)} h eingetragen)` : ''}. Die Stunden werden übernommen, sobald die Person den Monat abgeschickt hat. Dann nochmals «Stunden holen».`));
    }
    if (!days.length && !isOpen) {
      if (!pend) card.append(h('p', { class: 'muted' }, p.pauschal ? 'Noch keine Stunden für diesen Monat.' : 'Keine Stunden in diesem Monat.'));
      card.append(h('div', { class: 'row' }, h('button', { class: 'btn', onclick: startEntry }, pend ? 'Manuell eintragen' : 'Stunden eintragen'),
        notWorked(pend ? `${p.kurzname} hat den Monat nicht abgeschickt. Wirklich «nicht gearbeitet» (Lohnabrechnung mit 0.00)?` : '')));
      return card;
    }
    if (days.length) {
      card.append(h('div', { class: 'row between' }, h('strong', {}, `${days.length} Einsätze · ${C.fmtHc(r.hc)} h`),
        h('button', { class: 'btn sec small', onclick: () => { if (isOpen) delete S.open[p.id]; else openEdit(); render(); } }, isOpen ? 'Schliessen' : 'Bearbeiten')));
    }
    if (isOpen && p.pauschal) {
      const sat = C.sundaysThursdays(y, m);
      const msg = h('p', { class: 'err small' });
      card.append(h('p', { class: 'muted small' }, 'Stundentotal eingeben, dann wird auf Sonntage und Donnerstage verteilt (je 4 oder 5 Stunden, wenn nötig auch 3).'),
        h('label', {}, 'Stundentotal im Monat'), numInput(dr.pTotal[p.id] != null ? dr.pTotal[p.id] : '', (v) => { dr.pTotal[p.id] = v; saveSoon(); }, { placeholder: 'z. B. 36' }),
        h('button', { class: 'btn', onclick: () => {
          const t = dr.pTotal[p.id]; const res = C.distribute(t, sat);
          if (res.error) { msg.textContent = res.error; return; } days.splice(0, days.length, ...res.days); saveSoon(); render();
        } }, 'Verteilung vorschlagen'), msg);
      if (!days.length) card.append(h('div', { class: 'row' }, h('button', { class: 'btn sec', onclick: () => { delete S.open[p.id]; render(); } }, 'Abbrechen'), notWorked('')));
    }
    if (isOpen && days.length) {
      const first = mdays.find((x) => !used.has(x)) || mdays[0];
      const list = h('div', { class: 'days' });
      days.forEach((q, idx) => list.append(h('div', { class: 'dayrow' },
        h('input', { type: 'date', value: q.date, min: mdays[0], max: mdays[mdays.length - 1], onchange: (e) => { if (e.target.value) { q.date = e.target.value; days.sort((a, b) => a.date.localeCompare(b.date)); touch(); saveSoon(); render(); } } }),
        h('span', { class: 'wd' }, C.weekdayName(q.date).slice(0, 2)),
        numInput(q.hc ? (q.hc / 100).toFixed(2) : '', (v) => { q.hc = Math.round(v * 100); touch(); saveSoon(); render(); }, { class: 'hrs' }),
        h('button', { class: 'x', title: 'Zeile löschen', onclick: () => { days.splice(idx, 1); touch(); saveSoon(); render(); } }, '×'))));
      card.append(list, h('div', { class: 'row between' }, h('button', { class: 'btn sec small', onclick: () => { days.push({ date: first, hc: 0 }); days.sort((a, b) => a.date.localeCompare(b.date)); touch(); saveSoon(); render(); } }, '+ Tag')));
    }
    if (p.pauschal && days.length && dr.pTotal[p.id] != null) {
      const ok = Math.round(dr.pTotal[p.id] * 100) === r.hc;
      card.append(h('p', { class: ok ? 'ok small' : 'err small' }, ok ? `Summe stimmt mit dem Total (${Number(dr.pTotal[p.id]).toFixed(2)} h) überein.` : `Summe ${C.fmtHc(r.hc)} h ≠ Total ${Number(dr.pTotal[p.id]).toFixed(2)} h.`));
    }
    if (r.calc && r.calc.excess) {
      const sel = h('select', { onchange: (e) => { if (e.target.value) dr.excess[p.id] = e.target.value; else delete dr.excess[p.id]; saveSoon(); render(); } },
        h('option', { value: '' }, 'Bitte wählen …'),
        h('option', { value: 'ohne', selected: dr.excess[p.id] === 'ohne' }, 'Ohne AHV-Abzug abrechnen'),
        h('option', { value: 'abziehen', selected: dr.excess[p.id] === 'abziehen' }, `AHV nur auf Teil über ${C.fmtMoney(C.toCents(S.data.settings.freibetrag))}`));
      card.append(h('div', { class: 'blockers' }, h('strong', {}, 'Achtung: AHV-Lohn über CHF ' + C.fmtMoney(C.toCents(S.data.settings.freibetrag))),
        h('p', {}, `Der AHV-Lohn beträgt CHF ${C.fmtMoney(r.calc.bruttoC)}. Möglicherweise muss auf den übersteigenden Teil AHV abgezogen werden (Freibetrag für Personen im Rentenalter). Bitte entscheiden:`), sel));
    }
    if (r.calc) card.append(h('p', { class: 'muted small' }, `Brutto CHF ${C.fmtMoney(r.calc.bruttoC)} · AHV ${C.fmtMoney(r.calc.ahvC)} · Netto CHF ${C.fmtMoney(r.calc.nettoC)}`));
    return card;
  }

  function resultCard() {
    const r = S.result; const files = r.files;
    return h('div', { class: 'card done' }, h('h2', {}, 'Dokumente erstellt'),
      h('p', { class: 'muted small' }, 'Die Dateien liegen nur in diesem Gerät. „Speichern/Teilen“ öffnet das iPhone-Menü (z. B. „In Dateien sichern“ oder Google Drive).'),
      files.map((f) => h('div', { class: 'file' }, h('span', {}, f.name),
        h('div', { class: 'row' }, h('button', { class: 'btn sec small', onclick: () => openBlob(f) }, 'Ansehen'), h('button', { class: 'btn small', onclick: () => shareFiles([f]) }, 'Speichern/Teilen')))),
      h('button', { class: 'linkbtn', onclick: () => shareFiles(files) }, 'Alle Dateien speichern/teilen'),
      googleBlock(r));
  }

  /* ---------- Google: Ablage im Drive und Gmail-Entwürfe (über das eigene Google-Script) ---------- */
  const isTest = () => S.data.persons.length > 0 && S.data.persons.every((p) => p.id.startsWith('demo'));
  async function scriptPost(body) {
    const key = (S.data.settings.abrufKey || '').trim();
    if (!key) throw new Error('Bitte zuerst unter „Einstellungen“ den Abruf-Schlüssel eintragen.');
    let resp;
    try {
      // Ohne eigenen Content-Type (text/plain), damit der Browser keine Vorabfrage schickt.
      resp = await fetch(ABRUF_URL, { method: 'POST', redirect: 'follow', body: JSON.stringify(Object.assign({ k: key, test: isTest() }, body)) });
    } catch (e) { throw new Error('Keine Verbindung zu Google. Bitte Internet prüfen und nochmals versuchen.'); }
    let r; try { r = await resp.json(); } catch (e) { throw new Error('Unerwartete Antwort von Google (ist das Script neu bereitgestellt?).'); }
    if (!r || !r.ok) throw new Error((r && r.error) || 'Unbekannter Fehler.');
    return r;
  }
  const blobB64 = async (blob) => b64(new Uint8Array(await blob.arrayBuffer()));

  async function driveAblegen() {
    const r = S.result; const d = S.data;
    const persons = d.persons.filter((p) => r.files.some((f) => f.pid === p.id));
    const steps = [{ label: `Google Tabelle „Jahresübersicht Löhne Assistenz ${r.year}“` }, { label: 'Jahresübersicht (PDF)' }].concat(persons.map((p) => ({ label: r.files.some((f) => f.pid === p.id && /Stundenübersicht/.test(f.name)) ? `${p.kurzname}: Lohnabrechnung und Stundenübersicht` : `${p.kurzname}: Lohnabrechnung (nicht gearbeitet)`, pid: p.id })));
    S.ablage = { running: true, steps, done: false }; render();
    const run = async (st, fn) => { st.state = 'run'; render(); try { const res = await fn(); st.state = 'ok'; st.msg = res || ''; } catch (e) { st.state = 'err'; st.msg = e.message; } render(); return st.state === 'ok'; };
    // 1) Tabelle zuerst: Die Sicherung im Script verhindert, dass ältere Monate verloren gehen.
    const ys = C.yearSheet(d.months, d.persons, r.year);
    const okSheet = await run(steps[0], async () => { const x = await scriptPost({ action: 'jahr_schreiben', year: r.year, header: ys.header, rows: ys.rows }); return x.neu ? 'neu angelegt' : 'aktualisiert'; });
    if (!okSheet) { steps.slice(1).forEach((s) => { s.state = 'skip'; s.msg = 'nicht ausgeführt'; }); S.ablage.running = false; render(); return; }
    const jf = r.files.find((f) => f.pid === null);
    await run(steps[1], async () => {
      // Jahres-PDF jetzt neu erstellen: Seit «Dokumente erstellen» können Monate übernommen worden sein.
      jf.blob = new Blob([await P.jahresuebersicht(window.PDFLib, { employer: d.employer, persons: d.persons, year: r.year, months: d.months })], { type: 'application/pdf' }); const x = await scriptPost({ action: 'ablegen', ordner: '', files: [{ name: jf.name, b64: await blobB64(jf.blob) }] }); return x.files[0].ersetzt ? 'alte Version im Papierkorb' : 'neu'; });
    for (const st of steps.slice(2)) {
      const p = d.persons.find((x) => x.id === st.pid);
      await run(st, async () => {
        const fl = []; for (const f of r.files.filter((x) => x.pid === p.id)) fl.push({ name: f.name, b64: await blobB64(f.blob) });
        const x = await scriptPost({ action: 'ablegen', ordner: p.kurzname, files: fl });
        const rep = x.files.reduce((a, f) => a + f.ersetzt, 0); return `Ordner „${x.ordner}“` + (rep ? `, ${rep} alte Version(en) im Papierkorb` : '');
      });
    }
    S.ablage.running = false; S.ablage.done = steps.every((s) => s.state === 'ok'); render();
  }

  function mailDraft(p, key, ohneStunden) {
    const { y, m } = keyYM(key); const d = S.data;
    const satz = ohneStunden ? `Hier ist deine Lohnabrechnung vom ${C.MONATE[m - 1]}.` : `Hier ist deine Lohnabrechnung vom ${C.MONATE[m - 1]} mit der Stundenübersicht.`;
    return {
      pid: p.id, to: p.email || '', cc: d.employer.email || '',
      subject: `Lohnabrechnung ${C.monthLabel(y, m)} / ${p.kurzname}`,
      body: `${p.anrede === 'Herr' ? 'Lieber' : 'Liebe'} ${p.vorname}\n\n${satz}\n\nVielen Dank für deine Unterstützung! ❤️\n\nLiebe Grüsse\nRoger`,
    };
  }
  async function entwuerfeErstellen() {
    const r = S.result; const list = S.entw.list;
    S.entw.running = true; render();
    for (const e of list) {
      e.state = 'run'; render();
      try {
        const fl = []; for (const f of r.files.filter((x) => x.pid === e.pid)) fl.push({ name: f.name, b64: await blobB64(f.blob) });
        const x = await scriptPost({ action: 'entwurf', to: e.to, cc: e.cc, subject: e.subject, body: e.body, files: fl });
        e.state = 'ok'; e.msg = x.ersetzt ? 'Entwurf ersetzt' : 'Entwurf erstellt'; e.draftId = x.id; e.sendState = null; e.sendMsg = '';
      } catch (err) { e.state = 'err'; e.msg = err.message; }
      render();
    }
    S.entw.running = false; S.entw.done = list.every((e) => e.state === 'ok'); S.entw.sent = false; render();
  }

  function entwListe() {
    const r = S.result; const d = S.data;
    return d.persons.filter((p) => r.files.some((f) => f.pid === p.id)).map((p) => mailDraft(p, r.key, !r.files.some((f) => f.pid === p.id && /Stundenübersicht/.test(f.name))));
  }
  function entwProbs(list) {
    const d = S.data; const probs = [];
    list.forEach((e) => { const p = d.persons.find((x) => x.id === e.pid); if (!e.to) probs.push(`${p.kurzname}: keine E-Mail-Adresse in den Einstellungen.`); });
    if (!d.employer.email) probs.push('Arbeitgeber: keine E-Mail-Adresse für CC in den Einstellungen.');
    return probs;
  }
  /* Ablage und Entwürfe in einem Zug. Entwürfe entstehen nur, wenn die Ablage vollständig geklappt hat. Gesendet wird hier nie. */
  async function ablegenUndEntwuerfe() {
    // Immer aus den aktuellen Einstellungen neu zusammenstellen (Adressen könnten geändert worden sein).
    S.entw = { list: entwListe() };
    if (entwProbs(S.entw.list).length) { S.kombi = { err: 'Nichts ausgeführt: Bitte zuerst die fehlenden Angaben unten bei „2. Gmail-Entwürfe“ ergänzen.' }; render(); return; }
    S.kombi = { running: true }; render();
    await driveAblegen();
    if (!S.ablage.done) { S.kombi = { err: 'Die Ablage ist nicht vollständig. Es wurden keine Entwürfe erstellt. Details unten bei „1. Im Drive ablegen“.' }; render(); return; }
    await entwuerfeErstellen();
    S.kombi = S.entw.done ? { ok: 'Abgelegt und Entwürfe erstellt. Bitte die Entwürfe unten prüfen, dann bei „3. Senden“ senden.' } : { err: 'Im Drive abgelegt, aber nicht alle Entwürfe erstellt. Details unten bei „2. Gmail-Entwürfe“.' };
    render();
  }

  /* Senden der geprüften Entwürfe: nur nach Rückfrage, jeder Entwurf höchstens einmal. */
  async function entwuerfeSenden() {
    const list = S.entw.list.filter((e) => e.state === 'ok' && e.draftId && e.sendState !== 'ok');
    if (!list.length) return;
    const zeilen = list.map((e) => `• ${e.to}${e.cc ? ' (CC ' + e.cc + ')' : ''}`).join('\n');
    if (!confirm(`${list.length} E-Mail${list.length === 1 ? '' : 's'} jetzt wirklich senden?\n\n${zeilen}\n\nDas kann nicht rückgängig gemacht werden.`)) return;
    S.entw.sending = true; render();
    for (const e of list) {
      e.sendState = 'run'; render();
      try {
        const x = await scriptPost({ action: 'senden', draftId: e.draftId });
        e.sendState = 'ok'; e.sendMsg = x.simuliert ? 'Test: Senden geprüft, nicht wirklich gesendet (@example.com)' : 'gesendet';
      } catch (err) { e.sendState = 'err'; e.sendMsg = err.message; }
      render();
    }
    S.entw.sending = false; S.entw.sent = S.entw.list.every((e) => e.sendState === 'ok'); render();
  }

  const MARK = { ok: '✓', err: '✗', run: '…', skip: '–' };
  const stepLine = (label, st) => h('div', { class: 'step ' + (st.state || '') }, h('span', { class: 'mk' }, MARK[st.state] || '○'), h('span', {}, label, st.msg ? h('div', { class: 'small ' + (st.state === 'err' ? 'err' : 'muted') }, st.msg) : null));

  function googleBlock(r) {
    const d = S.data; const out = h('div', { class: 'gblock' }, h('h2', {}, 'Google Drive und Gmail'));
    if (isTest()) out.append(h('p', { class: 'tag' }, 'Testmodus (erfundene Daten): nur Ordner „_TEST Beispieldaten“, nur Adressen @example.com'));
    // Ablegen und Entwürfe in einem Zug
    const busy = !!((S.ablage && S.ablage.running) || (S.entw && (S.entw.running || S.entw.sending)) || (S.kombi && S.kombi.running));
    const gesendet = !!(S.entw && S.entw.list.some((e) => e.sendState === 'ok'));
    const beidesFertig = !!(S.ablage && S.ablage.done && S.entw && S.entw.done);
    if (S.kombi && S.kombi.ok) out.append(h('p', { class: 'ok' }, S.kombi.ok));
    if (S.kombi && S.kombi.err) out.append(h('div', { class: 'blockers' }, h('p', {}, S.kombi.err)));
    if (!gesendet && !beidesFertig) {
      out.append(h('p', { class: 'muted small' }, 'Legt alles im Drive ab und erstellt danach die Gmail-Entwürfe. Gesendet wird noch nicht.'),
        h('button', { class: 'btn', disabled: busy, onclick: ablegenUndEntwuerfe }, S.kombi && S.kombi.running ? 'Lege ab und erstelle Entwürfe …' : 'Ablegen und Entwürfe erstellen'));
      out.append(h('p', { class: 'muted small mt' }, 'Oder einzeln:'));
    }
    // Drive
    out.append(h('h3', {}, '1. Im Drive ablegen'));
    if (!S.ablage) out.append(h('p', { class: 'muted small' }, 'Legt die PDFs in den Ordnern der Personen ab, aktualisiert die Google Tabelle „Jahresübersicht“ und ersetzt das PDF der Jahresübersicht. Alte Versionen kommen in den Papierkorb.'));
    else S.ablage.steps.forEach((s) => out.append(stepLine(s.label, s)));
    if (S.ablage && S.ablage.done) out.append(h('p', { class: 'ok' }, 'Alles im Drive abgelegt.'));
    if (S.ablage && !S.ablage.running && S.ablage.steps[0].state === 'err' && /Jahresdaten übernehmen/.test(S.ablage.steps[0].msg || '')) {
      out.append(h('button', { class: 'btn sec', onclick: () => { S.tab = 'year'; render(); window.scrollTo(0, 0); } }, 'Zu „Jahr“: Jahresdaten übernehmen'));
    }
    out.append(h('button', { class: 'btn sec', disabled: busy, onclick: driveAblegen },
      S.ablage && S.ablage.running ? 'Lege ab …' : (S.ablage ? 'Nochmals im Drive ablegen' : 'Im Drive ablegen')));
    // Gmail
    out.append(h('h3', { class: 'mt' }, '2. Gmail-Entwürfe'));
    if (!S.entw) {
      out.append(h('p', { class: 'muted small' }, 'Pro Person ein Entwurf mit den PDFs, CC an den Arbeitgeber. Gesendet wird erst in Schritt 3, nach deiner Kontrolle und einer Rückfrage.'),
        h('button', { class: 'btn sec', disabled: busy, onclick: () => { S.entw = { list: entwListe() }; render(); } }, 'Entwürfe ansehen'));
      return out;
    }
    const probs = entwProbs(S.entw.list);
    S.entw.list.forEach((e) => {
      out.append(h('div', { class: 'mail' },
        h('div', { class: 'small' }, h('b', {}, 'An: '), e.to || '–'), h('div', { class: 'small' }, h('b', {}, 'CC: '), e.cc || '–'),
        h('div', { class: 'small' }, h('b', {}, 'Betreff: '), (isTest() ? '[TEST] ' : '') + e.subject),
        h('pre', {}, e.body),
        h('div', { class: 'small muted' }, 'Anhänge: ' + r.files.filter((f) => f.pid === e.pid).map((f) => f.name).join(', ')),
        e.state ? stepLine('Gmail', e) : null,
        e.sendState ? stepLine('Senden', { state: e.sendState, msg: e.sendMsg }) : null));
    });
    if (probs.length) out.append(h('div', { class: 'blockers' }, probs.map((x) => h('p', {}, x))));
    const anySent = S.entw.list.some((e) => e.sendState === 'ok');
    if (S.entw.done && !anySent) out.append(h('p', { class: 'ok' }, 'Die Entwürfe liegen in Gmail. Du kannst sie dort ansehen oder hier senden.'));
    if (!anySent) out.append(h('button', { class: 'btn sec', disabled: !!(busy || probs.length), onclick: entwuerfeErstellen },
      S.entw.running ? 'Erstelle Entwürfe …' : (S.entw.done ? 'Entwürfe nochmals erstellen (ersetzt sie)' : 'Entwürfe in Gmail erstellen')));
    // 3. Senden
    if (S.entw.done) {
      out.append(h('h3', { class: 'mt' }, '3. Senden'));
      const offen = S.entw.list.filter((e) => e.sendState !== 'ok').length;
      if (S.entw.sent) out.append(h('p', { class: 'ok' }, isTest() ? 'Test abgeschlossen: Senden geprüft.' : 'Alle Lohnabrechnungen sind gesendet.'));
      else {
        out.append(h('p', { class: 'muted small' }, 'Sendet die geprüften Entwürfe oben. Vorher kommt eine Rückfrage mit allen Empfängern. Gesendet wird nur an Adressen, die im Script erlaubt sind.'));
        out.append(h('button', { class: 'btn', disabled: !!S.entw.sending, onclick: entwuerfeSenden }, S.entw.sending ? 'Sende …' : `Jetzt senden (${offen})`));
      }
    }
    return out;
  }

  /* ---------- Jahresdaten einmalig aus der bestehenden Google Tabelle übernehmen ---------- */
  async function jahrLesen(year) {
    S.imp = { year, loading: true }; render();
    try {
      const x = await scriptPost({ action: 'jahr_lesen', year });
      if (!x.found) { S.imp = { year, errors: [`Im Drive gibt es keine Tabelle „${x.name}“. Es gibt nichts zu übernehmen.`] }; render(); return; }
      const res = C.parseYearSheet(x.values, S.data.persons);
      const add = []; const same = []; const diff = [];
      Object.keys(res.months).map(Number).sort((a, b) => a - b).forEach((m) => {
        const k = C.monthKey(year, m); const have = S.data.months[k]; const rec = res.months[m];
        if (!have) { add.push(m); return; }
        const dif = S.data.persons.filter((p) => { const a = have.persons && have.persons[p.id]; const b = rec.persons[p.id]; return (a ? a.nettoC : 0) !== (b ? b.nettoC : 0); });
        (dif.length ? diff : same).push(m);
      });
      S.imp = Object.assign({ year, name: x.name, add, same, diff }, res);
    } catch (e) { S.imp = { year, errors: [e.message] }; }
    render();
  }
  function jahrUebernehmen() {
    const imp = S.imp; const now = new Date().toISOString();
    imp.add.forEach((m) => { const rec = imp.months[m]; S.data.months[C.monthKey(imp.year, m)] = { created: now, imported: true, hcTotal: rec.hcTotal, persons: rec.persons }; });
    const n = imp.add.length; S.imp = { year: imp.year, doneMsg: `${n} Monat${n === 1 ? '' : 'e'} übernommen. Bitte unter „Einstellungen“ eine neue Sicherung speichern.` };
    save().catch(() => {}); render();
  }
  function importBlock(year) {
    const imp = S.imp && S.imp.year === year ? S.imp : null; const out = h('div', { class: 'card' }, h('h2', {}, 'Jahresdaten aus Google übernehmen'));
    if (!imp) {
      out.append(h('p', { class: 'muted small' }, `Übernimmt einmalig die Monate aus der bestehenden Google Tabelle „Jahresübersicht Löhne Assistenz ${year}“ (z. B. Monate, die noch im Chat abgerechnet wurden). Monate, die schon in der App sind, bleiben unverändert.`),
        h('button', { class: 'btn sec', onclick: () => jahrLesen(year) }, 'Tabelle lesen und prüfen'));
      return out;
    }
    if (imp.loading) { out.append(h('p', { class: 'muted' }, 'Lese Tabelle …')); return out; }
    if (imp.doneMsg) { out.append(h('p', { class: 'ok' }, imp.doneMsg)); return out; }
    if (imp.errors && imp.errors.length) {
      out.append(h('div', { class: 'blockers' }, h('strong', {}, 'Nicht übernommen:'), imp.errors.map((e) => h('p', {}, e))), (imp.warnings || []).map((w) => h('p', { class: 'warn small' }, w)),
        h('button', { class: 'btn sec', onclick: () => jahrLesen(year) }, 'Nochmals lesen'));
      return out;
    }
    out.append(h('p', { class: 'small muted' }, 'Zuordnung der Spalten: ' + imp.cols.map((c) => `«${c.header}» → ${c.p.kurzname} ${c.k === 'bruttoC' ? 'Brutto' : 'Netto'}`).join(' · ')));
    imp.warnings.forEach((w) => out.append(h('p', { class: 'warn small' }, w)));
    const cols = C.yearColumns(S.data.persons);
    if (imp.add.length) {
      out.append(h('p', {}, h('strong', {}, 'Neu in die App: '), imp.add.map((m) => C.MONATE[m - 1]).join(', ')));
      out.append(h('div', { class: 'scroll' }, h('table', { class: 'tbl' },
        h('thead', {}, h('tr', {}, h('th', {}, 'Monat'), cols.map((c) => h('th', { class: 'r' }, c.label)), h('th', { class: 'r' }, 'Stunden'))),
        h('tbody', {}, imp.add.map((m) => { const rec = imp.months[m]; return h('tr', {}, h('td', {}, C.MONATE[m - 1]), cols.map((c) => h('td', { class: 'r' }, rec.persons[c.p.id] ? C.fmtMoney(rec.persons[c.p.id][c.k]) : '')), h('td', { class: 'r' }, rec.hcTotal != null ? C.fmtHc(rec.hcTotal) : '?')); })))));
    } else out.append(h('p', { class: 'ok' }, 'Alle Monate der Tabelle sind schon in der App.'));
    if (imp.same.length) out.append(h('p', { class: 'muted small' }, 'Schon in der App (gleich): ' + imp.same.map((m) => C.MONATE[m - 1]).join(', ')));
    if (imp.diff.length) out.append(h('p', { class: 'warn small' }, 'Schon in der App, aber andere Beträge als in der Tabelle (App-Werte bleiben): ' + imp.diff.map((m) => C.MONATE[m - 1]).join(', ')));
    out.append(h('div', { class: 'row' },
      h('button', { class: 'btn', disabled: !imp.add.length, onclick: jahrUebernehmen }, 'Übernehmen'),
      h('button', { class: 'btn sec', onclick: () => { S.imp = null; render(); } }, 'Abbrechen')));
    return out;
  }

  /* ---------- Ansicht: Jahresübersicht ---------- */
  function viewYear() {
    const d = S.data; const yNow = new Date().getFullYear(); const year = S.year || yNow;
    const ySel = h('select', { onchange: (e) => { S.year = Number(e.target.value); render(); } }, [yNow - 2, yNow - 1, yNow, yNow + 1].map((yy) => h('option', { value: yy, selected: yy === year }, yy)));
    const yt = C.yearTotals(d.months, d.persons, year);
    const cols = C.yearColumns(d.persons).map((c) => [c.p, c.k, c.k === 'bruttoC' ? 'Brutto' : 'Netto']);
    const tbl = h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, h('th', {}, 'Monat'), cols.map((c) => h('th', { class: 'r' }, `${c[0].vorname} ${c[2]}`)), h('th', { class: 'r' }, 'Stunden'))),
      h('tbody', {}, yt.rows.map((r) => h('tr', {}, h('td', {}, C.MONATE[r.m - 1]), cols.map((c) => h('td', { class: 'r' }, !r.empty && r.per[c[0].id] ? C.fmtMoney(r.per[c[0].id][c[1]]) : '')), h('td', { class: 'r' }, r.empty ? '' : C.fmtHc(r.hc))))),
      h('tfoot', {}, h('tr', {}, h('td', {}, 'Total'), cols.map((c) => h('td', { class: 'r' }, C.fmtMoney(yt.tot.perPerson[c[0].id][c[1]]))), h('td', { class: 'r' }, C.fmtHc(yt.tot.hc)))));
    return h('div', {}, h('div', { class: 'card' }, h('h2', {}, 'Jahresübersicht'), h('div', { class: 'row' }, ySel), h('div', { class: 'scroll' }, tbl), h('p', { class: 'muted small' }, 'Für alle Spalten die Tabelle seitlich wischen.'),
      h('p', { class: 'muted small' }, `Abgerechnete Monate: ${yt.tot.count} von 12 · Ausbezahlt netto: CHF ${C.fmtMoney(yt.tot.netto)}`),
      h('button', { class: 'btn', onclick: async () => {
        const bytes = await P.jahresuebersicht(window.PDFLib, { employer: d.employer, persons: d.persons, year, months: d.months });
        S.lastYearFile = { name: `Jahresübersicht Löhne Assistenz ${year}.pdf`, year, blob: new Blob([bytes], { type: 'application/pdf' }) }; render();
      } }, 'PDF erstellen'),
      S.lastYearFile && S.lastYearFile.year === year ? h('div', { class: 'row' }, h('button', { class: 'btn sec', onclick: () => openBlob(S.lastYearFile) }, 'Ansehen'), h('button', { class: 'btn sec', onclick: () => shareFiles([S.lastYearFile]) }, 'Speichern/Teilen')) : null,
      h('p', { class: 'muted small' }, 'Wenn ein Monat falsch erfasst wurde, in „Abrechnung“ denselben Monat neu erstellen: Der Eintrag wird ersetzt.')),
      importBlock(year));
  }

  /* ---------- Ansicht: Einstellungen ---------- */
  function field(label, value, onset, opts) {
    return h('label', { class: 'f' }, h('span', {}, label), h('input', Object.assign({ type: 'text', value: value == null ? '' : value, onchange: (e) => { onset(e.target.value.trim()); saveSoon(); } }, opts || {})));
  }
  function viewSettings() {
    const d = S.data; const out = h('div', {});
    if (S.msg) { out.append(h('div', { class: 'blockers' }, h('p', {}, S.msg))); S.msg = null; }
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Arbeitgeber (Briefkopf)'),
      field('Name', d.employer.name, (v) => { d.employer.name = v; }), field('Strasse', d.employer.strasse, (v) => { d.employer.strasse = v; }),
      field('PLZ Ort', d.employer.ort, (v) => { d.employer.ort = v; }), field('E-Mail (für CC)', d.employer.email, (v) => { d.employer.email = v; })));
    const num = (k, label) => field(label, d.settings[k], (v) => { const n = Number(String(v).replace(',', '.')); if (isFinite(n) && n >= 0) d.settings[k] = n; }, { inputmode: 'decimal' });
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Sätze'), num('stundenlohn', 'Stundenlohn (CHF)'), num('ferien', 'Ferienentschädigung (%)'), num('ahv', 'AHV/IV/EO (%)'), num('freibetrag', 'Freibetrag pro Monat ohne AHV-Abzug (CHF)'),
      h('p', { class: 'muted small' }, 'ALV, BVG, NBU, Krankentaggeld und Quellensteuer sind fest auf 0.')));
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Abruf Stundenerfassung'),
      field('Abruf-Schlüssel', d.settings.abrufKey || '', (v) => { d.settings.abrufKey = v; }, { type: 'password', autocomplete: 'off', autocapitalize: 'off', spellcheck: 'false' }),
      h('p', { class: 'muted small' }, 'Damit holt „Stunden holen“ die Stunden direkt aus der Tabelle. Der Schlüssel bleibt verschlüsselt im Gerät und in der Sicherung.')));
    // Personen
    const pc = h('div', { class: 'card' }, h('h2', {}, 'Assistenzpersonen'));
    d.persons.forEach((p) => {
      if (S.editing === p.id) { pc.append(personForm(p)); return; }
      pc.append(h('div', { class: 'file' }, h('span', {}, h('strong', {}, p.kurzname), h('br'), h('span', { class: 'muted small' }, `${p.ahvAbzug ? 'mit' : 'ohne'} AHV-Abzug${p.pauschal ? ' · Stunden nach Total' : ''}`)),
        h('button', { class: 'btn sec small', onclick: () => { S.editing = p.id; render(); } }, 'Bearbeiten')));
    });
    pc.append(h('button', { class: 'btn sec', onclick: () => { const p = { id: uid(), anrede: 'Frau', name: '', kurzname: '', vorname: '', strasse: '', plzOrt: '', email: '', ahvNr: '', ahvAbzug: true, pauschal: false, clockifyKey: '', zahlung: '' }; d.persons.push(p); S.editing = p.id; render(); } }, '+ Person hinzufügen'));
    out.append(pc);
    // Sicherung
    const fileIn = h('input', { type: 'file', accept: '.json,application/json', class: 'hidden', onchange: async (e) => {
      const f = e.target.files[0]; if (!f) return;
      const pin = prompt('PIN der Sicherung eingeben:'); if (!pin) return;
      try { const b = JSON.parse(await f.text()); const key = await deriveKey(pin, unb64(b.salt), b.iter); const data = await decryptWith(key, b);
        if (!confirm('Alle aktuellen Daten durch die Sicherung ersetzen?')) return;
        S.key = key; S.salt = unb64(b.salt); S.data = data; localStorage.setItem(VAULT_KEY, JSON.stringify(b)); S.tab = 'abr'; render();
      } catch (err) { alert('PIN falsch oder Datei beschädigt.'); }
    } });
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Sicherung und PIN'),
      h('p', { class: 'muted small' }, 'Die Sicherungsdatei ist mit deiner PIN verschlüsselt. Lege sie z. B. im Google-Drive-Ordner ab.'),
      h('button', { class: 'btn', onclick: async () => {
        await save(); const text = localStorage.getItem(VAULT_KEY); const name = `Sicherung Abrechnung ${new Date().toISOString().slice(0, 10)}.json`;
        const file = new File([text], name, { type: 'application/json' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); return; } catch (e) { if (e.name === 'AbortError') return; } }
        const a = h('a', { href: URL.createObjectURL(file), download: name }); document.body.append(a); a.click(); a.remove();
      } }, 'Sicherung speichern'),
      h('button', { class: 'btn sec', onclick: () => fileIn.click() }, 'Sicherung laden'), fileIn,
      h('button', { class: 'btn sec', onclick: async () => {
        const old = prompt('Aktuelle PIN:'); if (old == null) return;
        try { const v = JSON.parse(localStorage.getItem(VAULT_KEY)); await decryptWith(await deriveKey(old, unb64(v.salt), v.iter), v); } catch (e) { alert('PIN falsch.'); return; }
        const n1 = prompt('Neue PIN (6–8 Ziffern):'); if (n1 == null) return; if (!/^\d{6,8}$/.test(n1)) { alert('Die PIN muss aus 6 bis 8 Ziffern bestehen.'); return; }
        if (prompt('Neue PIN wiederholen:') !== n1) { alert('Die PIN stimmen nicht überein.'); return; }
        S.salt = crypto.getRandomValues(new Uint8Array(16)); S.key = await deriveKey(n1, S.salt, ITER); await save(); alert('PIN geändert. Bitte danach eine neue Sicherung speichern.');
      } }, 'PIN ändern'),
      h('button', { class: 'btn sec', onclick: lock }, 'Jetzt sperren'),
      !d.persons.some((p) => p.id.startsWith('demo')) && !d.persons.length ? h('button', { class: 'btn sec', onclick: () => { loadDemo(d); saveSoon(); render(); } }, 'Erfundene Beispieldaten laden') : null,
      h('button', { class: 'btn danger', onclick: () => { if (confirm('Wirklich ALLE Daten in diesem Gerät löschen? Das geht nur mit einer Sicherungsdatei rückgängig.') && confirm('Letzte Rückfrage: Alles löschen?')) { localStorage.removeItem(VAULT_KEY); lock(); } } }, 'Alle Daten löschen')));
    return out;
  }
  function personForm(p) {
    const d = S.data;
    const chk = (label, k) => h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: p[k], onchange: (e) => { p[k] = e.target.checked; saveSoon(); } }), label);
    return h('div', { class: 'pform' },
      h('label', { class: 'f' }, h('span', {}, 'Anrede'), h('select', { onchange: (e) => { p.anrede = e.target.value; saveSoon(); } }, ['Frau', 'Herr'].map((a) => h('option', { selected: p.anrede === a }, a)))),
      field('Name auf Dokumenten (mit Zweitnamen)', p.name, (v) => { p.name = v; }), field('Kurzname für Dateien und Ordner', p.kurzname, (v) => { p.kurzname = v; }),
      field('Vorname (Anrede in der E-Mail)', p.vorname, (v) => { p.vorname = v; }), field('Strasse', p.strasse, (v) => { p.strasse = v; }), field('PLZ Ort', p.plzOrt, (v) => { p.plzOrt = v; }),
      field('E-Mail', p.email, (v) => { p.email = v; }, { inputmode: 'email' }), field('AHV-Nr.', p.ahvNr, (v) => { p.ahvNr = v; }),
      field('Name oder E-Mail in Clockify (falls anders)', p.clockifyKey, (v) => { p.clockifyKey = v; }),
      field('Zahlungsangabe unter dem Nettolohn (optional, z. B. IBAN)', p.zahlung, (v) => { p.zahlung = v; }),
      chk('AHV-Abzug', 'ahvAbzug'), chk('Keine Erfassung: Stunden nach Total auf Sonntage/Donnerstage verteilen', 'pauschal'),
      h('div', { class: 'row' }, h('button', { class: 'btn', onclick: () => { S.editing = null; render(); } }, 'Fertig'),
        h('button', { class: 'btn danger', onclick: () => { if (confirm(`${p.kurzname || 'Person'} löschen?`)) { d.persons = d.persons.filter((x) => x.id !== p.id); S.editing = null; saveSoon(); render(); } } }, 'Löschen')));
  }

  /* ---------- Rahmen ---------- */
  function render() {
    root.replaceChildren();
    if (!S.key) { root.append(localStorage.getItem(VAULT_KEY) ? viewLock() : viewOnboarding()); return; }
    const tabs = [['abr', 'Abrechnung'], ['year', 'Jahr'], ['set', 'Einstellungen']];
    const main = h('main', {}, S.tab === 'abr' ? viewAbr() : (S.tab === 'year' ? viewYear() : viewSettings()));
    root.append(h('header', {}, h('h1', {}, tabs.find((t) => t[0] === S.tab)[1])), main,
      h('nav', {}, tabs.map((t) => h('button', { class: S.tab === t[0] ? 'on' : '', onclick: () => { S.tab = t[0]; render(); window.scrollTo(0, 0); } }, t[1]))));
  }
  render();
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
