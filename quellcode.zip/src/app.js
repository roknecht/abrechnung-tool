/* Oberfläche der App. Alle Daten bleiben im Gerät (verschlüsselt mit der PIN). */
(function () {
  'use strict';
  const C = window.Core; const P = window.Pdf;
  const VAULT_KEY = 'abrechnung_vault_v1';
  const ITER = 250000;
  const enc = new TextEncoder(); const dec = new TextDecoder();

  /* ---------- kleine Helfer ---------- */
  function h(tag, props) {
    const el = document.createElement(tag);
    for (const [k, v] of Object.entries(props || {})) {
      if (k === 'class') el.className = v;
      else if (k === 'value') el.value = v;
      else if (k === 'checked') el.checked = !!v;
      else if (k.startsWith('on')) el.addEventListener(k.slice(2), v);
      else if (v === true) el.setAttribute(k, '');
      else if (v !== false && v != null) el.setAttribute(k, v);
    }
    for (const c of [].slice.call(arguments, 2).flat(Infinity)) { if (c == null || c === false) continue; el.append(c.nodeType ? c : document.createTextNode(String(c))); }
    return el;
  }
  const b64 = (u8) => { let s = ''; for (let i = 0; i < u8.length; i += 8192) s += String.fromCharCode.apply(null, u8.subarray(i, i + 8192)); return btoa(s); };
  const unb64 = (s) => Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
  const uid = () => 'p' + Math.random().toString(36).slice(2, 9);

  /* ---------- Verschlüsselung ---------- */
  async function deriveKey(pin, salt, iter) {
    const km = await crypto.subtle.importKey('raw', enc.encode(pin), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function encryptWith(key, obj) {
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(obj))));
    return { iv: b64(iv), ct: b64(ct) };
  }
  async function decryptWith(key, blob) {
    const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(blob.iv) }, key, unb64(blob.ct));
    return JSON.parse(dec.decode(pt));
  }

  /* ---------- Zustand ---------- */
  const S = { key: null, salt: null, data: null, tab: 'abr', result: null, editing: null, busy: false, msg: null };
  const root = document.getElementById('app');

  const emptyData = () => ({
    v: 1, settings: { stundenlohn: 35, ferien: 8.33, ahv: 5.3, freibetrag: 1400 },
    employer: { name: '', strasse: '', ort: '', email: '' }, persons: [], months: {}, draft: null,
  });
  async function save() {
    const blob = await encryptWith(S.key, S.data);
    localStorage.setItem(VAULT_KEY, JSON.stringify({ v: 1, salt: b64(S.salt), iter: ITER, iv: blob.iv, ct: blob.ct }));
  }
  let saveTimer = null;
  function saveSoon() { clearTimeout(saveTimer); saveTimer = setTimeout(() => save().catch(() => {}), 400); }

  /* ---------- Sperre / Start ---------- */
  function lock() { S.key = null; S.data = null; S.result = null; S.editing = null; render(); }
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { S.hiddenAt = Date.now(); } else if (S.key && S.hiddenAt && Date.now() - S.hiddenAt > 120000) lock();
  });

  function viewOnboarding() {
    const pin1 = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'new-password', maxlength: 8, placeholder: 'PIN (6–8 Ziffern)' });
    const pin2 = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'new-password', maxlength: 8, placeholder: 'PIN wiederholen' });
    const err = h('p', { class: 'err' });
    const fileIn = h('input', { type: 'file', accept: '.json,application/json', class: 'hidden', onchange: async (ev) => {
      const f = ev.target.files[0]; if (!f) return;
      try { S.pendingBackup = JSON.parse(await f.text()); if (!S.pendingBackup.ct) throw new Error('x'); err.textContent = 'Sicherung gewählt. PIN der Sicherung eingeben und „Sicherung laden“ tippen.'; err.className = 'ok'; loadBtn.disabled = false; } catch (e) { err.className = 'err'; err.textContent = 'Das ist keine gültige Sicherungsdatei.'; }
    } });
    const loadBtn = h('button', { class: 'btn sec', disabled: true, onclick: async () => {
      err.className = 'err';
      if (!/^\d{6,8}$/.test(pin1.value)) { err.textContent = 'PIN der Sicherung eingeben (6–8 Ziffern).'; return; }
      try {
        const b = S.pendingBackup; const salt = unb64(b.salt); const key = await deriveKey(pin1.value, salt, b.iter || ITER);
        const data = await decryptWith(key, b);
        S.key = key; S.salt = salt; S.data = data; localStorage.setItem(VAULT_KEY, JSON.stringify(b)); S.tab = 'abr'; render();
      } catch (e) { err.textContent = 'PIN falsch oder Datei beschädigt.'; }
    } }, 'Sicherung laden');
    const start = async (demo) => {
      err.className = 'err';
      if (!/^\d{6,8}$/.test(pin1.value)) { err.textContent = 'Die PIN muss aus 6 bis 8 Ziffern bestehen.'; return; }
      if (pin1.value !== pin2.value) { err.textContent = 'Die beiden PIN stimmen nicht überein.'; return; }
      S.salt = crypto.getRandomValues(new Uint8Array(16)); S.key = await deriveKey(pin1.value, S.salt, ITER);
      S.data = emptyData(); if (demo) loadDemo(S.data); await save(); S.tab = demo ? 'abr' : 'set'; render();
    };
    return h('div', { class: 'center' },
      h('h1', {}, 'Abrechnung'),
      h('p', { class: 'muted' }, 'Erster Start. Lege eine PIN fest. Alle Angaben bleiben verschlüsselt in diesem Gerät. Merke dir die PIN gut: Ohne PIN lassen sich die Daten nur mit einer Sicherungsdatei wiederherstellen.'),
      pin1, pin2, err,
      h('button', { class: 'btn', onclick: () => start(false) }, 'Leer starten'),
      h('button', { class: 'btn sec', onclick: () => start(true) }, 'Mit erfundenen Beispieldaten starten'),
      h('hr'), h('p', { class: 'muted' }, 'Oder eine bestehende Sicherung laden (PIN oben eingeben):'),
      h('button', { class: 'btn sec', onclick: () => fileIn.click() }, 'Sicherungsdatei wählen'), loadBtn, fileIn);
  }

  function viewLock() {
    const pin = h('input', { type: 'password', inputmode: 'numeric', autocomplete: 'current-password', maxlength: 8, placeholder: 'PIN' });
    const err = h('p', { class: 'err' });
    const go = async () => {
      err.textContent = '';
      try {
        const v = JSON.parse(localStorage.getItem(VAULT_KEY)); const salt = unb64(v.salt);
        const key = await deriveKey(pin.value, salt, v.iter); const data = await decryptWith(key, v);
        S.key = key; S.salt = salt; S.data = data; render();
      } catch (e) { err.textContent = 'PIN falsch.'; pin.value = ''; }
    };
    pin.addEventListener('keydown', (e) => { if (e.key === 'Enter') go(); });
    return h('div', { class: 'center' }, h('h1', {}, 'Abrechnung'), h('p', { class: 'muted' }, 'Gesperrt'), pin, err, h('button', { class: 'btn', onclick: go }, 'Entsperren'),
      h('p', { class: 'muted small' }, 'PIN vergessen? Dann nur mit einer Sicherungsdatei: Daten löschen und beim Start die Sicherung laden. ', h('a', { href: '#', onclick: (e) => { e.preventDefault(); if (confirm('Wirklich ALLE Daten in diesem Gerät löschen? Das geht nur mit einer Sicherungsdatei rückgängig.')) { localStorage.removeItem(VAULT_KEY); render(); } } }, 'Alle Daten löschen')));
  }

  /* ---------- Beispieldaten (erfunden) ---------- */
  function loadDemo(d) {
    d.employer = { name: 'Max Muster', strasse: 'Musterstrasse 1', ort: '8000 Zürich', email: 'max@example.com' };
    d.persons = [
      { id: 'demo1', anrede: 'Frau', name: 'Anna Beispiel', kurzname: 'Anna Beispiel', vorname: 'Anna', strasse: 'Beispielweg 2', plzOrt: '3000 Bern', email: 'anna@example.com', ahvNr: '756.0000.0000.02', ahvAbzug: true, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo2', anrede: 'Herr', name: 'Hans Probe', kurzname: 'Hans Probe', vorname: 'Hans', strasse: 'Probestrasse 3', plzOrt: '4000 Basel', email: 'hans@example.com', ahvNr: '756.0000.0000.03', ahvAbzug: false, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo3', anrede: 'Herr', name: 'Peter Test', kurzname: 'Peter Test', vorname: 'Peter', strasse: 'Testgasse 4', plzOrt: '5000 Aarau', email: 'peter@example.com', ahvNr: '756.0000.0000.04', ahvAbzug: false, pauschal: false, clockifyKey: '', zahlung: '' },
      { id: 'demo4', anrede: 'Frau', name: 'Maria Demo', kurzname: 'Maria Demo', vorname: 'Maria', strasse: 'Demoplatz 5', plzOrt: '6000 Luzern', email: 'maria@example.com', ahvNr: '756.0000.0000.05', ahvAbzug: true, pauschal: true, clockifyKey: '', zahlung: '' },
    ];
  }
  function demoCsv(y, m, persons) {
    const head = 'Project,Client,Description,Task,User,Group,Email,Tags,Billable,Start Date,Start Time,End Date,End Time,Duration (h),Duration (decimal),Billable Rate (CHF),Billable Amount (CHF)';
    const rows = [head]; const dm = (d) => `${C.pad(m)}/${C.pad(d)}/${y}`;
    const add = (p, d, st, en, dur, endDay) => rows.push(`,,,,${p.name},,${p.email},,No,${dm(d)},${st},${dm(endDay || d)},${en},${dur},${(Number(dur.split(':')[0]) + Number(dur.split(':')[1]) / 60).toFixed(2)},0,0`);
    const a = persons.find((p) => p.id === 'demo1'); const b = persons.find((p) => p.id === 'demo2');
    if (a) { [[2, '4:00'], [6, '5:00'], [11, '4:20'], [17, '5:00'], [24, '4:00']].forEach(([d, du]) => add(a, d, '08:00:00', '12:00:00', du)); add(a, 27, '22:00:00', '02:00:00', '4:00', 28); }
    if (b) { for (let d = 3; d <= 28; d += 2) add(b, d, '09:00:00', '13:00:00', d % 4 ? '3:30' : '2:45'); }
    rows.push(`,,,,Gast Beispiel,,gast@example.com,,No,${dm(5)},09:00:00,${dm(5)},10:00:00,1:00,1.00,0,0`);
    return rows.join('\n');
  }

  /* ---------- Entwurf der Monatsabrechnung ---------- */
  function prevMonth() { const t = new Date(); let y = t.getFullYear(); let m = t.getMonth(); if (m === 0) { m = 12; y--; } return { y, m }; }
  function ensureDraft() {
    const d = S.data;
    if (!d.draft) { const { y, m } = prevMonth(); d.draft = { key: C.monthKey(y, m), days: {}, csvHc: {}, skip: {}, excess: {}, pTotal: {}, info: null }; }
    return d.draft;
  }
  const keyYM = (k) => ({ y: Number(k.slice(0, 4)), m: Number(k.slice(5)) });
  const dayHc = (dr, id) => (dr.days[id] || []).reduce((a, q) => a + q.hc, 0);
  function resetDraft(key) { S.data.draft = { key, days: {}, csvHc: {}, skip: {}, excess: {}, pTotal: {}, info: null }; S.result = null; saveSoon(); }

  function applyCsv(text, filename) {
    const dr = ensureDraft(); const { y, m } = keyYM(dr.key); const d = S.data;
    const res = C.importClockify(text, y, m, d.persons.filter((p) => !p.pauschal));
    if (res.errors.length) { dr.info = { errors: res.errors, headers: res.headers || null, filename }; saveSoon(); return; }
    const keep = {}; d.persons.filter((p) => p.pauschal).forEach((p) => { keep[p.id] = dr.days[p.id] || []; });
    dr.days = keep; dr.csvHc = {}; dr.skip = {}; dr.excess = {};
    d.persons.filter((p) => !p.pauschal).forEach((p) => {
      const bp = res.byPerson[p.id];
      dr.days[p.id] = bp ? Object.keys(bp.days).sort().map((dt) => ({ date: dt, hc: bp.days[dt] })) : [];
      dr.csvHc[p.id] = bp ? Object.values(bp.days).reduce((a, v) => a + v, 0) : 0;
    });
    dr.info = { errors: [], warnings: res.warnings, unmatched: res.unmatched, outside: res.outside.length, rows: res.rows, filename };
    S.result = null; saveSoon();
  }

  /* ---------- Berechnung für die Kontrolle ---------- */
  function evaluate() {
    const d = S.data; const dr = ensureDraft(); const rows = []; const blockers = [];
    d.persons.forEach((p) => {
      const days = dr.days[p.id] || []; const hc = dayHc(dr, p.id); const skip = !!dr.skip[p.id];
      const r = { p, days, hc, skip };
      if (skip) { r.state = 'skip'; rows.push(r); return; }
      if (hc <= 0) { r.state = 'missing'; blockers.push(`${p.kurzname}: keine Stunden erfasst – bitte entscheiden.`); rows.push(r); return; }
      if (p.pauschal) {
        const t = dr.pTotal[p.id];
        if (t == null || Math.round(t * 100) !== hc) blockers.push(`${p.kurzname}: Summe der Tage (${C.fmtHc(hc)}) entspricht nicht dem Stundentotal${t != null ? ' (' + Number(t).toFixed(2) + ')' : ''}.`);
      }
      r.calc = C.calcPerson(p, hc, d.settings, { excessMode: dr.excess[p.id] });
      if (r.calc.excess && !dr.excess[p.id]) blockers.push(`${p.kurzname}: AHV-Lohn über CHF ${C.fmtMoney(C.toCents(d.settings.freibetrag))} – bitte Vorgehen wählen.`);
      r.state = 'ok'; rows.push(r);
    });
    return { rows, blockers, totalHc: rows.reduce((a, r) => a + (r.state === 'ok' ? r.hc : 0), 0) };
  }

  /* ---------- Dokumente erstellen ---------- */
  async function createDocs() {
    const d = S.data; const dr = ensureDraft(); const ev = evaluate(); const { y, m } = keyYM(dr.key);
    if (ev.blockers.length) return;
    if (d.months[dr.key] && !confirm('Für diesen Monat wurden schon Dokumente erstellt. Neu erstellen und den Eintrag in der Jahresübersicht ersetzen?')) return;
    S.busy = true; render();
    try {
      const files = []; const rec = { created: new Date().toISOString(), persons: {} };
      for (const r of ev.rows) {
        if (r.state !== 'ok') continue;
        const days = r.days.slice().sort((a, b) => a.date.localeCompare(b.date));
        const lohn = await P.lohnabrechnung(window.PDFLib, { employer: d.employer, person: r.p, y, m, calc: r.calc, settings: d.settings });
        const std = await P.stundenuebersicht(window.PDFLib, { employer: d.employer, person: r.p, y, m, days, settings: d.settings });
        files.push({ name: `${dr.key} Lohnabrechnung ${r.p.kurzname}.pdf`, bytes: lohn, person: r.p.kurzname });
        files.push({ name: `${dr.key} Stundenübersicht ${r.p.kurzname}.pdf`, bytes: std, person: r.p.kurzname });
        rec.persons[r.p.id] = { hc: r.hc, bruttoC: r.calc.bruttoC, nettoC: r.calc.nettoC };
      }
      d.months[dr.key] = rec; await save();
      const jb = await P.jahresuebersicht(window.PDFLib, { employer: d.employer, persons: d.persons, year: y, months: d.months });
      files.push({ name: `Jahresübersicht Löhne Assistenz ${y}.pdf`, bytes: jb, person: 'Jahresübersicht' });
      S.result = { key: dr.key, files: files.map((f) => ({ name: f.name, person: f.person, blob: new Blob([f.bytes], { type: 'application/pdf' }) })) };
    } catch (e) { alert('Fehler beim Erstellen der Dokumente: ' + e.message); }
    S.busy = false; render();
  }
  async function shareFiles(list) {
    const files = list.map((f) => new File([f.blob], f.name, { type: 'application/pdf' }));
    if (navigator.canShare && navigator.canShare({ files })) { try { await navigator.share({ files }); return; } catch (e) { if (e.name === 'AbortError') return; } }
    list.forEach((f) => { const a = h('a', { href: URL.createObjectURL(f.blob), download: f.name }); document.body.append(a); a.click(); a.remove(); });
  }
  const openBlob = (f) => window.open(URL.createObjectURL(f.blob), '_blank');

  /* ---------- Ansicht: Abrechnung ---------- */
  function numInput(value, onset, opts) {
    return h('input', Object.assign({ type: 'text', inputmode: 'decimal', value, onchange: (e) => { const v = Number(String(e.target.value).replace(',', '.')); onset(isFinite(v) ? v : 0); } }, opts || {}));
  }
  function viewAbr() {
    const d = S.data; const dr = ensureDraft(); const { y, m } = keyYM(dr.key); const ev = evaluate();
    const wrap = h('div', {});
    if (!d.persons.length) return h('div', { class: 'card' }, h('p', {}, 'Es sind noch keine Assistenzpersonen erfasst. Bitte zuerst unter „Einstellungen“ Arbeitgeber und Personen eintragen.'), h('button', { class: 'btn', onclick: () => { S.tab = 'set'; render(); } }, 'Zu den Einstellungen'));

    // Monat
    const mSel = h('select', { onchange: (e) => { if (hasDraftData(dr) && !confirm('Der Entwurf des aktuellen Monats geht verloren. Fortfahren?')) { render(); return; } resetDraft(C.monthKey(y, Number(e.target.value))); render(); } },
      C.MONATE.map((n, i) => h('option', { value: i + 1, selected: i + 1 === m }, n)));
    const yNow = new Date().getFullYear();
    const ySel = h('select', { onchange: (e) => { if (hasDraftData(dr) && !confirm('Der Entwurf des aktuellen Monats geht verloren. Fortfahren?')) { render(); return; } resetDraft(C.monthKey(Number(e.target.value), m)); render(); } },
      [yNow - 2, yNow - 1, yNow, yNow + 1].map((yy) => h('option', { value: yy, selected: yy === y }, yy)));
    const fileIn = h('input', { type: 'file', accept: '.csv,text/csv,text/plain', class: 'hidden', onchange: async (e) => { const f = e.target.files[0]; if (!f) return; applyCsv(await f.text(), f.name); render(); } });
    wrap.append(h('div', { class: 'card' }, h('h2', {}, 'Abrechnungsmonat'), h('div', { class: 'row' }, mSel, ySel),
      h('p', { class: 'muted small' }, `Abrechnungsdatum: ${C.fmtDate(C.nextMonthFirst(y, m))}`),
      h('button', { class: 'btn', onclick: () => fileIn.click() }, 'Clockify-CSV einlesen'), fileIn,
      d.persons.some((p) => p.id.startsWith('demo')) ? h('button', { class: 'btn sec', onclick: () => { applyCsv(demoCsv(y, m, d.persons), 'Beispiel.csv'); render(); } }, 'Beispiel-CSV laden (erfunden)') : null,
      infoBlock(dr)));

    // Personen
    ev.rows.forEach((r) => wrap.append(personCard(r, dr, y, m)));

    // Kontrolle
    const tbl = h('table', { class: 'tbl compact' }, h('thead', {}, h('tr', {}, ['Person', 'Std.', 'Brutto', 'AHV', 'Netto'].map((t, i) => h('th', { class: i ? 'r' : '' }, t)))),
      h('tbody', {}, ev.rows.map((r) => h('tr', {}, h('td', { class: 'wrap' }, r.p.kurzname, r.state === 'skip' ? h('div', { class: 'muted small' }, 'nicht gearbeitet') : null), h('td', { class: 'r' }, r.state === 'ok' ? C.fmtHc(r.hc) : (r.state === 'skip' ? '–' : '?')),
        h('td', { class: 'r' }, r.calc ? C.fmtMoney(r.calc.bruttoC) : ''), h('td', { class: 'r' }, r.calc ? C.fmtMoney(r.calc.ahvC) : ''), h('td', { class: 'r' }, r.calc ? C.fmtMoney(r.calc.nettoC) : '')))),
      h('tfoot', {}, h('tr', {}, h('td', { class: 'wrap' }, 'Total aller Personen'), h('td', { class: 'r' }, C.fmtHc(ev.totalHc)), h('td', {}), h('td', {}), h('td', { class: 'r' }, C.fmtMoney(ev.rows.reduce((a, r) => a + (r.calc ? r.calc.nettoC : 0), 0))))));
    const csvDiff = ev.rows.filter((r) => !r.p.pauschal && r.state === 'ok' && dr.csvHc[r.p.id] != null && dr.info && !dr.info.errors.length && dr.csvHc[r.p.id] !== r.hc);
    wrap.append(h('div', { class: 'card' }, h('h2', {}, 'Kontrolle'), h('div', { class: 'scroll' }, tbl),
      csvDiff.map((r) => h('p', { class: 'warn' }, `${r.p.kurzname}: Stunden von Hand geändert (CSV: ${C.fmtHc(dr.csvHc[r.p.id])}, jetzt: ${C.fmtHc(r.hc)}).`)),
      ev.blockers.length ? h('div', { class: 'blockers' }, h('strong', {}, 'Noch offen:'), ev.blockers.map((b) => h('p', {}, b))) : h('p', { class: 'ok' }, 'Alles geprüft. Die Dokumente können erstellt werden.'),
      h('button', { class: 'btn', disabled: !!ev.blockers.length || S.busy, onclick: createDocs }, S.busy ? 'Erstelle …' : 'Dokumente erstellen')));

    if (S.result && S.result.key === dr.key) wrap.append(resultCard());
    return wrap;
  }
  const hasDraftData = (dr) => Object.values(dr.days).some((a) => a.length) || Object.keys(dr.skip).length;

  function infoBlock(dr) {
    const i = dr.info; if (!i) return null;
    if (i.errors && i.errors.length) return h('div', { class: 'blockers' }, h('strong', {}, `Datei „${i.filename}“ konnte nicht gelesen werden:`), i.errors.map((e) => h('p', {}, e)), i.headers ? h('p', { class: 'small' }, 'Gefundene Spalten: ' + i.headers.join(' | ')) : null);
    const out = [h('p', { class: 'ok small' }, `„${i.filename}“ eingelesen: ${i.rows} Zeilen.`)];
    if (i.outside) out.push(h('p', { class: 'warn small' }, `${i.outside} Einträge liegen in anderen Monaten und wurden ignoriert.`));
    (i.unmatched || []).forEach((u) => out.push(h('p', { class: 'warn small' }, `Unbekannter Benutzer „${u.user}“ (${u.count} Einträge, ${C.fmtHc(u.hc)} h) – keiner Person zugeordnet. In den Einstellungen bei der Person den Clockify-Namen eintragen.`)));
    (i.warnings || []).forEach((w) => out.push(h('p', { class: 'warn small' }, w)));
    return h('div', {}, out);
  }

  function personCard(r, dr, y, m) {
    const p = r.p; const days = dr.days[p.id] || (dr.days[p.id] = []);
    const used = new Set(days.map((q) => q.date)); const mdays = C.monthDays(y, m);
    const card = h('div', { class: 'card' },
      h('div', { class: 'row between' }, h('h3', {}, p.kurzname), h('span', { class: 'tag' }, p.ahvAbzug ? 'mit AHV-Abzug' : 'ohne AHV-Abzug')));
    if (r.state === 'skip') {
      card.append(h('p', { class: 'muted' }, 'Hat in diesem Monat nicht gearbeitet – keine Abrechnung, Monat bleibt in der Jahresübersicht leer.'),
        h('button', { class: 'btn sec', onclick: () => { delete dr.skip[p.id]; saveSoon(); render(); } }, 'Rückgängig'));
      return card;
    }
    if (p.pauschal) {
      const first = mdays.find((x) => !used.has(x)) || mdays[0];
      const sat = C.sundaysThursdays(y, m);
      const msg = h('p', { class: 'err small' });
      card.append(h('p', { class: 'muted small' }, 'Keine Erfassung. Stundentotal eingeben, dann wird auf Sonntage und Donnerstage (je 4 oder 5 Stunden) verteilt.'),
        h('label', {}, 'Stundentotal im Monat'), numInput(dr.pTotal[p.id] != null ? dr.pTotal[p.id] : '', (v) => { dr.pTotal[p.id] = v; saveSoon(); }, { placeholder: 'z. B. 36' }),
        h('button', { class: 'btn sec', onclick: () => {
          const t = dr.pTotal[p.id]; const res = C.distribute(t, sat);
          if (res.error) { msg.textContent = res.error; return; } days.splice(0, days.length, ...res.days); saveSoon(); render();
        } }, 'Verteilung vorschlagen'), msg);
      if (!days.length && r.state === 'missing') card.append(h('button', { class: 'btn sec', onclick: () => { dr.skip[p.id] = true; saveSoon(); render(); } }, 'Hat nicht gearbeitet'));
    } else if (r.state === 'missing' && !days.length) {
      card.append(h('p', { class: 'warn' }, 'Keine Einträge in diesem Monat gefunden. Hat die Person nicht gearbeitet?'),
        h('div', { class: 'row' }, h('button', { class: 'btn', onclick: () => { dr.skip[p.id] = true; saveSoon(); render(); } }, 'Ja, nicht gearbeitet'),
          h('button', { class: 'btn sec', onclick: () => { days.push({ date: mdays[0], hc: 0 }); saveSoon(); render(); } }, 'Nein, Stunden eintragen')));
    }
    if (days.length) {
      const first = mdays.find((x) => !used.has(x)) || mdays[0];
      const list = h('div', { class: 'days' });
      days.forEach((q, idx) => list.append(h('div', { class: 'dayrow' },
        h('input', { type: 'date', value: q.date, min: mdays[0], max: mdays[mdays.length - 1], onchange: (e) => { if (e.target.value) { q.date = e.target.value; days.sort((a, b) => a.date.localeCompare(b.date)); saveSoon(); render(); } } }),
        h('span', { class: 'wd' }, C.weekdayName(q.date).slice(0, 2)),
        numInput(q.hc ? (q.hc / 100).toFixed(2) : '', (v) => { q.hc = Math.round(v * 100); saveSoon(); render(); }, { class: 'hrs' }),
        h('button', { class: 'x', title: 'Zeile löschen', onclick: () => { days.splice(idx, 1); saveSoon(); render(); } }, '×'))));
      card.append(list, h('div', { class: 'row between' }, h('button', { class: 'btn sec small', onclick: () => { days.push({ date: first, hc: 0 }); days.sort((a, b) => a.date.localeCompare(b.date)); saveSoon(); render(); } }, '+ Tag'),
        h('strong', {}, `${days.length} Einsätze · ${C.fmtHc(r.hc)} h`)));
      if (p.pauschal && dr.pTotal[p.id] != null) {
        const ok = Math.round(dr.pTotal[p.id] * 100) === r.hc;
        card.append(h('p', { class: ok ? 'ok small' : 'err small' }, ok ? `Summe stimmt mit dem Total (${Number(dr.pTotal[p.id]).toFixed(2)} h) überein.` : `Summe ${C.fmtHc(r.hc)} h ≠ Total ${Number(dr.pTotal[p.id]).toFixed(2)} h.`));
      }
    }
    if (r.calc && r.calc.excess) {
      const sel = h('select', { onchange: (e) => { if (e.target.value) dr.excess[p.id] = e.target.value; else delete dr.excess[p.id]; saveSoon(); render(); } },
        h('option', { value: '' }, 'Bitte wählen …'),
        h('option', { value: 'ohne', selected: dr.excess[p.id] === 'ohne' }, 'Ohne AHV-Abzug abrechnen'),
        h('option', { value: 'abziehen', selected: dr.excess[p.id] === 'abziehen' }, `AHV nur auf Teil über ${C.fmtMoney(C.toCents(S.data.settings.freibetrag))}`));
      card.append(h('div', { class: 'blockers' }, h('strong', {}, 'Achtung: AHV-Lohn über CHF ' + C.fmtMoney(C.toCents(S.data.settings.freibetrag))),
        h('p', {}, `Der AHV-Lohn beträgt CHF ${C.fmtMoney(r.calc.bruttoC)}. Möglicherweise muss auf den übersteigenden Teil AHV abgezogen werden (Freibetrag für Personen im Rentenalter). Bitte entscheiden:`), sel));
    }
    if (r.calc) card.append(h('p', { class: 'muted small' }, `Brutto CHF ${C.fmtMoney(r.calc.bruttoC)} · AHV ${C.fmtMoney(r.calc.ahvC)} · Netto CHF ${C.fmtMoney(r.calc.nettoC)}`));
    return card;
  }

  function resultCard() {
    const r = S.result; const files = r.files;
    return h('div', { class: 'card done' }, h('h2', {}, 'Dokumente erstellt'),
      h('p', { class: 'muted small' }, 'Die Dateien liegen nur in diesem Gerät. „Speichern/Teilen“ öffnet das iPhone-Menü (z. B. „In Dateien sichern“ oder Google Drive).'),
      files.map((f) => h('div', { class: 'file' }, h('span', {}, f.name),
        h('div', { class: 'row' }, h('button', { class: 'btn sec small', onclick: () => openBlob(f) }, 'Ansehen'), h('button', { class: 'btn small', onclick: () => shareFiles([f]) }, 'Speichern/Teilen')))),
      h('button', { class: 'btn', onclick: () => shareFiles(files) }, 'Alle Dateien speichern/teilen'),
      h('p', { class: 'muted small' }, 'Ablage in Google Drive und Gmail-Entwürfe folgen in Phase 2.'));
  }

  /* ---------- Ansicht: Jahresübersicht ---------- */
  function viewYear() {
    const d = S.data; const yNow = new Date().getFullYear(); const year = S.year || yNow;
    const ySel = h('select', { onchange: (e) => { S.year = Number(e.target.value); render(); } }, [yNow - 2, yNow - 1, yNow, yNow + 1].map((yy) => h('option', { value: yy, selected: yy === year }, yy)));
    const yt = C.yearTotals(d.months, d.persons, year);
    const cols = []; d.persons.forEach((p) => { if (p.ahvAbzug) { cols.push([p, 'bruttoC', 'Brutto']); cols.push([p, 'nettoC', 'Netto']); } else cols.push([p, 'nettoC', 'Netto']); });
    const tbl = h('table', { class: 'tbl' }, h('thead', {}, h('tr', {}, h('th', {}, 'Monat'), cols.map((c) => h('th', { class: 'r' }, `${c[0].vorname} ${c[2]}`)), h('th', { class: 'r' }, 'Stunden'))),
      h('tbody', {}, yt.rows.map((r) => h('tr', {}, h('td', {}, C.MONATE[r.m - 1]), cols.map((c) => h('td', { class: 'r' }, !r.empty && r.per[c[0].id] ? C.fmtMoney(r.per[c[0].id][c[1]]) : '')), h('td', { class: 'r' }, r.empty ? '' : C.fmtHc(r.hc))))),
      h('tfoot', {}, h('tr', {}, h('td', {}, 'Total'), cols.map((c) => h('td', { class: 'r' }, C.fmtMoney(yt.tot.perPerson[c[0].id][c[1]]))), h('td', { class: 'r' }, C.fmtHc(yt.tot.hc)))));
    return h('div', { class: 'card' }, h('h2', {}, 'Jahresübersicht'), h('div', { class: 'row' }, ySel), h('div', { class: 'scroll' }, tbl), h('p', { class: 'muted small' }, 'Für alle Spalten die Tabelle seitlich wischen.'),
      h('p', { class: 'muted small' }, `Abgerechnete Monate: ${yt.tot.count} von 12 · Ausbezahlt netto: CHF ${C.fmtMoney(yt.tot.netto)}`),
      h('button', { class: 'btn', onclick: async () => {
        const bytes = await P.jahresuebersicht(window.PDFLib, { employer: d.employer, persons: d.persons, year, months: d.months });
        S.lastYearFile = { name: `Jahresübersicht Löhne Assistenz ${year}.pdf`, year, blob: new Blob([bytes], { type: 'application/pdf' }) }; render();
      } }, 'PDF erstellen'),
      S.lastYearFile && S.lastYearFile.year === year ? h('div', { class: 'row' }, h('button', { class: 'btn sec', onclick: () => openBlob(S.lastYearFile) }, 'Ansehen'), h('button', { class: 'btn sec', onclick: () => shareFiles([S.lastYearFile]) }, 'Speichern/Teilen')) : null,
      h('p', { class: 'muted small' }, 'Wenn ein Monat falsch erfasst wurde, in „Abrechnung“ denselben Monat neu erstellen: Der Eintrag wird ersetzt.'));
  }

  /* ---------- Ansicht: Einstellungen ---------- */
  function field(label, value, onset, opts) {
    return h('label', { class: 'f' }, h('span', {}, label), h('input', Object.assign({ type: 'text', value: value == null ? '' : value, onchange: (e) => { onset(e.target.value.trim()); saveSoon(); } }, opts || {})));
  }
  function viewSettings() {
    const d = S.data; const out = h('div', {});
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Arbeitgeber (Briefkopf)'),
      field('Name', d.employer.name, (v) => { d.employer.name = v; }), field('Strasse', d.employer.strasse, (v) => { d.employer.strasse = v; }),
      field('PLZ Ort', d.employer.ort, (v) => { d.employer.ort = v; }), field('E-Mail (für CC)', d.employer.email, (v) => { d.employer.email = v; })));
    const num = (k, label) => field(label, d.settings[k], (v) => { const n = Number(String(v).replace(',', '.')); if (isFinite(n) && n >= 0) d.settings[k] = n; }, { inputmode: 'decimal' });
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Sätze'), num('stundenlohn', 'Stundenlohn (CHF)'), num('ferien', 'Ferienentschädigung (%)'), num('ahv', 'AHV/IV/EO (%)'), num('freibetrag', 'Freibetrag pro Monat ohne AHV-Abzug (CHF)'),
      h('p', { class: 'muted small' }, 'ALV, BVG, NBU, Krankentaggeld und Quellensteuer sind fest auf 0.')));
    // Personen
    const pc = h('div', { class: 'card' }, h('h2', {}, 'Assistenzpersonen'));
    d.persons.forEach((p) => {
      if (S.editing === p.id) { pc.append(personForm(p)); return; }
      pc.append(h('div', { class: 'file' }, h('span', {}, h('strong', {}, p.kurzname), h('br'), h('span', { class: 'muted small' }, `${p.ahvAbzug ? 'mit' : 'ohne'} AHV-Abzug${p.pauschal ? ' · Stunden nach Total' : ''}`)),
        h('button', { class: 'btn sec small', onclick: () => { S.editing = p.id; render(); } }, 'Bearbeiten')));
    });
    pc.append(h('button', { class: 'btn sec', onclick: () => { const p = { id: uid(), anrede: 'Frau', name: '', kurzname: '', vorname: '', strasse: '', plzOrt: '', email: '', ahvNr: '', ahvAbzug: true, pauschal: false, clockifyKey: '', zahlung: '' }; d.persons.push(p); S.editing = p.id; render(); } }, '+ Person hinzufügen'));
    out.append(pc);
    // Sicherung
    const fileIn = h('input', { type: 'file', accept: '.json,application/json', class: 'hidden', onchange: async (e) => {
      const f = e.target.files[0]; if (!f) return;
      const pin = prompt('PIN der Sicherung eingeben:'); if (!pin) return;
      try { const b = JSON.parse(await f.text()); const key = await deriveKey(pin, unb64(b.salt), b.iter); const data = await decryptWith(key, b);
        if (!confirm('Alle aktuellen Daten durch die Sicherung ersetzen?')) return;
        S.key = key; S.salt = unb64(b.salt); S.data = data; localStorage.setItem(VAULT_KEY, JSON.stringify(b)); S.tab = 'abr'; render();
      } catch (err) { alert('PIN falsch oder Datei beschädigt.'); }
    } });
    out.append(h('div', { class: 'card' }, h('h2', {}, 'Sicherung und PIN'),
      h('p', { class: 'muted small' }, 'Die Sicherungsdatei ist mit deiner PIN verschlüsselt. Lege sie z. B. im Google-Drive-Ordner ab.'),
      h('button', { class: 'btn', onclick: async () => {
        await save(); const text = localStorage.getItem(VAULT_KEY); const name = `Sicherung Abrechnung ${new Date().toISOString().slice(0, 10)}.json`;
        const file = new File([text], name, { type: 'application/json' });
        if (navigator.canShare && navigator.canShare({ files: [file] })) { try { await navigator.share({ files: [file] }); return; } catch (e) { if (e.name === 'AbortError') return; } }
        const a = h('a', { href: URL.createObjectURL(file), download: name }); document.body.append(a); a.click(); a.remove();
      } }, 'Sicherung speichern'),
      h('button', { class: 'btn sec', onclick: () => fileIn.click() }, 'Sicherung laden'), fileIn,
      h('button', { class: 'btn sec', onclick: async () => {
        const old = prompt('Aktuelle PIN:'); if (old == null) return;
        try { const v = JSON.parse(localStorage.getItem(VAULT_KEY)); await decryptWith(await deriveKey(old, unb64(v.salt), v.iter), v); } catch (e) { alert('PIN falsch.'); return; }
        const n1 = prompt('Neue PIN (6–8 Ziffern):'); if (n1 == null) return; if (!/^\d{6,8}$/.test(n1)) { alert('Die PIN muss aus 6 bis 8 Ziffern bestehen.'); return; }
        if (prompt('Neue PIN wiederholen:') !== n1) { alert('Die PIN stimmen nicht überein.'); return; }
        S.salt = crypto.getRandomValues(new Uint8Array(16)); S.key = await deriveKey(n1, S.salt, ITER); await save(); alert('PIN geändert. Bitte danach eine neue Sicherung speichern.');
      } }, 'PIN ändern'),
      h('button', { class: 'btn sec', onclick: lock }, 'Jetzt sperren'),
      !d.persons.some((p) => p.id.startsWith('demo')) && !d.persons.length ? h('button', { class: 'btn sec', onclick: () => { loadDemo(d); saveSoon(); render(); } }, 'Erfundene Beispieldaten laden') : null,
      h('button', { class: 'btn danger', onclick: () => { if (confirm('Wirklich ALLE Daten in diesem Gerät löschen? Das geht nur mit einer Sicherungsdatei rückgängig.') && confirm('Letzte Rückfrage: Alles löschen?')) { localStorage.removeItem(VAULT_KEY); lock(); } } }, 'Alle Daten löschen')));
    return out;
  }
  function personForm(p) {
    const d = S.data;
    const chk = (label, k) => h('label', { class: 'chk' }, h('input', { type: 'checkbox', checked: p[k], onchange: (e) => { p[k] = e.target.checked; saveSoon(); } }), label);
    return h('div', { class: 'pform' },
      h('label', { class: 'f' }, h('span', {}, 'Anrede'), h('select', { onchange: (e) => { p.anrede = e.target.value; saveSoon(); } }, ['Frau', 'Herr'].map((a) => h('option', { selected: p.anrede === a }, a)))),
      field('Name auf Dokumenten (mit Zweitnamen)', p.name, (v) => { p.name = v; }), field('Kurzname für Dateien und Ordner', p.kurzname, (v) => { p.kurzname = v; }),
      field('Vorname (Anrede in der E-Mail)', p.vorname, (v) => { p.vorname = v; }), field('Strasse', p.strasse, (v) => { p.strasse = v; }), field('PLZ Ort', p.plzOrt, (v) => { p.plzOrt = v; }),
      field('E-Mail', p.email, (v) => { p.email = v; }, { inputmode: 'email' }), field('AHV-Nr.', p.ahvNr, (v) => { p.ahvNr = v; }),
      field('Name oder E-Mail in Clockify (falls anders)', p.clockifyKey, (v) => { p.clockifyKey = v; }),
      field('Zahlungsangabe unter „Der Betrag wird wie folgt überwiesen“ (optional)', p.zahlung, (v) => { p.zahlung = v; }),
      chk('AHV-Abzug', 'ahvAbzug'), chk('Keine Erfassung: Stunden nach Total auf Sonntage/Donnerstage verteilen', 'pauschal'),
      h('div', { class: 'row' }, h('button', { class: 'btn', onclick: () => { S.editing = null; render(); } }, 'Fertig'),
        h('button', { class: 'btn danger', onclick: () => { if (confirm(`${p.kurzname || 'Person'} löschen?`)) { d.persons = d.persons.filter((x) => x.id !== p.id); S.editing = null; saveSoon(); render(); } } }, 'Löschen')));
  }

  /* ---------- Rahmen ---------- */
  function render() {
    root.replaceChildren();
    if (!S.key) { root.append(localStorage.getItem(VAULT_KEY) ? viewLock() : viewOnboarding()); return; }
    const tabs = [['abr', 'Abrechnung'], ['year', 'Jahr'], ['set', 'Einstellungen']];
    const main = h('main', {}, S.tab === 'abr' ? viewAbr() : (S.tab === 'year' ? viewYear() : viewSettings()));
    root.append(h('header', {}, h('h1', {}, tabs.find((t) => t[0] === S.tab)[1])), main,
      h('nav', {}, tabs.map((t) => h('button', { class: S.tab === t[0] ? 'on' : '', onclick: () => { S.tab = t[0]; render(); window.scrollTo(0, 0); } }, t[1]))));
  }
  render();
  if ('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('sw.js').catch(() => {});
})();
