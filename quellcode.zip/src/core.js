/* Kernlogik: Datum, Rundung, Lohnberechnung, Carolina-Verteilung, Clockify-CSV.
   Alle Geldbeträge in Rappen (ganze Zahlen), alle Stunden in Hundertstel (ganze Zahlen). */
(function (root) {
  'use strict';

  const MONATE = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
  const WOCHENTAGE = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];

  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;
  function parseYmd(s) { const [y, m, d] = s.split('-').map(Number); return { y, m, d }; }
  function weekday(s) { const { y, m, d } = parseYmd(s); return new Date(Date.UTC(y, m - 1, d)).getUTCDay(); }
  const weekdayName = (s) => WOCHENTAGE[weekday(s)];
  function fmtDate(s) { const { y, m, d } = parseYmd(s); return `${pad(d)}.${pad(m)}.${y}`; }
  const daysInMonth = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  function monthDays(y, m) { const n = daysInMonth(y, m); const a = []; for (let d = 1; d <= n; d++) a.push(ymd(y, m, d)); return a; }
  function sundaysThursdays(y, m) { return monthDays(y, m).filter((s) => { const w = weekday(s); return w === 0 || w === 4; }); }
  const monthKey = (y, m) => `${y}-${pad(m)}`;
  const monthLabel = (y, m) => `${MONATE[m - 1]} ${y}`;
  function nextMonthFirst(y, m) { return m === 12 ? ymd(y + 1, 1, 1) : ymd(y, m + 1, 1); }

  /* ---------- Geld und Stunden ---------- */
  const toCents = (chf) => Math.round(Number(chf) * 100 + 1e-6);
  const round5 = (cents) => Math.round(cents / 5 + 1e-9) * 5; // auf 5 Rappen
  function fmtMoney(c) {
    const neg = c < 0; const a = Math.abs(c);
    const chf = String(Math.floor(a / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, "'");
    return (neg ? '-' : '') + chf + '.' + pad(a % 100);
  }
  const fmtHc = (hc) => (hc / 100).toFixed(2);
  const fmtPct = (p, dec) => Number(p).toFixed(dec) + '%';

  /* ---------- Lohnberechnung ---------- */
  function calcPerson(person, hc, s, opt) {
    opt = opt || {};
    const rateC = toCents(s.stundenlohn);
    const lohnC = round5(hc * rateC / 100);
    const ferienC = round5(lohnC * s.ferien / 100);
    const bruttoC = lohnC + ferienC;
    let basisC = 0; let ahvRate = 0; let ahvC = 0; let excess = false;
    if (person.ahvAbzug) {
      basisC = bruttoC; ahvRate = s.ahv; ahvC = round5(bruttoC * s.ahv / 100);
    } else {
      const frei = toCents(s.freibetrag);
      if (bruttoC > frei) {
        excess = true;
        if (opt.excessMode === 'abziehen') { basisC = bruttoC - frei; ahvRate = s.ahv; ahvC = round5(basisC * s.ahv / 100); }
      }
    }
    const abzuegeC = ahvC; // ALV, BVG, NBU, KTG, Quellensteuer = 0
    return {
      hc, rateC, lohnC, ferienC, bruttoC, ahvLohnC: bruttoC,
      ahvBasisC: basisC > 0 ? basisC : bruttoC, ahvRate, ahvC, abzuegeC,
      nettoC: bruttoC - abzuegeC, excess, excessMode: opt.excessMode || null,
    };
  }

  /* ---------- Verteilung für Personen ohne Erfassung (Sonntage/Donnerstage) ---------- */
  function distribute(totalHours, days) {
    const T = Number(totalHours); const D = days.length;
    if (!isFinite(T) || T <= 0) return { error: 'Bitte ein Stundentotal grösser als 0 eingeben.' };
    if (Math.abs(T - Math.round(T)) > 1e-9) return { error: 'Das Total muss in ganzen Stunden sein, damit je Tag 4 oder 5 Stunden möglich sind.' };
    const t = Math.round(T);
    const lo = Math.ceil(t / 5); const hi = Math.min(Math.floor(t / 4), D);
    if (lo > hi) {
      if (t > 5 * D) return { error: `Mit ${D} Sonntagen/Donnerstagen sind höchstens ${5 * D} Stunden möglich.` };
      return { error: `${t} Stunden lassen sich nicht in Tage mit je 4 oder 5 Stunden aufteilen.` };
    }
    let n = Math.round(t / 4.5); if (n < lo) n = lo; if (n > hi) n = hi;
    const fives = t - 4 * n;
    const idx = []; // gleichmässig verteilte Tage
    for (let k = 0; k < n; k++) idx.push(n === 1 ? Math.floor((D - 1) / 2) : Math.round(k * (D - 1) / (n - 1)));
    const five = new Set();
    for (let k = 0; k < fives; k++) five.add(Math.floor((k + 0.5) * n / fives));
    return { days: idx.map((di, k) => ({ date: days[di], hc: five.has(k) ? 500 : 400 })) };
  }

  /* ---------- CSV ---------- */
  function parseCSV(text) {
    text = String(text).replace(/^﻿/, '');
    const first = text.split(/\r?\n/, 1)[0] || '';
    const cnt = (ch) => (first.match(new RegExp('\\' + ch, 'g')) || []).length;
    const delim = cnt(';') > cnt(',') ? ';' : (cnt('\t') > cnt(',') ? '\t' : ',');
    const rows = []; let row = []; let cell = ''; let q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c;
      } else if (c === '"') q = true;
      else if (c === delim) { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        row.push(cell); cell = ''; if (row.some((x) => x.trim() !== '')) rows.push(row); row = [];
      } else cell += c;
    }
    row.push(cell); if (row.some((x) => x.trim() !== '')) rows.push(row);
    return rows;
  }

  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const HEAD = {
    user: ['user', 'benutzer', 'nutzer', 'mitarbeiter', 'name'],
    email: ['email', 'e-mail', 'e mail'],
    start: ['start date', 'startdatum', 'start-datum', 'datum', 'date', 'anfangsdatum', 'beginn datum'],
    startTime: ['start time', 'startzeit', 'beginn', 'anfangszeit'],
    endDate: ['end date', 'enddatum', 'end-datum'],
    durH: ['duration (h)', 'dauer (h)', 'duration', 'dauer'],
    durDec: ['duration (decimal)', 'dauer (dezimal)', 'duration (dec)', 'dauer (dez)'],
  };
  function findCol(headers, names) {
    const h = headers.map(norm);
    for (const n of names) { const i = h.indexOf(n); if (i >= 0) return i; }
    return -1;
  }
  function parseDuration(v) {
    v = String(v || '').trim(); if (!v) return null;
    let m = v.match(/^(\d+):(\d{1,2})(?::(\d{1,2}))?$/);
    if (m) { const mins = Number(m[1]) * 60 + Number(m[2]) + (m[3] ? Number(m[3]) / 60 : 0); return mins; }
    m = v.replace(',', '.').match(/^\d+(\.\d+)?$/);
    if (m) return Number(v.replace(',', '.')) * 60;
    return null;
  }
  const minutesToHc = (mins) => Math.round(mins / 60 * 100 + 1e-9);

  function parseDates(values) {
    // liefert {format, dates[]}; Formate: iso, dmy-dot, slash (M/D/Y oder D/M/Y)
    const out = []; let slashMDY = null; let ambiguous = false;
    const slash = values.filter((v) => /^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(v));
    for (const v of slash) {
      const [a, b] = v.split('/').map(Number);
      if (a > 12) slashMDY = false; else if (b > 12) slashMDY = true;
    }
    if (slash.length && slashMDY === null) { slashMDY = true; ambiguous = true; }
    for (const v0 of values) {
      const v = String(v0).trim(); let m;
      if ((m = v.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/))) out.push(ymd(+m[1], +m[2], +m[3]));
      else if ((m = v.match(/^(\d{1,2})\.(\d{1,2})\.(\d{2,4})$/))) out.push(ymd(m[3].length === 2 ? 2000 + +m[3] : +m[3], +m[2], +m[1]));
      else if ((m = v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/))) {
        const yy = m[3].length === 2 ? 2000 + +m[3] : +m[3];
        out.push(slashMDY ? ymd(yy, +m[1], +m[2]) : ymd(yy, +m[2], +m[1]));
      } else out.push(null);
    }
    return { dates: out, ambiguous };
  }

  /* Liest eine Clockify-CSV für einen Monat und ordnet die Einträge den Personen zu. */
  function importClockify(text, y, m, persons) {
    const res = { byPerson: {}, unmatched: [], outside: [], warnings: [], errors: [], cols: null, rows: 0 };
    const rows = parseCSV(text);
    if (rows.length < 2) { res.errors.push('Die Datei enthält keine Datenzeilen.'); return res; }
    const headers = rows[0];
    const c = {
      user: findCol(headers, HEAD.user), email: findCol(headers, HEAD.email), start: findCol(headers, HEAD.start),
      startTime: findCol(headers, HEAD.startTime), endDate: findCol(headers, HEAD.endDate),
      durH: findCol(headers, HEAD.durH), durDec: findCol(headers, HEAD.durDec),
    };
    res.cols = c; res.headers = headers;
    if (c.start < 0) res.errors.push('Spalte mit dem Startdatum nicht gefunden (erwartet z. B. „Start Date" oder „Startdatum").');
    if (c.durH < 0 && c.durDec < 0) res.errors.push('Spalte mit der Dauer nicht gefunden (erwartet z. B. „Duration (h)" oder „Duration (decimal)").');
    if (c.user < 0 && c.email < 0) res.errors.push('Spalte mit dem Benutzer nicht gefunden (erwartet z. B. „User" oder „Email").');
    if (res.errors.length) return res;

    const data = rows.slice(1);
    res.rows = data.length;
    const pd = parseDates(data.map((r) => r[c.start] || ''));
    if (pd.ambiguous) res.warnings.push('Das Datumsformat in der Datei ist nicht eindeutig (Tag/Monat). Es wurde Monat/Tag/Jahr angenommen. Bitte die Tage prüfen.');

    const keyMap = new Map();
    for (const p of persons) {
      [p.clockifyKey, p.email, p.kurzname, p.name].forEach((k) => { if (k && norm(k)) keyMap.set(norm(k), p.id); });
    }
    const seen = new Map(); const unm = new Map();
    data.forEach((r, i) => {
      const date = pd.dates[i];
      const user = c.user >= 0 ? (r[c.user] || '').trim() : '';
      const email = c.email >= 0 ? (r[c.email] || '').trim() : '';
      let mins = null;
      if (c.durH >= 0) mins = parseDuration(r[c.durH]);
      if (mins === null && c.durDec >= 0) mins = parseDuration(r[c.durDec]);
      if (!date || mins === null) { res.warnings.push(`Zeile ${i + 2}: Datum oder Dauer nicht lesbar – Zeile ignoriert.`); return; }
      const hc = minutesToHc(mins);
      if (hc <= 0) { res.warnings.push(`Zeile ${i + 2}: Dauer 0 – ignoriert.`); return; }
      const id = keyMap.get(norm(email)) || keyMap.get(norm(user));
      const label = user || email;
      if (!id) {
        const u = unm.get(label) || { user: label, email, count: 0, hc: 0 }; u.count++; u.hc += hc; unm.set(label, u); return;
      }
      const { y: ey, m: em } = parseYmd(date);
      if (ey !== y || em !== m) { res.outside.push({ id, date, hc }); return; }
      const t = c.startTime >= 0 ? r[c.startTime] : '';
      const dk = `${id}|${date}|${t}|${hc}`;
      if (seen.has(dk)) res.warnings.push(`Mögliche Dublette: ${label}, ${fmtDate(date)}, ${fmtHc(hc)} h (Zeile ${i + 2}).`);
      seen.set(dk, 1);
      if (c.endDate >= 0 && r[c.endDate]) {
        const ed = parseDates([r[c.endDate]]).dates[0];
        if (ed && ed !== date) res.warnings.push(`${label}: Einsatz am ${fmtDate(date)} geht über Mitternacht – zählt zum Starttag.`);
      }
      const bp = res.byPerson[id] || (res.byPerson[id] = { days: {}, entries: 0 });
      bp.days[date] = (bp.days[date] || 0) + hc; bp.entries++;
    });
    res.unmatched = [...unm.values()];
    for (const id of Object.keys(res.byPerson)) {
      for (const [d, hc] of Object.entries(res.byPerson[id].days)) {
        if (hc > 1200) res.warnings.push(`Auffällig: ${fmtDate(d)} hat ${fmtHc(hc)} Stunden an einem Tag.`);
      }
    }
    return res;
  }

  /* ---------- Jahresübersicht ---------- */
  function yearTotals(months, persons, year) {
    const rows = []; const tot = { hc: 0, perPerson: {}, netto: 0, bruttoAhv: 0, count: 0 };
    persons.forEach((p) => { tot.perPerson[p.id] = { bruttoC: 0, nettoC: 0 }; });
    for (let m = 1; m <= 12; m++) {
      const rec = months[monthKey(year, m)];
      if (!rec) { rows.push({ m, empty: true }); continue; }
      let hcSum = 0; const per = {};
      persons.forEach((p) => {
        const r = rec.persons && rec.persons[p.id];
        if (r) { per[p.id] = r; hcSum += r.hc; tot.perPerson[p.id].bruttoC += r.bruttoC; tot.perPerson[p.id].nettoC += r.nettoC; tot.netto += r.nettoC; if (p.ahvAbzug) tot.bruttoAhv += r.bruttoC; }
      });
      tot.hc += hcSum; tot.count++;
      rows.push({ m, per, hc: hcSum });
    }
    return { rows, tot };
  }

  const api = {
    MONATE, WOCHENTAGE, pad, ymd, parseYmd, weekday, weekdayName, fmtDate, daysInMonth, monthDays, sundaysThursdays,
    monthKey, monthLabel, nextMonthFirst, toCents, round5, fmtMoney, fmtHc, fmtPct, calcPerson, distribute,
    parseCSV, importClockify, yearTotals, norm,
  };
  root.Core = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
