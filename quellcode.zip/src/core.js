/* Kernlogik: Datum, Rundung, Lohnberechnung, Carolina-Verteilung, Clockify-CSV.
   Alle Geldbeträge in Rappen (ganze Zahlen), alle Stunden in Hundertstel (ganze Zahlen). */
(function (root) {
  'use strict';

  const MONATE = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];
  const WOCHENTAGE = ['Sonntag', 'Montag', 'Dienstag', 'Mittwoch', 'Donnerstag', 'Freitag', 'Samstag'];

  const pad = (n) => String(n).padStart(2, '0');
  const ymd = (y, m, d) => `${y}-${pad(m)}-${pad(d)}`;
  function parseYmd(s) { const [y, m, d] = s.split('-').map(Number); return { y, m, d }; }
  function weekday(s) { const { y, m, d } = parseYmd(s); return new Date(Date.UTC(y, m - 1, d)).getUTCDay(); }
  const weekdayName = (s) => WOCHENTAGE[weekday(s)];
  function fmtDate(s) { const { y, m, d } = parseYmd(s); return `${pad(d)}.${pad(m)}.${y}`; }
  const daysInMonth = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  function monthDays(y, m) { const n = daysInMonth(y, m); const a = []; for (let d = 1; d <= n; d++) a.push(ymd(y, m, d)); return a; }
  function sundaysThursdays(y, m) { return monthDays(y, m).filter((s) => { const w = weekday(s); return w === 0 || w === 4; }); }
  const monthKey = (y, m) => `${y}-${pad(m)}`;
  const monthLabel = (y, m) => `${MONATE[m - 1]} ${y}`;
  function nextMonthFirst(y, m) { return m === 12 ? ymd(y + 1, 1, 1) : ymd(y, m + 1, 1); }

  /* ---------- Geld und Stunden ---------- */
  const toCents = (chf) => Math.round(Number(chf) * 100 + 1e-6);
  const round5 = (cents) => Math.round(cents / 5 + 1e-9) * 5; // auf 5 Rappen
  function fmtMoney(c) {
    const neg = c < 0; const a = Math.abs(c);
    const chf = String(Math.floor(a / 100)).replace(/\B(?=(\d{3})+(?!\d))/g, "'");
    return (neg ? '-' : '') + chf + '.' + pad(a % 100);
  }
  const fmtHc = (hc) => (hc / 100).toFixed(2);
  const fmtPct = (p, dec) => Number(p).toFixed(dec) + '%';

  /* ---------- Lohnberechnung ---------- */
  function calcPerson(person, hc, s, opt) {
    opt = opt || {};
    const rateC = toCents(s.stundenlohn);
    const lohnC = round5(hc * rateC / 100);
    const ferienC = round5(lohnC * s.ferien / 100);
    const bruttoC = lohnC + ferienC;
    let basisC = 0; let ahvRate = 0; let ahvC = 0; let excess = false;
    if (person.ahvAbzug) {
      basisC = bruttoC; ahvRate = s.ahv; ahvC = round5(bruttoC * s.ahv / 100);
    } else {
      const frei = toCents(s.freibetrag);
      if (bruttoC > frei) {
        excess = true;
        if (opt.excessMode === 'abziehen') { basisC = bruttoC - frei; ahvRate = s.ahv; ahvC = round5(basisC * s.ahv / 100); }
      }
    }
    const abzuegeC = ahvC; // ALV, BVG, NBU, KTG, Quellensteuer = 0
    return {
      hc, rateC, lohnC, ferienC, bruttoC, ahvLohnC: bruttoC,
      ahvBasisC: basisC > 0 ? basisC : bruttoC, ahvRate, ahvC, abzuegeC,
      nettoC: bruttoC - abzuegeC, excess, excessMode: opt.excessMode || null,
    };
  }

  /* ---------- Verteilung für Personen ohne Erfassung (Sonntage/Donnerstage) ---------- */
  function distribute(totalHours, days) {
    const T = Number(totalHours); const D = days.length;
    if (!isFinite(T) || T <= 0) return { error: 'Bitte ein Stundentotal grösser als 0 eingeben.' };
    if (Math.abs(T - Math.round(T)) > 1e-9) return { error: 'Das Total muss in ganzen Stunden sein, damit je Tag 4 oder 5 Stunden (wenn nötig 3) möglich sind.' };
    const t = Math.round(T);
    if (t > 5 * D) return { error: `Mit ${D} Sonntagen/Donnerstagen sind höchstens ${5 * D} Stunden möglich.` };
    // Zuerst nur 4- und 5-Stunden-Einsätze; geht das nicht auf, so wenige 3-Stunden-Einsätze wie möglich dazu.
    for (let threes = 0; threes <= D; threes++) {
      const r = t - 3 * threes; if (r < 0) break;
      const lo = Math.ceil(r / 5); const hi = Math.min(Math.floor(r / 4), D - threes);
      if (lo > hi) continue;
      let n4 = Math.round(r / 4.5); if (n4 < lo) n4 = lo; if (n4 > hi) n4 = hi;
      const fives = r - 4 * n4; const n = n4 + threes;
      const idx = []; // gleichmässig verteilte Tage
      for (let k = 0; k < n; k++) idx.push(n === 1 ? Math.floor((D - 1) / 2) : Math.round(k * (D - 1) / (n - 1)));
      const val = new Array(n).fill(400);
      const three = new Set(); for (let k = 0; k < threes; k++) three.add(Math.floor((k + 0.5) * n / threes));
      three.forEach((k) => { val[k] = 300; });
      const rest = []; for (let k = 0; k < n; k++) if (!three.has(k)) rest.push(k);
      for (let k = 0; k < fives; k++) val[rest[Math.floor((k + 0.5) * rest.length / fives)]] = 500;
      return { days: idx.map((di, k) => ({ date: days[di], hc: val[k] })) };
    }
    return { error: `${t} Stunden lassen sich nicht in Tage mit je 3, 4 oder 5 Stunden aufteilen.` };
  }

  /* ---------- CSV ---------- */
  function parseCSV(text) {
    text = String(text).replace(/^﻿/, '');
    const first = text.split(/\r?\n/, 1)[0] || '';
    const cnt = (ch) => (first.match(new RegExp('\\' + ch, 'g')) || []).length;
    const delim = cnt(';') > cnt(',') ? ';' : (cnt('\t') > cnt(',') ? '\t' : ',');
    const rows = []; let row = []; let cell = ''; let q = false;
    for (let i = 0; i < text.length; i++) {
      const c = text[i];
      if (q) {
        if (c === '"') { if (text[i + 1] === '"') { cell += '"'; i++; } else q = false; } else cell += c;
      } else if (c === '"') q = true;
      else if (c === delim) { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && text[i + 1] === '\n') i++;
        row.push(cell); cell = ''; if (row.some((x) => x.trim() !== '')) rows.push(row); row = [];
      } else cell += c;
    }
    row.push(cell); if (row.some((x) => x.trim() !== '')) rows.push(row);
    return rows;
  }

  const norm = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const HEAD = {
    user: ['user', 'benutzer', 'nutzer', 'mitarbeiter', 'name'],
    email: ['email', 'e-mail', 'e mail'],
    start: ['start date', 'startdatum', 'start-datum', 'datum', 'date', 'anfangsdatum', 'beginn datum'],
    startTime: ['start time', 'startzeit', 'beginn', 'anfangszeit'],
    endDate: ['end date', 'enddatum', 'end-datum'],
    durH: ['duration (h)', 'dauer (h)', 'duration', 'dauer'],
    durDec: ['duration (decimal)', 'dauer (dezimal)', 'duration (dec)', 'dauer (dez)'],
  };
  function findCol(headers, names) {
    const h = headers.map(norm);
    for (const n of names) { const i = h.indexOf(n); if (i >= 0) return i; }
    return -1;
  }
  function parseDuration(v) {
    v = String(v || '').trim(); if (!v) return null;
    let m = v.match(/^(\d+):(\d{1,2})(?::(\d{1,2}))?$/);
    if (m) { const mins = Number(m[1]) * 60 + Number(m[2]) + (m[3] ? Number(m[3]) / 60 : 0); return mins; }
    m = v.replace(',', '.').match(/^\d+(\.\d+)?$/);
    if (m) return Number(v.replace(',', '.')) * 60;
    return null;
  }
  const minutesToHc = (mins) => Math.round(mins / 60 * 100 + 1e-9);

  function parseDates(values) {
    // liefert {format, dates[]}; Formate: iso, dmy-dot, slash (M/D/Y oder D/M/Y)
    const out = []; let slashMDY = null; let ambiguous = false;
    const slash = values.filter((v) => /^\d{1,2}\/\d{1,2}\/\d{2,4}$/.test(v));
    for (const v of slash) {
      const [a, b] = v.split('/').map(Number);
      if (a > 12) slashMDY = false; else if (b > 12) slashMDY = true;
    }
    if (slash.length && slashMDY === null) { slashMDY = true; ambiguous = true; }
    for (const v0 of values) {
      const v = String(v0).trim(); let m;
      if ((m = v.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/))) out.push(ymd(+m[1], +m[2], +m[3]));
      else if ((m = v.match(/^(\d{1,2})\.(\d{1,2})\.(\d{2,4})$/))) out.push(ymd(m[3].length === 2 ? 2000 + +m[3] : +m[3], +m[2], +m[1]));
      else if ((m = v.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})$/))) {
        const yy = m[3].length === 2 ? 2000 + +m[3] : +m[3];
        out.push(slashMDY ? ymd(yy, +m[1], +m[2]) : ymd(yy, +m[2], +m[1]));
      } else out.push(null);
    }
    return { dates: out, ambiguous };
  }

  /* Liest eine Clockify-CSV für einen Monat und ordnet die Einträge den Personen zu. */
  function importClockify(text, y, m, persons) {
    const res = { byPerson: {}, unmatched: [], outside: [], warnings: [], errors: [], cols: null, rows: 0 };
    const rows = parseCSV(text);
    if (rows.length < 2) { res.errors.push('Die Datei enthält keine Datenzeilen.'); return res; }
    const headers = rows[0];
    const c = {
      user: findCol(headers, HEAD.user), email: findCol(headers, HEAD.email), start: findCol(headers, HEAD.start),
      startTime: findCol(headers, HEAD.startTime), endDate: findCol(headers, HEAD.endDate),
      durH: findCol(headers, HEAD.durH), durDec: findCol(headers, HEAD.durDec),
    };
    res.cols = c; res.headers = headers;
    if (c.start < 0) res.errors.push('Spalte mit dem Startdatum nicht gefunden (erwartet z. B. „Start Date" oder „Startdatum").');
    if (c.durH < 0 && c.durDec < 0) res.errors.push('Spalte mit der Dauer nicht gefunden (erwartet z. B. „Duration (h)" oder „Duration (decimal)").');
    if (c.user < 0 && c.email < 0) res.errors.push('Spalte mit dem Benutzer nicht gefunden (erwartet z. B. „User" oder „Email").');
    if (res.errors.length) return res;

    const data = rows.slice(1);
    res.rows = data.length;
    const pd = parseDates(data.map((r) => r[c.start] || ''));
    if (pd.ambiguous) res.warnings.push('Das Datumsformat in der Datei ist nicht eindeutig (Tag/Monat). Es wurde Monat/Tag/Jahr angenommen. Bitte die Tage prüfen.');

    const keyMap = new Map();
    for (const p of persons) {
      [p.clockifyKey, p.email, p.kurzname, p.name].forEach((k) => { if (k && norm(k)) keyMap.set(norm(k), p.id); });
    }
    const seen = new Map(); const unm = new Map();
    data.forEach((r, i) => {
      const date = pd.dates[i];
      const user = c.user >= 0 ? (r[c.user] || '').trim() : '';
      const email = c.email >= 0 ? (r[c.email] || '').trim() : '';
      let mins = null;
      if (c.durH >= 0) mins = parseDuration(r[c.durH]);
      if (mins === null && c.durDec >= 0) mins = parseDuration(r[c.durDec]);
      if (!date || mins === null) { res.warnings.push(`Zeile ${i + 2}: Datum oder Dauer nicht lesbar – Zeile ignoriert.`); return; }
      const hc = minutesToHc(mins);
      if (hc <= 0) { res.warnings.push(`Zeile ${i + 2}: Dauer 0 – ignoriert.`); return; }
      const id = keyMap.get(norm(email)) || keyMap.get(norm(user));
      const label = user || email;
      if (!id) {
        const u = unm.get(label) || { user: label, email, count: 0, hc: 0 }; u.count++; u.hc += hc; unm.set(label, u); return;
      }
      const { y: ey, m: em } = parseYmd(date);
      if (ey !== y || em !== m) { res.outside.push({ id, date, hc }); return; }
      const t = c.startTime >= 0 ? r[c.startTime] : '';
      const dk = `${id}|${date}|${t}|${hc}`;
      if (seen.has(dk)) res.warnings.push(`Mögliche Dublette: ${label}, ${fmtDate(date)}, ${fmtHc(hc)} h (Zeile ${i + 2}).`);
      seen.set(dk, 1);
      if (c.endDate >= 0 && r[c.endDate]) {
        const ed = parseDates([r[c.endDate]]).dates[0];
        if (ed && ed !== date) res.warnings.push(`${label}: Einsatz am ${fmtDate(date)} geht über Mitternacht – zählt zum Starttag.`);
      }
      const bp = res.byPerson[id] || (res.byPerson[id] = { days: {}, entries: 0 });
      bp.days[date] = (bp.days[date] || 0) + hc; bp.entries++;
    });
    res.unmatched = [...unm.values()];
    for (const id of Object.keys(res.byPerson)) {
      for (const [d, hc] of Object.entries(res.byPerson[id].days)) {
        if (hc > 1200) res.warnings.push(`Auffällig: ${fmtDate(d)} hat ${fmtHc(hc)} Stunden an einem Tag.`);
      }
    }
    return res;
  }

  /* ---------- Jahresübersicht ---------- */
  function yearTotals(months, persons, year) {
    const rows = []; const tot = { hc: 0, perPerson: {}, netto: 0, bruttoAhv: 0, count: 0 };
    persons.forEach((p) => { tot.perPerson[p.id] = { bruttoC: 0, nettoC: 0 }; });
    for (let m = 1; m <= 12; m++) {
      const rec = months[monthKey(year, m)];
      if (!rec) { rows.push({ m, empty: true }); continue; }
      let hcSum = 0; const per = {};
      persons.forEach((p) => {
        const r = rec.persons && rec.persons[p.id];
        if (r) { per[p.id] = r; hcSum += r.hc || 0; tot.perPerson[p.id].bruttoC += r.bruttoC; tot.perPerson[p.id].nettoC += r.nettoC; tot.netto += r.nettoC; if (p.ahvAbzug) tot.bruttoAhv += r.bruttoC; }
      });
      if (rec.hcTotal != null) hcSum = rec.hcTotal; // aus der Google Tabelle übernommener Monat: nur Total Stunden bekannt
      tot.hc += hcSum; tot.count++;
      rows.push({ m, per, hc: hcSum });
    }
    return { rows, tot };
  }

  /* Spalten der Jahresübersicht: Personen mit AHV-Abzug Brutto + Netto, die anderen nur Netto. */
  function yearColumns(persons) {
    const cols = [];
    persons.forEach((p) => { if (p.ahvAbzug) { cols.push({ p, k: 'bruttoC', label: `${p.vorname} Brutto` }); cols.push({ p, k: 'nettoC', label: `${p.vorname} Netto` }); } else cols.push({ p, k: 'nettoC', label: `${p.vorname} Netto` }); });
    return cols;
  }
  /* Werte für die Google Tabelle: Kopfzeile + 12 Monatszeilen (CHF als Zahl, leer = ''). Totals rechnet die Tabelle. */
  function yearSheet(months, persons, year) {
    const cols = yearColumns(persons); const yt = yearTotals(months, persons, year);
    const header = ['Monat'].concat(cols.map((c) => c.label), ['Total Stunden']);
    const rows = yt.rows.map((r) => [MONATE[r.m - 1]].concat(
      cols.map((c) => (!r.empty && r.per[c.p.id] ? r.per[c.p.id][c.k] / 100 : '')), [r.empty ? '' : r.hc / 100]));
    return { header, rows };
  }

  /* Monat aus einer Zelle der Jahrestabelle: «Januar», «Jan», «März 2026», «2026-03», {m: 3}. Sonst 0. */
  const MON3 = ['jan', 'feb', 'mar', 'apr', 'mai', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dez'];
  function sheetMonth(v) {
    if (v && typeof v === 'object' && v.m) return Number(v.m);
    const s = norm(v); let mm;
    if ((mm = s.match(/^\d{4}-(\d{2})$/))) return Number(mm[1]) >= 1 && Number(mm[1]) <= 12 ? Number(mm[1]) : 0;
    if (!/^[a-z]{3}/.test(s)) return 0;
    const i = MON3.indexOf(s.slice(0, 3)); return i + 1;
  }
  function sheetNumber(v) {
    if (v === '' || v == null) return null;
    if (typeof v === 'number') return isFinite(v) ? v : NaN;
    const s = String(v).replace(/[’'\s]/g, '').replace(/^CHF/i, '');
    if (!s) return null;
    return /^-?\d+(\.\d+)?$/.test(s) ? Number(s) : NaN;
  }
  /* Liest die bestehende Google Tabelle «Jahresübersicht» (Werte aus dem Script) und ordnet die Spalten den Personen zu. */
  function parseYearSheet(values, persons) {
    const res = { months: {}, cols: [], warnings: [], errors: [] };
    const hi = (values || []).findIndex((r) => r.some((c) => /brutto|netto/.test(norm(c))));
    if (hi < 0) { res.errors.push('In der Tabelle wurde keine Kopfzeile mit «Brutto» oder «Netto» gefunden.'); return res; }
    const head = values[hi]; let hoursCol = -1;
    head.forEach((c, j) => {
      if (j === 0) return; const hn = norm(c); if (!hn) return;
      if (hn.includes('stunden')) { if (hoursCol < 0 || hn.includes('total')) hoursCol = j; return; }
      const k = hn.includes('brutto') ? 'bruttoC' : (hn.includes('netto') ? 'nettoC' : null);
      let best = null; let bl = 0;
      persons.forEach((p) => [p.vorname, p.kurzname, p.name].forEach((x) => { const nx = norm(x); if (nx && hn.includes(nx) && nx.length > bl) { best = p; bl = nx.length; } }));
      if (!k || !best) { res.warnings.push(`Spalte «${c}» keiner Person zugeordnet – wird nicht übernommen.`); return; }
      if (res.cols.some((x) => x.p === best && x.k === k)) { res.errors.push(`Für ${best.kurzname} gibt es zwei Spalten «${k === 'bruttoC' ? 'Brutto' : 'Netto'}».`); return; }
      res.cols.push({ j, p: best, k, header: String(c) });
    });
    if (hoursCol < 0) res.errors.push('Spalte «Total Stunden» nicht gefunden.');
    persons.forEach((p) => {
      const has = (k) => res.cols.some((x) => x.p === p && x.k === k);
      if (!has('nettoC')) res.warnings.push(`Keine Spalte «Netto» für ${p.kurzname}.`);
      if (p.ahvAbzug && has('nettoC') && !has('bruttoC')) res.errors.push(`Keine Spalte «Brutto» für ${p.kurzname} (mit AHV-Abzug).`);
    });
    if (res.errors.length) return res;
    values.slice(hi + 1).forEach((r, i) => {
      const m = sheetMonth(r[0]); if (!m) return;
      const rec = { persons: {}, hcTotal: null }; let any = false; const pv = {};
      res.cols.forEach((c) => {
        const n = sheetNumber(r[c.j]);
        if (n === null) return;
        if (isNaN(n)) { res.errors.push(`${MONATE[m - 1]}: Wert «${r[c.j]}» in Spalte «${c.header}» ist keine Zahl.`); return; }
        (pv[c.p.id] || (pv[c.p.id] = {}))[c.k] = toCents(n); if (n !== 0) any = true;
      });
      const hn = sheetNumber(r[hoursCol]);
      if (hn !== null && isNaN(hn)) res.errors.push(`${MONATE[m - 1]}: Stunden «${r[hoursCol]}» sind keine Zahl.`);
      if (!any) return;
      if (res.months[m]) { res.errors.push(`Der Monat ${MONATE[m - 1]} steht zweimal in der Tabelle (Zeile ${hi + i + 2}).`); return; }
      persons.forEach((p) => {
        const v = pv[p.id]; if (!v || (!v.nettoC && !v.bruttoC)) return;
        if (v.nettoC == null) { res.errors.push(`${MONATE[m - 1]}: Netto fehlt für ${p.kurzname}.`); return; }
        rec.persons[p.id] = { hc: 0, bruttoC: v.bruttoC != null ? v.bruttoC : v.nettoC, nettoC: v.nettoC };
      });
      rec.hcTotal = hn !== null && !isNaN(hn) ? Math.round(hn * 100) : null;
      if (rec.hcTotal == null) res.warnings.push(`${MONATE[m - 1]}: Total Stunden fehlt.`);
      res.months[m] = rec;
    });
    if (!Object.keys(res.months).length && !res.errors.length) res.errors.push('In der Tabelle sind keine Monate mit Beträgen eingetragen.');
    return res;
  }

  const api = {
    MONATE, WOCHENTAGE, pad, ymd, parseYmd, weekday, weekdayName, fmtDate, daysInMonth, monthDays, sundaysThursdays,
    monthKey, monthLabel, nextMonthFirst, toCents, round5, fmtMoney, fmtHc, fmtPct, calcPerson, distribute,
    parseCSV, importClockify, yearTotals, norm, yearColumns, yearSheet, sheetMonth, sheetNumber, parseYearSheet,
  };
  root.Core = api;
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
