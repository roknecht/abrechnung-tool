/**
 * Stundenerfassung – Google Apps Script (Web-App, gebunden an die Tabelle «Stundenerfassung Assistenz»).
 * Tabellenblatt «Personen»: Spalte A = Token (geheimer Link-Teil), B = Name (genau wie in der Abrechnungs-App), C = aktiv (leer oder «ja»; «nein» sperrt)
 * Tabellenblatt «Stunden»: A = Name, B = Datum (JJJJ-MM-TT, Text), C = Dauer (Dezimalstunden), D = Geändert
 * Die Spalten A–C sind so benannt (Name | Datum | Dauer), dass die Abrechnungs-App die CSV-Datei direkt einlesen kann.
 * Tabellenblatt «Abschluss» (wird automatisch angelegt): A = Name, B = Monat (JJJJ-MM), C = Total, D = Zeitpunkt, E = Status («abgeschickt» oder «offen»), F = Anzahl Abschlüsse.
 *   Ein Monat ist für die Person gesperrt, solange der Status «abgeschickt» ist. Roger kann ihn öffnen, indem er den Status auf «offen» setzt oder die Zeile löscht.
 * Abruf durch die App: Aktion «export» mit Schlüssel (Skripteigenschaft ABRUF_KEY); liefert Stunden eines Monats als CSV-Text und den Abschluss-Status.
 * Beim Abschicken geht eine E-Mail an den Besitzer des Scripts (Konto, unter dem die Web-App läuft).
 */
var TZ = 'Europe/Zurich';
var SH_P = 'Personen';
var SH_S = 'Stunden';
var SH_A = 'Abschluss';
var MONATE = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

function doGet(e) { return out_(handle_(e && e.parameter ? e.parameter : {})); }
function doPost(e) {
  var p = {};
  try { p = JSON.parse(e.postData.contents); } catch (x) { p = (e && e.parameter) || {}; }
  return out_(handle_(p));
}
function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

function handle_(p) {
  var lock = LockService.getScriptLock();
  try { lock.waitLock(15000); } catch (x) { return { ok: false, error: 'Gerade besetzt, bitte nochmals versuchen.' }; }
  try {
    if (p.action === 'export') return export_(String(p.k || ''), String(p.m || ''));
    var name = findPerson_(String(p.t || ''));
    if (!name) return { ok: false, error: 'Dieser Link ist ungültig. Bitte bei Roger nachfragen.' };
    if (p.action === 'set') return setHours_(name, String(p.date || ''), p.hours);
    if (p.action === 'submit') return submit_(name, String(p.m || ''));
    if (p.action === 'reopen') return reopen_(name, String(p.m || ''));
    return list_(name, String(p.m || ''));
  } catch (err) {
    return { ok: false, error: 'Fehler: ' + err.message };
  } finally { lock.releaseLock(); }
}

function sheet_(n) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var s = ss.getSheetByName(n);
  if (!s) throw new Error('Tabellenblatt «' + n + '» fehlt');
  return s;
}

function findPerson_(token) {
  if (token.length < 16) return null;
  var v = sheet_(SH_P).getDataRange().getValues();
  for (var i = 1; i < v.length; i++) {
    if (String(v[i][0]).trim() === token) {
      if (String(v[i][2]).trim().toLowerCase() === 'nein') return null;
      return String(v[i][1]).trim();
    }
  }
  return null;
}

function today_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'); }
function prevMonth_(ym) {
  var y = +ym.slice(0, 4), m = +ym.slice(5, 7) - 1;
  if (m < 1) { y--; m = 12; }
  return y + '-' + (m < 10 ? '0' : '') + m;
}
/** Bearbeitbar: laufender Monat und Vormonat. Ältere Monate nur noch lesen. */
function editable_(ym) { var t = today_().slice(0, 7); return ym === t || ym === prevMonth_(t); }

function datesOf_(name, ym) {
  var s = sheet_(SH_S), n = s.getLastRow(), res = {};
  if (n < 2) return res;
  var v = s.getRange(2, 1, n - 1, 3).getValues();
  for (var i = 0; i < v.length; i++) {
    var d = cellDate_(v[i][1]);
    if (String(v[i][0]).trim() === name && d.slice(0, 7) === ym) res[d] = Number(v[i][2]);
  }
  return res;
}
function cellDate_(c) {
  if (c instanceof Date) return Utilities.formatDate(c, TZ, 'yyyy-MM-dd');
  return String(c).trim();
}

function list_(name, ym) {
  if (!/^\d{4}-\d{2}$/.test(ym)) ym = today_().slice(0, 7);
  return { ok: true, name: name, month: ym, today: today_(), editable: editable_(ym), closed: closed_(name, ym), entries: datesOf_(name, ym) };
}

var MAX_H = 12;
/** Nur Dezimalstunden in Viertelstunden (Komma oder Punkt), 0 bis MAX_H. Leer = 0 (Eintrag löschen). */
function parseHours_(h) {
  if (h === '' || h === null || h === undefined) return 0;
  var s = String(h).trim().replace(',', '.');
  if (!s) return 0;
  if (!/^\d{1,2}(\.\d{1,2})?$/.test(s)) return NaN;
  var v = Number(s);
  if (!isFinite(v) || v < 0 || v > MAX_H) return NaN;
  if (Math.abs(v * 4 - Math.round(v * 4)) > 1e-9) return NaN;
  return v;
}

function setHours_(name, date, hours) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return { ok: false, error: 'Datum ungültig.' };
  var y = +date.slice(0, 4), m = +date.slice(5, 7), d = +date.slice(8, 10);
  var dt = new Date(y, m - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return { ok: false, error: 'Datum ungültig.' };
  if (!editable_(date.slice(0, 7))) return { ok: false, error: 'Dieser Monat ist abgeschlossen. Änderungen bitte Roger melden.' };
  if (date > today_()) return { ok: false, error: 'Für zukünftige Tage kann noch nichts eingetragen werden.' };
  if (closed_(name, date.slice(0, 7))) return { ok: false, error: 'Dieser Monat ist abgeschickt. Bitte zuerst «Nochmals bearbeiten» wählen.' };
  var h = parseHours_(hours);
  if (isNaN(h)) return { ok: false, error: 'Bitte Stunden in Viertelstunden eingeben (z. B. 4, 4.25, 4.5 oder 4.75), höchstens ' + MAX_H + ' Stunden pro Tag.' };
  var s = sheet_(SH_S), n = s.getLastRow(), row = -1;
  if (n >= 2) {
    var v = s.getRange(2, 1, n - 1, 3).getValues();
    for (var i = 0; i < v.length; i++) {
      if (String(v[i][0]).trim() === name && cellDate_(v[i][1]) === date) { row = i + 2; break; }
    }
  }
  var now = Utilities.formatDate(new Date(), TZ, 'dd.MM.yyyy HH:mm');
  if (h === 0) { if (row > 0) s.deleteRow(row); }
  else if (row > 0) { s.getRange(row, 3, 1, 2).setValues([[h, now]]); }
  else {
    var r = Math.max(n, 1) + 1;
    s.getRange(r, 2).setNumberFormat('@');
    s.getRange(r, 1, 1, 4).setValues([[name, date, h, now]]);
  }
  return { ok: true, date: date, hours: h };
}

function monthLabel_(ym) { return MONATE[+ym.slice(5, 7) - 1] + ' ' + ym.slice(0, 4); }
function cellMonth_(c) {
  if (c instanceof Date) return Utilities.formatDate(c, TZ, 'yyyy-MM');
  return String(c).trim();
}

/** Blatt «Abschluss» (wird bei Bedarf angelegt). */
function absSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var s = ss.getSheetByName(SH_A);
  if (!s) {
    s = ss.insertSheet(SH_A);
    s.getRange(1, 1, 1, 6).setValues([['Name', 'Monat', 'Total', 'Zeitpunkt', 'Status', 'Anzahl']]);
    s.getRange('B:B').setNumberFormat('@');
  }
  return s;
}
function absFind_(name, ym) {
  var s = absSheet_(), n = s.getLastRow();
  if (n < 2) return null;
  var v = s.getRange(2, 1, n - 1, 6).getValues();
  for (var i = 0; i < v.length; i++) {
    if (String(v[i][0]).trim() === name && cellMonth_(v[i][1]) === ym) {
      return { row: i + 2, status: String(v[i][4]).trim().toLowerCase(), count: Number(v[i][5]) || 0 };
    }
  }
  return null;
}
function closed_(name, ym) { var a = absFind_(name, ym); return !!a && a.status === 'abgeschickt'; }

function submit_(name, ym) {
  if (!/^\d{4}-\d{2}$/.test(ym)) return { ok: false, error: 'Monat ungültig.' };
  if (!editable_(ym)) return { ok: false, error: 'Dieser Monat ist abgeschlossen. Änderungen bitte Roger melden.' };
  var e = datesOf_(name, ym), total = 0, days = 0;
  Object.keys(e).forEach(function (k) { total += e[k]; days++; });
  var a = absFind_(name, ym);
  if (a && a.status === 'abgeschickt') return { ok: true, already: true, month: ym, total: total, days: days };
  var s = absSheet_(), now = Utilities.formatDate(new Date(), TZ, 'dd.MM.yyyy HH:mm');
  var count = (a ? a.count : 0) + 1;
  if (a) { s.getRange(a.row, 3, 1, 4).setValues([[total, now, 'abgeschickt', count]]); }
  else {
    var r = Math.max(s.getLastRow(), 1) + 1;
    s.getRange(r, 2).setNumberFormat('@');
    s.getRange(r, 1, 1, 6).setValues([[name, ym, total, now, 'abgeschickt', count]]);
  }
  var mail = notify_(name, ym, total, days, count, now);
  return { ok: true, month: ym, total: total, days: days, mail: mail };
}

function reopen_(name, ym) {
  if (!/^\d{4}-\d{2}$/.test(ym)) return { ok: false, error: 'Monat ungültig.' };
  if (!editable_(ym)) return { ok: false, error: 'Dieser Monat ist abgeschlossen. Änderungen bitte Roger melden.' };
  var a = absFind_(name, ym);
  if (a && a.status === 'abgeschickt') absSheet_().getRange(a.row, 5, 1, 1).setValues([['offen']]);
  return { ok: true, month: ym };
}

/**
 * Abruf durch die Abrechnungs-App: liefert alle Stunden eines Monats als CSV-Text (Name,Datum,Dauer,Geändert)
 * und den Abschluss-Status pro Person. Nur mit dem geheimen Schlüssel aus den Skripteigenschaften (Eigenschaft ABRUF_KEY).
 */
function export_(key, ym) {
  var want = PropertiesService.getScriptProperties().getProperty('ABRUF_KEY') || '';
  if (want.length < 12) return { ok: false, error: 'Abruf ist nicht eingerichtet (Skripteigenschaft ABRUF_KEY fehlt).' };
  if (key.length !== want.length || key !== want) return { ok: false, error: 'Abruf-Schlüssel ist falsch.' };
  if (!/^\d{4}-\d{2}$/.test(ym)) return { ok: false, error: 'Monat ungültig.' };
  var s = sheet_(SH_S), n = s.getLastRow(), lines = ['Name,Datum,Dauer,Geändert'], rows = 0;
  var q = function (x) { x = String(x); return /[",\n]/.test(x) ? '"' + x.replace(/"/g, '""') + '"' : x; };
  if (n >= 2) {
    var v = s.getRange(2, 1, n - 1, 4).getValues();
    for (var i = 0; i < v.length; i++) {
      var d = cellDate_(v[i][1]);
      if (d.slice(0, 7) !== ym || !String(v[i][0]).trim()) continue;
      lines.push([q(String(v[i][0]).trim()), d, Number(v[i][2]), q(v[i][3] instanceof Date ? Utilities.formatDate(v[i][3], TZ, 'dd.MM.yyyy HH:mm') : v[i][3])].join(','));
      rows++;
    }
  }
  var abs = [], a = absSheet_(), an = a.getLastRow();
  if (an >= 2) {
    var av = a.getRange(2, 1, an - 1, 6).getValues();
    for (var j = 0; j < av.length; j++) {
      if (cellMonth_(av[j][1]) === ym) abs.push({ name: String(av[j][0]).trim(), status: String(av[j][4]).trim().toLowerCase(), total: Number(av[j][2]) || 0 });
    }
  }
  var pv = sheet_(SH_P).getDataRange().getValues(), act = [];
  for (var k = 1; k < pv.length; k++) {
    if (String(pv[k][1]).trim() && String(pv[k][2]).trim().toLowerCase() !== 'nein') act.push(String(pv[k][1]).trim());
  }
  return { ok: true, month: ym, rows: rows, csv: lines.join('\n') + '\n', abschluss: abs, aktiv: act };
}

/** E-Mail an den Besitzer des Scripts. Ein Fehler hier darf das Abschicken nicht verhindern. */
function notify_(name, ym, total, days, count, now) {
  try {
    var to = Session.getEffectiveUser().getEmail();
    if (!to) return false;
    var again = count > 1 ? ' (erneut)' : '';
    var subj = 'Stunden übermittelt: ' + name + ' ' + monthLabel_(ym) + again;
    var body = name + ' hat die Stunden für ' + monthLabel_(ym) + ' übermittelt' + again + '.\n\n' +
      'Total: ' + total.toFixed(2) + ' Stunden (' + days + (days === 1 ? ' Tag' : ' Tage') + ')\n' +
      'Zeitpunkt: ' + now + '\n\n' +
      'Die Einzelheiten stehen im Blatt «Stunden» der Tabelle «Stundenerfassung Assistenz».';
    MailApp.sendEmail(to, subj, body);
    return true;
  } catch (x) { return false; }
}

/** Einmalig im Script-Editor ausführen: holt die Berechtigung zum Senden der E-Mail. */
function autorisieren() {
  MailApp.getRemainingDailyQuota();
  Session.getEffectiveUser().getEmail();
}

/** Einmalig ausführen: legt die Tabellenblätter mit Kopfzeilen an. */
function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var p = ss.getSheetByName(SH_P) || ss.insertSheet(SH_P);
  if (p.getLastRow() < 1) p.getRange(1, 1, 1, 3).setValues([['Token', 'Name', 'aktiv']]);
  var s = ss.getSheetByName(SH_S) || ss.insertSheet(SH_S);
  if (s.getLastRow() < 1) s.getRange(1, 1, 1, 4).setValues([['Name', 'Datum', 'Dauer', 'Geändert']]);
  s.getRange('B:B').setNumberFormat('@');
  absSheet_();
}
