/**
 * Stundenerfassung – Google Apps Script (Web-App, gebunden an die Tabelle «Stundenerfassung Assistenz»).
 * Tabellenblatt «Personen»: Spalte A = Token (geheimer Link-Teil), B = Name (genau wie in der Abrechnungs-App), C = aktiv (leer oder «ja»; «nein» sperrt)
 * Tabellenblatt «Stunden»: A = Name, B = Datum (JJJJ-MM-TT, Text), C = Dauer (Dezimalstunden), D = Geändert
 * Die Spalten A–C sind so benannt (Name | Datum | Dauer), dass die Abrechnungs-App die CSV-Datei direkt einlesen kann.
 */
var TZ = 'Europe/Zurich';
var SH_P = 'Personen';
var SH_S = 'Stunden';

function doGet(e) { return out_(handle_(e && e.parameter ? e.parameter : {})); }
function doPost(e) {
  var p = {};
  try { p = JSON.parse(e.postData.contents); } catch (x) { p = (e && e.parameter) || {}; }
  return out_(handle_(p));
}
function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

function handle_(p) {
  var lock = LockService.getScriptLock();
  try { lock.waitLock(15000); } catch (x) { return { ok: false, error: 'Gerade besetzt, bitte nochmals versuchen.' }; }
  try {
    var name = findPerson_(String(p.t || ''));
    if (!name) return { ok: false, error: 'Dieser Link ist ungültig. Bitte bei Roger nachfragen.' };
    if (p.action === 'set') return setHours_(name, String(p.date || ''), p.hours);
    return list_(name, String(p.m || ''));
  } catch (err) {
    return { ok: false, error: 'Fehler: ' + err.message };
  } finally { lock.releaseLock(); }
}

function sheet_(n) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var s = ss.getSheetByName(n);
  if (!s) throw new Error('Tabellenblatt «' + n + '» fehlt');
  return s;
}

function findPerson_(token) {
  if (token.length < 16) return null;
  var v = sheet_(SH_P).getDataRange().getValues();
  for (var i = 1; i < v.length; i++) {
    if (String(v[i][0]).trim() === token) {
      if (String(v[i][2]).trim().toLowerCase() === 'nein') return null;
      return String(v[i][1]).trim();
    }
  }
  return null;
}

function today_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'); }
function prevMonth_(ym) {
  var y = +ym.slice(0, 4), m = +ym.slice(5, 7) - 1;
  if (m < 1) { y--; m = 12; }
  return y + '-' + (m < 10 ? '0' : '') + m;
}
/** Bearbeitbar: laufender Monat und Vormonat. Ältere Monate nur noch lesen. */
function editable_(ym) { var t = today_().slice(0, 7); return ym === t || ym === prevMonth_(t); }

function datesOf_(name, ym) {
  var s = sheet_(SH_S), n = s.getLastRow(), res = {};
  if (n < 2) return res;
  var v = s.getRange(2, 1, n - 1, 3).getValues();
  for (var i = 0; i < v.length; i++) {
    var d = cellDate_(v[i][1]);
    if (String(v[i][0]).trim() === name && d.slice(0, 7) === ym) res[d] = Number(v[i][2]);
  }
  return res;
}
function cellDate_(c) {
  if (c instanceof Date) return Utilities.formatDate(c, TZ, 'yyyy-MM-dd');
  return String(c).trim();
}

function list_(name, ym) {
  if (!/^\d{4}-\d{2}$/.test(ym)) ym = today_().slice(0, 7);
  return { ok: true, name: name, month: ym, today: today_(), editable: editable_(ym), entries: datesOf_(name, ym) };
}

function parseHours_(h) {
  if (h === '' || h === null || h === undefined) return 0;
  var s = String(h).trim().replace(',', '.');
  var m = s.match(/^(\d{1,2}):(\d{2})$/);
  var v = m ? (+m[1] + (+m[2]) / 60) : Number(s);
  if (!isFinite(v) || v < 0 || v > 24) return NaN;
  return Math.round(v * 100) / 100;
}

function setHours_(name, date, hours) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return { ok: false, error: 'Datum ungültig.' };
  var y = +date.slice(0, 4), m = +date.slice(5, 7), d = +date.slice(8, 10);
  var dt = new Date(y, m - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return { ok: false, error: 'Datum ungültig.' };
  if (!editable_(date.slice(0, 7))) return { ok: false, error: 'Dieser Monat ist abgeschlossen. Änderungen bitte Roger melden.' };
  if (date > today_()) return { ok: false, error: 'Für zukünftige Tage kann noch nichts eingetragen werden.' };
  var h = parseHours_(hours);
  if (isNaN(h)) return { ok: false, error: 'Bitte Stunden zwischen 0 und 24 eingeben, z. B. 4.5 oder 4:30.' };
  var s = sheet_(SH_S), n = s.getLastRow(), row = -1;
  if (n >= 2) {
    var v = s.getRange(2, 1, n - 1, 3).getValues();
    for (var i = 0; i < v.length; i++) {
      if (String(v[i][0]).trim() === name && cellDate_(v[i][1]) === date) { row = i + 2; break; }
    }
  }
  var now = Utilities.formatDate(new Date(), TZ, 'dd.MM.yyyy HH:mm');
  if (h === 0) { if (row > 0) s.deleteRow(row); }
  else if (row > 0) { s.getRange(row, 3, 1, 2).setValues([[h, now]]); }
  else {
    var r = Math.max(n, 1) + 1;
    s.getRange(r, 2).setNumberFormat('@');
    s.getRange(r, 1, 1, 4).setValues([[name, date, h, now]]);
  }
  return { ok: true, date: date, hours: h };
}

/** Einmalig ausführen: legt die beiden Tabellenblätter mit Kopfzeilen an. */
function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var p = ss.getSheetByName(SH_P) || ss.insertSheet(SH_P);
  if (p.getLastRow() < 1) p.getRange(1, 1, 1, 3).setValues([['Token', 'Name', 'aktiv']]);
  var s = ss.getSheetByName(SH_S) || ss.insertSheet(SH_S);
  if (s.getLastRow() < 1) s.getRange(1, 1, 1, 4).setValues([['Name', 'Datum', 'Dauer', 'Geändert']]);
  s.getRange('B:B').setNumberFormat('@');
}
