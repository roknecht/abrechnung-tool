/**
 * Stundenerfassung – Google Apps Script (Web-App, gebunden an die Tabelle «Stundenerfassung Assistenz»).
 * Tabellenblatt «Personen»: Spalte A = Token (geheimer Link-Teil), B = Name (genau wie in der Abrechnungs-App), C = aktiv (leer oder «ja»; «nein» sperrt)
 * Tabellenblatt «Stunden»: A = Name, B = Datum (JJJJ-MM-TT, Text), C = Dauer (Dezimalstunden), D = Geändert
 * Die Spalten A–C sind so benannt (Name | Datum | Dauer), dass die Abrechnungs-App die CSV-Datei direkt einlesen kann.
 * Tabellenblatt «Abschluss» (wird automatisch angelegt): A = Name, B = Monat (JJJJ-MM), C = Total, D = Zeitpunkt, E = Status («abgeschickt» oder «offen»), F = Anzahl Abschlüsse.
 *   Ein Monat ist für die Person gesperrt, solange der Status «abgeschickt» ist. Roger kann ihn öffnen, indem er den Status auf «offen» setzt oder die Zeile löscht.
 * Abruf durch die App: Aktion «export» mit Schlüssel (Skripteigenschaft ABRUF_KEY); liefert Stunden eines Monats als CSV-Text und den Abschluss-Status.
 * Beim Abschicken geht eine E-Mail an den Besitzer des Scripts (Konto, unter dem die Web-App läuft).
 * Ablage durch die App (POST, nur mit dem Schlüssel ABRUF_KEY). Hauptordner = Ordner der Stundentabelle (oder Skripteigenschaft HAUPTORDNER_ID):
 *   «ablegen»        legt PDFs in den Unterordnern ab (Ordnername = Kurzname) und verschiebt gleichnamige alte Dateien in den Papierkorb.
 *   «jahr_lesen»     liefert die Werte der Google Tabelle «Jahresübersicht Löhne Assistenz JJJJ» (einmalige Übernahme in die App).
 *   «jahr_schreiben» schreibt die Jahresübersicht in dieselbe Tabelle (gleicher Link); weigert sich, wenn dabei Monate verloren gingen.
 *   «entwurf»        legt Gmail-ENTWÜRFE mit PDF-Anhängen an. Das Script versendet nie E-Mails an Assistenzpersonen.
 *   Mit test = true arbeitet alles nur im Unterordner «_TEST Beispieldaten» des Hauptordners (für erfundene Beispieldaten).
 */
var TZ = 'Europe/Zurich';
var SH_P = 'Personen';
var SH_S = 'Stunden';
var SH_A = 'Abschluss';
var MONATE = ['Januar', 'Februar', 'März', 'April', 'Mai', 'Juni', 'Juli', 'August', 'September', 'Oktober', 'November', 'Dezember'];

function doGet(e) { return out_(handle_(e && e.parameter ? e.parameter : {})); }
function doPost(e) {
  var p = {};
  try { p = JSON.parse(e.postData.contents); } catch (x) { p = (e && e.parameter) || {}; }
  return out_(handle_(p));
}
function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

var ABLAGE = { ablegen: 1, jahr_lesen: 1, jahr_schreiben: 1, entwurf: 1 };

function handle_(p) {
  // Ablage-Aktionen der App: ohne Script-Sperre, damit die Erfassungsseite nie warten muss.
  if (ABLAGE[p.action]) {
    try {
      var err = checkKey_(String(p.k || ''));
      if (err) return { ok: false, error: err };
      if (p.action === 'ablegen') return ablegen_(p);
      if (p.action === 'jahr_lesen') return jahrLesen_(p);
      if (p.action === 'jahr_schreiben') return jahrSchreiben_(p);
      return entwurf_(p);
    } catch (x) { return { ok: false, error: 'Fehler: ' + x.message }; }
  }
  var lock = LockService.getScriptLock();
  try { lock.waitLock(15000); } catch (x) { return { ok: false, error: 'Gerade besetzt, bitte nochmals versuchen.' }; }
  try {
    if (p.action === 'export') return export_(String(p.k || ''), String(p.m || ''));
    var name = findPerson_(String(p.t || ''));
    if (!name) return { ok: false, error: 'Dieser Link ist ungültig. Bitte bei Roger nachfragen.' };
    if (p.action === 'set') return setHours_(name, String(p.date || ''), p.hours);
    if (p.action === 'submit') return submit_(name, String(p.m || ''));
    if (p.action === 'reopen') return reopen_(name, String(p.m || ''));
    return list_(name, String(p.m || ''));
  } catch (err) {
    return { ok: false, error: 'Fehler: ' + err.message };
  } finally { lock.releaseLock(); }
}

function sheet_(n) {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var s = ss.getSheetByName(n);
  if (!s) throw new Error('Tabellenblatt «' + n + '» fehlt');
  return s;
}

function findPerson_(token) {
  if (token.length < 16) return null;
  var v = sheet_(SH_P).getDataRange().getValues();
  for (var i = 1; i < v.length; i++) {
    if (String(v[i][0]).trim() === token) {
      if (String(v[i][2]).trim().toLowerCase() === 'nein') return null;
      return String(v[i][1]).trim();
    }
  }
  return null;
}

function today_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd'); }
function prevMonth_(ym) {
  var y = +ym.slice(0, 4), m = +ym.slice(5, 7) - 1;
  if (m < 1) { y--; m = 12; }
  return y + '-' + (m < 10 ? '0' : '') + m;
}
/** Bearbeitbar: laufender Monat und Vormonat. Ältere Monate nur noch lesen. */
function editable_(ym) { var t = today_().slice(0, 7); return ym === t || ym === prevMonth_(t); }

function datesOf_(name, ym) {
  var s = sheet_(SH_S), n = s.getLastRow(), res = {};
  if (n < 2) return res;
  var v = s.getRange(2, 1, n - 1, 3).getValues();
  for (var i = 0; i < v.length; i++) {
    var d = cellDate_(v[i][1]);
    if (String(v[i][0]).trim() === name && d.slice(0, 7) === ym) res[d] = Number(v[i][2]);
  }
  return res;
}
function cellDate_(c) {
  if (c instanceof Date) return Utilities.formatDate(c, TZ, 'yyyy-MM-dd');
  return String(c).trim();
}

function list_(name, ym) {
  if (!/^\d{4}-\d{2}$/.test(ym)) ym = today_().slice(0, 7);
  return { ok: true, name: name, month: ym, today: today_(), editable: editable_(ym), closed: closed_(name, ym), entries: datesOf_(name, ym) };
}

var MAX_H = 12;
/** Nur Dezimalstunden in Viertelstunden (Komma oder Punkt), 0 bis MAX_H. Leer = 0 (Eintrag löschen). */
function parseHours_(h) {
  if (h === '' || h === null || h === undefined) return 0;
  var s = String(h).trim().replace(',', '.');
  if (!s) return 0;
  if (!/^\d{1,2}(\.\d{1,2})?$/.test(s)) return NaN;
  var v = Number(s);
  if (!isFinite(v) || v < 0 || v > MAX_H) return NaN;
  if (Math.abs(v * 4 - Math.round(v * 4)) > 1e-9) return NaN;
  return v;
}

function setHours_(name, date, hours) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) return { ok: false, error: 'Datum ungültig.' };
  var y = +date.slice(0, 4), m = +date.slice(5, 7), d = +date.slice(8, 10);
  var dt = new Date(y, m - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return { ok: false, error: 'Datum ungültig.' };
  if (!editable_(date.slice(0, 7))) return { ok: false, error: 'Dieser Monat ist abgeschlossen. Änderungen bitte Roger melden.' };
  if (date > today_()) return { ok: false, error: 'Für zukünftige Tage kann noch nichts eingetragen werden.' };
  if (closed_(name, date.slice(0, 7))) return { ok: false, error: 'Dieser Monat ist abgeschickt. Bitte zuerst «Nochmals bearbeiten» wählen.' };
  var h = parseHours_(hours);
  if (isNaN(h)) return { ok: false, error: 'Bitte Stunden in Viertelstunden eingeben (z. B. 4, 4.25, 4.5 oder 4.75), höchstens ' + MAX_H + ' Stunden pro Tag.' };
  var s = sheet_(SH_S), n = s.getLastRow(), row = -1;
  if (n >= 2) {
    var v = s.getRange(2, 1, n - 1, 3).getValues();
    for (var i = 0; i < v.length; i++) {
      if (String(v[i][0]).trim() === name && cellDate_(v[i][1]) === date) { row = i + 2; break; }
    }
  }
  var now = Utilities.formatDate(new Date(), TZ, 'dd.MM.yyyy HH:mm');
  if (h === 0) { if (row > 0) s.deleteRow(row); }
  else if (row > 0) { s.getRange(row, 3, 1, 2).setValues([[h, now]]); }
  else {
    var r = Math.max(n, 1) + 1;
    s.getRange(r, 2).setNumberFormat('@');
    s.getRange(r, 1, 1, 4).setValues([[name, date, h, now]]);
  }
  return { ok: true, date: date, hours: h };
}

function monthLabel_(ym) { return MONATE[+ym.slice(5, 7) - 1] + ' ' + ym.slice(0, 4); }
function cellMonth_(c) {
  if (c instanceof Date) return Utilities.formatDate(c, TZ, 'yyyy-MM');
  return String(c).trim();
}

/** Blatt «Abschluss» (wird bei Bedarf angelegt). */
function absSheet_() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var s = ss.getSheetByName(SH_A);
  if (!s) {
    s = ss.insertSheet(SH_A);
    s.getRange(1, 1, 1, 6).setValues([['Name', 'Monat', 'Total', 'Zeitpunkt', 'Status', 'Anzahl']]);
    s.getRange('B:B').setNumberFormat('@');
  }
  return s;
}
function absFind_(name, ym) {
  var s = absSheet_(), n = s.getLastRow();
  if (n < 2) return null;
  var v = s.getRange(2, 1, n - 1, 6).getValues();
  for (var i = 0; i < v.length; i++) {
    if (String(v[i][0]).trim() === name && cellMonth_(v[i][1]) === ym) {
      return { row: i + 2, status: String(v[i][4]).trim().toLowerCase(), count: Number(v[i][5]) || 0 };
    }
  }
  return null;
}
function closed_(name, ym) { var a = absFind_(name, ym); return !!a && a.status === 'abgeschickt'; }

function submit_(name, ym) {
  if (!/^\d{4}-\d{2}$/.test(ym)) return { ok: false, error: 'Monat ungültig.' };
  if (!editable_(ym)) return { ok: false, error: 'Dieser Monat ist abgeschlossen. Änderungen bitte Roger melden.' };
  var e = datesOf_(name, ym), total = 0, days = 0;
  Object.keys(e).forEach(function (k) { total += e[k]; days++; });
  var a = absFind_(name, ym);
  if (a && a.status === 'abgeschickt') return { ok: true, already: true, month: ym, total: total, days: days };
  var s = absSheet_(), now = Utilities.formatDate(new Date(), TZ, 'dd.MM.yyyy HH:mm');
  var count = (a ? a.count : 0) + 1;
  if (a) { s.getRange(a.row, 3, 1, 4).setValues([[total, now, 'abgeschickt', count]]); }
  else {
    var r = Math.max(s.getLastRow(), 1) + 1;
    s.getRange(r, 2).setNumberFormat('@');
    s.getRange(r, 1, 1, 6).setValues([[name, ym, total, now, 'abgeschickt', count]]);
  }
  var mail = notify_(name, ym, total, days, count, now);
  return { ok: true, month: ym, total: total, days: days, mail: mail };
}

function reopen_(name, ym) {
  if (!/^\d{4}-\d{2}$/.test(ym)) return { ok: false, error: 'Monat ungültig.' };
  if (!editable_(ym)) return { ok: false, error: 'Dieser Monat ist abgeschlossen. Änderungen bitte Roger melden.' };
  var a = absFind_(name, ym);
  if (a && a.status === 'abgeschickt') absSheet_().getRange(a.row, 5, 1, 1).setValues([['offen']]);
  return { ok: true, month: ym };
}

/**
 * Abruf durch die Abrechnungs-App: liefert alle Stunden eines Monats als CSV-Text (Name,Datum,Dauer,Geändert)
 * und den Abschluss-Status pro Person. Nur mit dem geheimen Schlüssel aus den Skripteigenschaften (Eigenschaft ABRUF_KEY).
 */
function checkKey_(key) {
  var want = PropertiesService.getScriptProperties().getProperty('ABRUF_KEY') || '';
  if (want.length < 12) return 'Abruf ist nicht eingerichtet (Skripteigenschaft ABRUF_KEY fehlt).';
  if (key.length !== want.length || key !== want) return 'Abruf-Schlüssel ist falsch.';
  return '';
}

function export_(key, ym) {
  var kerr = checkKey_(key);
  if (kerr) return { ok: false, error: kerr };
  if (!/^\d{4}-\d{2}$/.test(ym)) return { ok: false, error: 'Monat ungültig.' };
  var s = sheet_(SH_S), n = s.getLastRow(), lines = ['Name,Datum,Dauer,Geändert'], rows = 0;
  var q = function (x) { x = String(x); return /[",\n]/.test(x) ? '"' + x.replace(/"/g, '""') + '"' : x; };
  if (n >= 2) {
    var v = s.getRange(2, 1, n - 1, 4).getValues();
    for (var i = 0; i < v.length; i++) {
      var d = cellDate_(v[i][1]);
      if (d.slice(0, 7) !== ym || !String(v[i][0]).trim()) continue;
      lines.push([q(String(v[i][0]).trim()), d, Number(v[i][2]), q(v[i][3] instanceof Date ? Utilities.formatDate(v[i][3], TZ, 'dd.MM.yyyy HH:mm') : v[i][3])].join(','));
      rows++;
    }
  }
  var abs = [], a = absSheet_(), an = a.getLastRow();
  if (an >= 2) {
    var av = a.getRange(2, 1, an - 1, 6).getValues();
    for (var j = 0; j < av.length; j++) {
      if (cellMonth_(av[j][1]) === ym) abs.push({ name: String(av[j][0]).trim(), status: String(av[j][4]).trim().toLowerCase(), total: Number(av[j][2]) || 0 });
    }
  }
  var pv = sheet_(SH_P).getDataRange().getValues(), act = [];
  for (var k = 1; k < pv.length; k++) {
    if (String(pv[k][1]).trim() && String(pv[k][2]).trim().toLowerCase() !== 'nein') act.push(String(pv[k][1]).trim());
  }
  return { ok: true, month: ym, rows: rows, csv: lines.join('\n') + '\n', abschluss: abs, aktiv: act };
}

/** E-Mail an den Besitzer des Scripts. Ein Fehler hier darf das Abschicken nicht verhindern. */
function notify_(name, ym, total, days, count, now) {
  try {
    var to = Session.getEffectiveUser().getEmail();
    if (!to) return false;
    var again = count > 1 ? ' (erneut)' : '';
    var subj = 'Stunden übermittelt: ' + name + ' ' + monthLabel_(ym) + again;
    var body = name + ' hat die Stunden für ' + monthLabel_(ym) + ' übermittelt' + again + '.\n\n' +
      'Total: ' + total.toFixed(2) + ' Stunden (' + days + (days === 1 ? ' Tag' : ' Tage') + ')\n' +
      'Zeitpunkt: ' + now + '\n\n' +
      'Die Einzelheiten stehen im Blatt «Stunden» der Tabelle «Stundenerfassung Assistenz».';
    MailApp.sendEmail(to, subj, body);
    return true;
  } catch (x) { return false; }
}

/** Einmalig im Script-Editor ausführen: holt die Berechtigungen (E-Mail-Hinweis, Drive-Ablage, Gmail-Entwürfe, Tabellen). */
function autorisieren() {
  MailApp.getRemainingDailyQuota();
  Session.getEffectiveUser().getEmail();
  Logger.log('Hauptordner: ' + hauptordner_().getName());
  GmailApp.getDrafts();
  Logger.log('Berechtigungen in Ordnung.');
}

/* =====================  Ablage durch die Abrechnungs-App  ===================== */
var HAUPTORDNER_NAME = 'Assistenzpersonenabrechnungen';
var TEST_ORDNER = '_TEST Beispieldaten';
var MAX_PDF = 5 * 1024 * 1024;

function nfc_(s) { s = String(s == null ? '' : s).trim(); return typeof s.normalize === 'function' ? s.normalize('NFC') : s; }

/**
 * Hauptordner = Ordner, in dem die Tabelle «Stundenerfassung Assistenz» liegt
 * (oder Skripteigenschaft HAUPTORDNER_ID). Zur Sicherheit muss er «Assistenzpersonenabrechnungen» heissen.
 */
function hauptordner_() {
  var id = PropertiesService.getScriptProperties().getProperty('HAUPTORDNER_ID');
  var f;
  if (id) f = DriveApp.getFolderById(id);
  else {
    var it = DriveApp.getFileById(SpreadsheetApp.getActiveSpreadsheet().getId()).getParents();
    if (!it.hasNext()) throw new Error('Hauptordner nicht gefunden.');
    f = it.next();
  }
  if (nfc_(f.getName()) !== HAUPTORDNER_NAME) throw new Error('Der Ordner der Stundentabelle heisst nicht «' + HAUPTORDNER_NAME + '». Ablage abgebrochen.');
  return f;
}
function unterordner_(parent, name, create) {
  var want = nfc_(name), it = parent.getFolders(), found = [];
  while (it.hasNext()) { var f = it.next(); if (nfc_(f.getName()) === want) found.push(f); }
  if (found.length > 1) throw new Error('Den Ordner «' + name + '» gibt es mehrfach. Bitte im Drive bereinigen.');
  if (found.length === 1) return found[0];
  if (create) return parent.createFolder(want);
  return null;
}
/** Basisordner: echter Hauptordner oder (Test) dessen Unterordner «_TEST Beispieldaten». */
function basis_(test) {
  var h = hauptordner_();
  return test ? unterordner_(h, TEST_ORDNER, true) : h;
}
function dateienNamens_(folder, name) {
  var want = nfc_(name), it = folder.getFiles(), out = [];
  while (it.hasNext()) { var f = it.next(); if (nfc_(f.getName()) === want) out.push(f); }
  return out;
}

var RE_PERSON_PDF = /^\d{4}-\d{2} (Lohnabrechnung|Stundenübersicht) .+\.pdf$/;
var RE_JAHR_PDF = /^Jahresübersicht Löhne Assistenz \d{4}\.pdf$/;

/**
 * {ordner: Kurzname oder '' für den Hauptordner, files: [{name, b64}], test}
 * Neue Datei zuerst anlegen, erst danach alte gleichnamige Dateien in den Papierkorb.
 */
function ablegen_(p) {
  var test = p.test === true, ordner = nfc_(p.ordner), files = p.files || [];
  if (!files.length || files.length > 4) return { ok: false, error: 'Keine oder zu viele Dateien.' };
  for (var i = 0; i < files.length; i++) {
    var n = nfc_(files[i].name);
    if (ordner ? !RE_PERSON_PDF.test(n) : !RE_JAHR_PDF.test(n)) return { ok: false, error: 'Unerwarteter Dateiname: ' + n };
    if (!files[i].b64 || files[i].b64.length > MAX_PDF * 1.4) return { ok: false, error: 'Datei fehlt oder ist zu gross: ' + n };
  }
  var base = basis_(test);
  var folder = ordner ? unterordner_(base, ordner, test) : base;
  if (!folder) return { ok: false, error: 'Im Drive gibt es keinen Ordner «' + ordner + '». Der Kurzname in der App muss genau gleich heissen wie der Ordner.' };
  // Erst alle Dateien prüfen, dann schreiben: bei einem Fehler wird nichts ersetzt.
  var blobs = files.map(function (fl) {
    var name = nfc_(fl.name), bytes = Utilities.base64Decode(fl.b64);
    if (bytes.length < 5 || String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) !== '%PDF') throw new Error('Keine PDF-Datei: ' + name);
    return { name: name, bytes: bytes };
  });
  var res = [];
  blobs.forEach(function (bl) {
    var name = bl.name;
    var neu = folder.createFile(Utilities.newBlob(bl.bytes, 'application/pdf', name));
    var alt = 0;
    dateienNamens_(folder, name).forEach(function (f) { if (f.getId() !== neu.getId()) { f.setTrashed(true); alt++; } });
    res.push({ name: name, id: neu.getId(), ersetzt: alt });
  });
  return { ok: true, ordner: folder.getName(), files: res };
}

function jahrName_(year) { return 'Jahresübersicht Löhne Assistenz ' + year; }
function jahrTabelle_(base, year) {
  var it = base.getFilesByType(MimeType.GOOGLE_SHEETS), want = nfc_(jahrName_(year)), found = [];
  while (it.hasNext()) { var f = it.next(); if (nfc_(f.getName()) === want) found.push(f); }
  if (found.length > 1) throw new Error('Die Tabelle «' + jahrName_(year) + '» gibt es mehrfach. Bitte im Drive bereinigen.');
  return found.length ? SpreadsheetApp.openById(found[0].getId()) : null;
}
var MON3 = ['jan', 'feb', 'mar', 'apr', 'mai', 'jun', 'jul', 'aug', 'sep', 'okt', 'nov', 'dez'];
/** Monat aus der ersten Spalte: «Januar», «Jan», «März 2026», «2026-03» oder ein Datum. Sonst 0. */
function monatsZeile_(v) {
  if (v instanceof Date) return v.getMonth() + 1;
  if (v && typeof v === 'object' && v.m) return Number(v.m);
  var s = nfc_(v).toLowerCase().replace('ä', 'a');
  var m = s.match(/^\d{4}-(\d{2})$/);
  if (m) return Number(m[1]) >= 1 && Number(m[1]) <= 12 ? Number(m[1]) : 0;
  for (var i = 0; i < 12; i++) if (s.slice(0, 3) === MON3[i] && /^[a-z]{3}/.test(s)) return i + 1;
  return 0;
}
function gefuellt_(rows) {
  var n = 0;
  rows.forEach(function (r) {
    if (!monatsZeile_(r[0])) return;
    for (var j = 1; j < r.length; j++) if (r[j] !== '' && r[j] !== null && Number(String(r[j]).replace(/[’'\s]/g, '')) !== 0) { n++; return; }
  });
  return n;
}

/** {year, test} -> Werte der ersten Tabellenseite (zum einmaligen Übernehmen in die App). */
function jahrLesen_(p) {
  var year = Number(p.year);
  if (!(year >= 2020 && year <= 2100)) return { ok: false, error: 'Jahr ungültig.' };
  var ss = jahrTabelle_(basis_(p.test === true), year);
  if (!ss) return { ok: true, found: false, name: jahrName_(year) };
  var v = ss.getSheets()[0].getDataRange().getValues().map(function (r) {
    return r.map(function (c) { return c instanceof Date ? { m: c.getMonth() + 1 } : c; });
  });
  return { ok: true, found: true, name: ss.getName(), values: v };
}

/**
 * {year, header: [..], rows: [[Monat, Werte…]] (12 Zeilen), test}
 * Schreibt die Jahresübersicht in die bestehende Tabelle (gleiche Datei, gleicher Link) oder legt sie neu an.
 * Sicherung: Hat die bestehende Tabelle mehr ausgefüllte Monate als die neuen Daten, wird nichts geschrieben.
 */
function jahrSchreiben_(p) {
  var year = Number(p.year), header = p.header || [], rows = p.rows || [];
  if (!(year >= 2020 && year <= 2100)) return { ok: false, error: 'Jahr ungültig.' };
  if (rows.length !== 12 || header.length < 3) return { ok: false, error: 'Daten der Jahresübersicht unvollständig.' };
  var w = header.length;
  for (var i = 0; i < 12; i++) {
    if (!rows[i] || rows[i].length !== w || monatsZeile_(rows[i][0]) !== i + 1) return { ok: false, error: 'Zeile ' + (i + 1) + ' der Jahresübersicht ungültig.' };
    for (var j = 1; j < w; j++) if (rows[i][j] !== '' && !isFinite(Number(rows[i][j]))) return { ok: false, error: 'Ungültiger Wert in der Jahresübersicht.' };
  }
  var base = basis_(p.test === true);
  var ss = jahrTabelle_(base, year), neu = false;
  if (ss) {
    var alt = gefuellt_(ss.getSheets()[0].getDataRange().getValues());
    var jetzt = gefuellt_(rows);
    if (alt > jetzt) return { ok: false, error: 'Die Tabelle «' + jahrName_(year) + '» enthält ' + alt + ' Monate, die App erst ' + jetzt + '. Bitte zuerst unter «Jahr» die Jahresdaten übernehmen. Es wurde nichts geändert.', alt: alt, jetzt: jetzt };
  } else {
    ss = SpreadsheetApp.create(jahrName_(year)); neu = true;
    DriveApp.getFileById(ss.getId()).moveTo(base);
  }
  var sh = ss.getSheets()[0];
  sh.clear();
  sh.getRange(1, 1, 1, w).setValues([header]).setFontWeight('bold');
  sh.getRange(2, 1, 12, w).setValues(rows);
  var tot = ['Total'];
  for (var c = 2; c <= w; c++) { var col = colName_(c); tot.push('=SUM(' + col + '2:' + col + '13)'); }
  sh.getRange(14, 1, 1, 1).setValue('Total');
  sh.getRange(14, 2, 1, w - 1).setFormulas([tot.slice(1)]);
  sh.getRange(14, 1, 1, w).setFontWeight('bold');
  sh.getRange(2, 2, 13, w - 1).setNumberFormat('#,##0.00');
  sh.setFrozenRows(1);
  return { ok: true, neu: neu, name: ss.getName(), url: ss.getUrl() };
}
function colName_(n) { var s = ''; while (n > 0) { var m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }

/**
 * {to, cc, subject, body, files: [{name, b64}], test}
 * Legt einen Gmail-ENTWURF an. Ein bestehender Entwurf mit genau gleichem Betreff wird ersetzt (keine Doppel).
 * Es wird nie etwas versendet.
 */
function entwurf_(p) {
  var test = p.test === true;
  var to = nfc_(p.to), cc = nfc_(p.cc), subject = nfc_(p.subject), body = String(p.body || ''), files = p.files || [];
  var mail = /^[^\s@,;]+@[^\s@,;]+\.[^\s@,;]+$/;
  if (!mail.test(to)) return { ok: false, error: 'E-Mail-Adresse der Person fehlt oder ist ungültig.' };
  if (cc && !mail.test(cc)) return { ok: false, error: 'CC-Adresse ist ungültig.' };
  if (test && (!/@example\.com$/i.test(to) || (cc && !/@example\.com$/i.test(cc)))) return { ok: false, error: 'Im Testmodus nur Adressen @example.com.' };
  if (test) subject = '[TEST] ' + subject;
  if (!/^(\[TEST\] )?Lohnabrechnung .+ \/ .+$/.test(subject)) return { ok: false, error: 'Betreff ungültig.' };
  if (!files.length || files.length > 2) return { ok: false, error: 'Anhänge fehlen.' };
  var att = files.map(function (fl) {
    var name = nfc_(fl.name);
    if (!RE_PERSON_PDF.test(name)) throw new Error('Unerwarteter Anhang: ' + name);
    var bytes = Utilities.base64Decode(fl.b64 || '');
    if (bytes.length < 5 || String.fromCharCode(bytes[0], bytes[1], bytes[2], bytes[3]) !== '%PDF') throw new Error('Keine PDF-Datei: ' + name);
    return Utilities.newBlob(bytes, 'application/pdf', name);
  });
  // Gleichnamige Entwürfe gezielt suchen (schnell, auch bei vielen alten Entwürfen) und danach ersetzen.
  var ersetzt = 0, ids = {}, n = 0;
  GmailApp.search('in:drafts subject:"' + subject.replace(/"/g, '') + '"', 0, 20).forEach(function (t) {
    t.getMessages().forEach(function (m) { if (m.isDraft() && nfc_(m.getSubject()) === subject) { ids[m.getId()] = 1; n++; } });
  });
  if (n) GmailApp.getDrafts().forEach(function (d) { if (ids[d.getMessageId()]) { d.deleteDraft(); ersetzt++; } });
  var opt = { attachments: att };
  if (cc) opt.cc = cc;
  var d = GmailApp.createDraft(to, subject, body, opt);
  return { ok: true, id: d.getId(), ersetzt: ersetzt, subject: subject };
}

/** Einmalig ausführen: legt die Tabellenblätter mit Kopfzeilen an. */
function setup() {
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var p = ss.getSheetByName(SH_P) || ss.insertSheet(SH_P);
  if (p.getLastRow() < 1) p.getRange(1, 1, 1, 3).setValues([['Token', 'Name', 'aktiv']]);
  var s = ss.getSheetByName(SH_S) || ss.insertSheet(SH_S);
  if (s.getLastRow() < 1) s.getRange(1, 1, 1, 4).setValues([['Name', 'Datum', 'Dauer', 'Geändert']]);
  s.getRange('B:B').setNumberFormat('@');
  absSheet_();
}
