// Baut dist/index.html: Programmcode und PDF-Bibliothek in einer einzigen Datei.
const fs = require('fs'); const path = require('path');
const rd = (p) => fs.readFileSync(path.join(__dirname, p), 'utf8');
const lib = fs.readFileSync('/opt/npm-tools/node_modules/pdf-lib/dist/pdf-lib.min.js', 'utf8').replace(/\/\/# sourceMappingURL=.*$/m, '');
let html = rd('src/index.template.html');
const parts = { '/*__PDFLIB__*/': lib, '/*__CORE__*/': rd('src/core.js'), '/*__PDF__*/': rd('src/pdf.js'), '/*__APP__*/': rd('src/app.js') };
for (const [k, v] of Object.entries(parts)) {
  if (/<\/script/i.test(v)) throw new Error('</script in ' + k);
  html = html.split(k).join(v);
}
fs.mkdirSync(path.join(__dirname, 'dist'), { recursive: true });
fs.writeFileSync(path.join(__dirname, 'dist/index.html'), html);
console.log('dist/index.html', (html.length / 1024).toFixed(0) + ' KB');
